#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_kpX___S1Lgx3hu0ti95uMw(const real_T*a,const size_t n);real_T
ex_VCMYZqH7FzWLWPHooBByoI(const real_T x);void ex_ktEh0_dPE7WMZaXpgviZfL(
real_T*fx1,real_T*ex__rg5CXJeg_Cndu5WDoxbMl,real_T*ex_V5xxz05F7a_ihqj30K8FAv,
real_T*ex_FNXAh_ftg_KpWeXlYDyRqE,const real_T*x1,const real_T*f,const size_t n1
,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex__dZ6arJEU5pmV9XKy8etwi,const size_t ex_VvovjV_Yc_G4fP1XodrLft,const size_t
ex_VhUgI4c0k9GOgm8dFTThdK,const size_t ex_Fsdzbs_wz00cfyfchwr6K7,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS);void ex_VKUiWhgLteGl_1sCHRJXum(real_T*
ex_k8zBiCVRtSWw_L3ohL9ZU6,real_T*ex__q3Je3USIpxhYaV_bmlNgE,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF);void ex_F7_9Sgo0sqlceT8kkrDtm9(real_T*
ex_kESK0x0mPXxyfXNDYQuNSo,real_T*ex__idLDQm5dX_uePEg9ek_dK,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t ex__Et5EUn_AfCGcaoPYM3rE7,const size_t
ex_VRc9H9oEh84hXu9Yu4okxd,const size_t ex__vFO6imE0nOcdTAyK5nWZf,const size_t
ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t ex_k64KfxW_YeCBd1Jcztnal5,const size_t
ex_FpCuD8p2g1ldYupGLDualI,const size_t ex_F4NwsNKf_S_ubm278AmjEt,const size_t
ex_VzS__hA47OtneLeQmJKhJU,const size_t ex_VseJVSrhmHl_fHMdqZQUoK,const size_t
ex__zov1f51H_xVZDV3hSAwLo,const size_t ex__UCiJ_ovpi8viepU66XSz1,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS,const real_T ex__QgqlEW2f18scLxPhDEnMF,const real_T
ex__yrlSbVOXjWXaTMEdN9cIu);void ex_Futd5IPo6_Sea16WtbGVmf(real_T*
ex__nq35K78gNGYiPqAi6FlY1,real_T*ex_k7clpQTkJip2cDihM27xMo,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const real_T*
ex__4uaYPi3B7txZPrRD2z8ek,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const size_t ex_VzS__hA47OtneLeQmJKhJU,const size_t
ex_VseJVSrhmHl_fHMdqZQUoK,const size_t ex__zov1f51H_xVZDV3hSAwLo,const size_t
ex__UCiJ_ovpi8viepU66XSz1,const size_t ex_FDTDXUQhgm_eYmdJ8sNRVZ,const size_t
ex_VlNl_tKLFzxvYHI0dZ9wzf,const size_t ex_kiGZSX33fPpmaucBO5il15,const size_t
ex__1tnMVPyaKpZeawGCX2ExG,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF,const real_T ex__yrlSbVOXjWXaTMEdN9cIu,const real_T
ex_F1sFV5GwlJdShuwH_gb9cU);size_t ex_F0HBEJ7qD9OkfDK6FdP9lf(real_T*H,real_T*Hx
,real_T*G,real_T*Gx,size_t*numEdges,const real_T*x,const size_t n,const real_T
t,const boolean_T*mode,const real_T ex_F_tm5fod4xxuguhS49BSQm,const boolean_T
ex_kMAXUIgm88xvaunhJ2st8X);size_t ex_VzC4wVDNwRO2VyQZ1TOBFP(real_T*H,real_T*G,
size_t*numEdges,const real_T*x,const size_t n,const real_T t,const boolean_T*
mode,const boolean_T ex_V0dauSHHy5d6_D42s3Aeag);
#include "lang_std.h"
void tlu2_linear_linear_prelookup(real_T*H,real_T*G,size_t*numEdges,size_t*bin
,const real_T*x,const real_T*t,const boolean_T*mode,const size_t*n){*bin=
ex_VzC4wVDNwRO2VyQZ1TOBFP(H,G,numEdges,x,*n,*t,mode,true);}void
tlu2_linear_linear_prelookup_custom_function_(void*out,const void*in){const
real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(const real_T
*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T*)((const
void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*)in)[3];
real_T*H=(real_T*)((void**)out)[0];real_T*G=(real_T*)((void**)out)[1];size_t*
numEdges=(size_t*)((void**)out)[2];size_t*bin=(size_t*)((void**)out)[3];
tlu2_linear_linear_prelookup(H,G,numEdges,bin,x,t,mode,n);}void
tlu2_linear_nearest_prelookup(real_T*H,real_T*G,size_t*numEdges,size_t*bin,
const real_T*x,const real_T*t,const boolean_T*mode,const size_t*n){*bin=
ex_VzC4wVDNwRO2VyQZ1TOBFP(H,G,numEdges,x,*n,*t,mode,false);}void
tlu2_linear_nearest_prelookup_custom_function_(void*out,const void*in){const
real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(const real_T
*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T*)((const
void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*)in)[3];
real_T*H=(real_T*)((void**)out)[0];real_T*G=(real_T*)((void**)out)[1];size_t*
numEdges=(size_t*)((void**)out)[2];size_t*bin=(size_t*)((void**)out)[3];
tlu2_linear_nearest_prelookup(H,G,numEdges,bin,x,t,mode,n);}void
tlu2_akima_linear_prelookup(real_T*H,real_T*Hx,real_T*G,real_T*Gx,size_t*
numEdges,size_t*bin,const real_T*x,const real_T*t,const boolean_T*mode,const
size_t*n){*bin=ex_F0HBEJ7qD9OkfDK6FdP9lf(H,Hx,G,Gx,numEdges,x,*n,*t,mode,1.0,
true);}void tlu2_akima_linear_prelookup_custom_function_(void*out,const void*
in){const real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(
const real_T*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T
*)((const void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*
)in)[3];real_T*H=(real_T*)((void**)out)[0];real_T*Hx=(real_T*)((void**)out)[1]
;real_T*G=(real_T*)((void**)out)[2];real_T*Gx=(real_T*)((void**)out)[3];size_t
*numEdges=(size_t*)((void**)out)[4];size_t*bin=(size_t*)((void**)out)[5];
tlu2_akima_linear_prelookup(H,Hx,G,Gx,numEdges,bin,x,t,mode,n);}void
tlu2_akima_nearest_prelookup(real_T*H,real_T*Hx,real_T*G,real_T*Gx,size_t*
numEdges,size_t*bin,const real_T*x,const real_T*t,const boolean_T*mode,const
size_t*n){*bin=ex_F0HBEJ7qD9OkfDK6FdP9lf(H,Hx,G,Gx,numEdges,x,*n,*t,mode,0.0,
true);}void tlu2_akima_nearest_prelookup_custom_function_(void*out,const void*
in){const real_T*x=(const real_T*)((const void*const*)in)[0];const real_T*t=(
const real_T*)((const void*const*)in)[1];const boolean_T*mode=(const boolean_T
*)((const void*const*)in)[2];const size_t*n=(const size_t*)((const void*const*
)in)[3];real_T*H=(real_T*)((void**)out)[0];real_T*Hx=(real_T*)((void**)out)[1]
;real_T*G=(real_T*)((void**)out)[2];real_T*Gx=(real_T*)((void**)out)[3];size_t
*numEdges=(size_t*)((void**)out)[4];size_t*bin=(size_t*)((void**)out)[5];
tlu2_akima_nearest_prelookup(H,Hx,G,Gx,numEdges,bin,x,t,mode,n);}
