/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#ifndef struct__DifferentialClumpTag
#define struct__DifferentialClumpTag

typedef struct _DifferentialClumpTag {
  DifferentialClump mBase;
  int32_T mRefCnt;
  PmAllocator mAlloc;
} _DifferentialClump;

#else

typedef struct _DifferentialClumpTag _DifferentialClump;

#endif
