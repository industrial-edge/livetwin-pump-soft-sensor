/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "ssc_ml_fun.h"
#include "pump_soft_sensor_3d73c5c7_0_external_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_1.h"
#include "pump_soft_sensor_3d73c5c7_0_dc.h"

static void sls_destroy(SwitchedLinearSystem *sls)
{
  (void) sls;
}

SwitchedLinearSystem *pump_soft_sensor_3d73c5c7_0(PmAllocator *allocator)
{
  static PmIntVector diff_indices = { 0U, NULL };

  static NeDynamicSystemInputSizes sizes = { { 0U, 27U, 1U, 1U, 0U, 4U, 0U, 0U,
      0U, 0U, 0U, 1U, 0U, 0U, 0U, 43U, 6U, 0U, 0U, 105U, } };

  static SwitchedLinearClump *clumps[2U];
  static SwitchedLinearSystem sls;
  static NeModelParameters modelparams;
  static NeSolverParameters solverparams;
  solverparams = *( ((NeSolverParameters **) allocator)[0]);
  modelparams = *((NeModelParameters *) ( ((NeSolverParameters **) allocator)[1]));
  sls.mSizes = sizes;
  sls.mDiffStateIndices = &diff_indices;
  sls.mGlobalMethodTable = pump_soft_sensor_3d73c5c7_0_gmt(NULL);
  sls.mNumClumps = 2U;
  sls.mClumps = clumps;
  sls.mClumps[0U] = pump_soft_sensor_3d73c5c7_0_slc_0(NULL);
  sls.mClumps[1U] = pump_soft_sensor_3d73c5c7_0_slc_1(NULL);
  sls.mDiffClump = pump_soft_sensor_3d73c5c7_0_dc(NULL);
  sls.mIniter = NULL;
  sls.mDestroy = sls_destroy;
  return &sls;
}
