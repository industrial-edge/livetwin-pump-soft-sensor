/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_dp_l.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_assert.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_dp_r.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_obs.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_mode.h"
#include "ssc_ml_fun.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_external_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_externals.h"

static int32_T gmt_y(const GlobalMethodTable *ds, const NeDynamicSystemInput *in,
                     GmtMethodOutput *out);
static int32_T gmt_iassert(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
static int32_T gmt_init_r(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
static int32_T gmt_init_i(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
static int32_T gmt_cache_r(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
static int32_T gmt_cache_i(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
static int32_T gmt_update_r(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
static int32_T gmt_update_i(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
static int32_T gmt_dp_i(const GlobalMethodTable *ds, const NeDynamicSystemInput *
  in, GmtMethodOutput *out);
static int32_T gmt_dp_j(const GlobalMethodTable *ds, const NeDynamicSystemInput *
  in, GmtMethodOutput *out);
static int32_T gmt_init_diff(const GlobalMethodTable *ds, const
  NeDynamicSystemInput *in, GmtMethodOutput *out);
GlobalMethodTable *pump_soft_sensor_3d73c5c7_0_gmt(PmAllocator *allocator)
{
  static NeAssertData assert_data[92] = { {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 0U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE,
      "Inconsistent mask parameters. Internal diameter must be greater than zero.",
      "simscape:GreaterThanZero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 1U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE,
      "Inconsistent mask parameters. Pipe length must be greater than zero.",
      "simscape:GreaterThanZero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 2U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE,
      "Inconsistent mask parameters. Internal diameter must be greater than zero.",
      "simscape:GreaterThanZero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 3U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE,
      "Inconsistent mask parameters. Pipe length must be greater than zero.",
      "simscape:GreaterThanZero", }, { "pump_soft_sensor/pump", 2U, 4U,
      "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      FALSE, "Reference angular velocity must be greater than zero.",
      "physmod:simscape:compiler:patterns:checks:GreaterThanZero", }, {
      "pump_soft_sensor/pump", 2U, 6U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      FALSE, "Reference density must be greater than zero.",
      "physmod:simscape:compiler:patterns:checks:GreaterThanZero", }, {
      "pump_soft_sensor/pump", 2U, 8U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      FALSE,
      "Pump delivery vector for Pressure differential must be arranged in strictly ascending order.",
      "physmod:simscape:compiler:patterns:checks:StrictlyAscendingVec", }, {
      "pump_soft_sensor/pump", 2U, 10U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      FALSE,
      "Pump delivery vector for Brake power must be arranged in strictly ascending order.",
      "physmod:simscape:compiler:patterns:checks:StrictlyAscendingVec", }, {
      "pump_soft_sensor/pump", 2U, 12U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      FALSE,
      "Angular speed threshold for flow reversal must be greater than zero.",
      "physmod:simscape:compiler:patterns:checks:GreaterThanZero", }, {
      "pump_soft_sensor/pump", 1U, 14U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "The values in the table grid vector are not strictly monotonic",
      "physmod:common:data2:library:tlu:Nonmotonic", }, {
      "pump_soft_sensor/pump", 1U, 15U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "The values in the table must be finite( no nan or inf allowed )",
      "physmod:common:data2:library:tlu:Nonfinite", }, { "pump_soft_sensor/pump",
      1U, 16U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "The values in the table must be finite( no nan or inf allowed )",
      "physmod:common:data2:library:tlu:Nonfinite", }, { "pump_soft_sensor/pump",
      1U, 17U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "The values in the table grid vector are not strictly monotonic",
      "physmod:common:data2:library:tlu:Nonmotonic", }, {
      "pump_soft_sensor/pump", 1U, 18U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "The values in the table must be finite( no nan or inf allowed )",
      "physmod:common:data2:library:tlu:Nonfinite", }, { "pump_soft_sensor/pump",
      1U, 19U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "The values in the table must be finite( no nan or inf allowed )",
      "physmod:common:data2:library:tlu:Nonfinite", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 20U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 21U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 22U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 23U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 24U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 25U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 26U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 27U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 28U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 29U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 30U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 31U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 32U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 33U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 34U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 35U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "Argument of log10 must be positive.",
      "physmod:common:mf:core:asserts:RequireArgumentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 36U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 37U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 38U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 39U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 40U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 41U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 42U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 43U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 44U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 45U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 46U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 47U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 48U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 49U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 50U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 51U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/suction side pipe", 1U, 52U,
      "hydraulic_systems.suction_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 53U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/pump", 1U, 54U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 55U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/pump", 1U, 56U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 57U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "Argument of sqrt must be nonnegative.",
      "physmod:common:mf:core:asserts:RequireArgumentNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 58U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/pump", 1U, 59U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 60U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/pump", 1U, 61U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 62U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "Argument of sqrt must be nonnegative.",
      "physmod:common:mf:core:asserts:RequireArgumentNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 63U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/pump", 1U, 64U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/pump", 1U, 65U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/pump", 1U, 66U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 67U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/pump", 1U, 68U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/pump", 1U, 69U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 70U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/pump", 1U, 71U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/pump", 1U, 72U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/pump", 1U, 73U, "pump.pump_model",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 74U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 75U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 76U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 77U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 78U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 79U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "Argument of log10 must be positive.",
      "physmod:common:mf:core:asserts:RequireArgumentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 80U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 81U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 82U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 83U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 84U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 85U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 86U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 87U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 88U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 89U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 90U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 91U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 92U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      FALSE, "In divide, the denominator must be nonzero.",
      "physmod:common:mf:core:asserts:RequireDenominatorNonzero", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 93U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 94U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 95U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the exponent should be positive when the base is equal to zero. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireExponentPositive", }, {
      "pump_soft_sensor/hydraulic systems/pressure side pipe", 1U, 96U,
      "hydraulic_systems.pressure_side_pipe",
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      TRUE,
      "In power, the base should be nonnegative when the exponent is not an integer. This may become error in future releases.",
      "physmod:common:mf:core:asserts:RequireBaseNonnegative", } };

  static NeRange assert_ranges[97] = { {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+pumps_motors/centrifugal_pump_tab1d.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, }, {
      "C:/Program Files/MATLAB/R2019b/toolbox/physmod/sh/sh/+sh/+low_pressure_blocks/pipe_res_low_press.sscp",
      1U, 1U, 1U, 1U, NE_RANGE_TYPE_PROTECTED, } };

  static NeAssertData *initial_assert_data = NULL;
  static NeRange *initial_assert_ranges = NULL;
  static NeParameterVector paramInfo_logicals = { 0U, NULL };

  static NeParameterVector paramInfo_integers = { 0U, NULL };

  static NeParameterVector paramInfo_indices = { 0U, NULL };

  static NeParameterData paramInfo_reals_[43] = { {
      "Angular_speed_treshold_for_flow_reversal", "", "", 0U, 1U, }, {
      "Reference_angular_velocity", "", "", 0U, 1U, }, { "Reference_density", "",
      "", 0U, 1U, }, { "pressure_pipe_internal_diameter", "", "", 0U, 1U, }, {
      "pressure_pipe_inlet_heigth", "", "", 0U, 1U, }, {
      "pressure_pipe_outlet_heigth", "", "", 0U, 1U, }, { "pressure_pipe_length",
      "", "", 0U, 1U, }, { "suction_pipe_internal_diameter", "", "", 0U, 1U, },
      { "suction_pipe_inlet_heigth", "", "", 0U, 1U, }, {
      "suction_pipe_outlet_heigth", "", "", 0U, 1U, }, { "suction_pipe_length",
      "", "", 0U, 1U, }, { "pump_delivery_vector_pressure_differential", "", "",
      0U, 8U, }, { "pump_delivery_vector_pressure_differential", "", "", 1U, 8U,
    }, { "pump_delivery_vector_pressure_differential", "", "", 2U, 8U, }, {
      "pump_delivery_vector_pressure_differential", "", "", 3U, 8U, }, {
      "pump_delivery_vector_pressure_differential", "", "", 4U, 8U, }, {
      "pump_delivery_vector_pressure_differential", "", "", 5U, 8U, }, {
      "pump_delivery_vector_pressure_differential", "", "", 6U, 8U, }, {
      "pump_delivery_vector_pressure_differential", "", "", 7U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 0U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 1U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 2U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 3U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 4U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 5U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 6U, 8U, }, {
      "pump_delivery_vector_brake_power", "", "", 7U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 0U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 1U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 2U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 3U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 4U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 5U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 6U, 8U, }, {
      "pump_pressure_differential_vector", "", "", 7U, 8U, }, {
      "pump_brake_power_vector", "", "", 0U, 8U, }, { "pump_brake_power_vector",
      "", "", 1U, 8U, }, { "pump_brake_power_vector", "", "", 2U, 8U, }, {
      "pump_brake_power_vector", "", "", 3U, 8U, }, { "pump_brake_power_vector",
      "", "", 4U, 8U, }, { "pump_brake_power_vector", "", "", 5U, 8U, }, {
      "pump_brake_power_vector", "", "", 6U, 8U, }, { "pump_brake_power_vector",
      "", "", 7U, 8U, } };

  static NeParameterVector paramInfo_reals = { 43U, paramInfo_reals_ };

  static int32_T mode_indices_[7] = { 9, 13, 10, 11, 15, 25, 14 };

  static PmIntVector mode_indices = { 7U, mode_indices_ };

  static int32_T obs_is_linear_[43] = { 1, 1, 1, 0, 0, 1, 0, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1,
    1, 1, 0 };

  static PmIntVector obs_is_linear = { 43U, obs_is_linear_ };

  static GlobalMethodTable gmt;
  (void) allocator;
  gmt.mMethods[GMT_METHOD_MODE] = pump_soft_sensor_3d73c5c7_0_gmt_mode;
  gmt.mMethods[GMT_METHOD_Y] = gmt_y;
  gmt.mMethods[GMT_METHOD_OBS] = pump_soft_sensor_3d73c5c7_0_gmt_obs;
  gmt.mMethods[GMT_METHOD_ASSERT] = pump_soft_sensor_3d73c5c7_0_gmt_assert;
  gmt.mMethods[GMT_METHOD_IASSERT] = gmt_iassert;
  gmt.mMethods[GMT_METHOD_INIT_R] = gmt_init_r;
  gmt.mMethods[GMT_METHOD_INIT_I] = gmt_init_i;
  gmt.mMethods[GMT_METHOD_CACHE_R] = gmt_cache_r;
  gmt.mMethods[GMT_METHOD_CACHE_I] = gmt_cache_i;
  gmt.mMethods[GMT_METHOD_UPDATE_R] = gmt_update_r;
  gmt.mMethods[GMT_METHOD_UPDATE_I] = gmt_update_i;
  gmt.mMethods[GMT_METHOD_DP_L] = pump_soft_sensor_3d73c5c7_0_gmt_dp_l;
  gmt.mMethods[GMT_METHOD_DP_I] = gmt_dp_i;
  gmt.mMethods[GMT_METHOD_DP_J] = gmt_dp_j;
  gmt.mMethods[GMT_METHOD_DP_R] = pump_soft_sensor_3d73c5c7_0_gmt_dp_r;
  gmt.mMethods[GMT_METHOD_INIT_DIFF] = gmt_init_diff;
  gmt.mNumY = 3U;
  gmt.mNumAsserts = 92U;
  gmt.mAssertData = assert_data;
  gmt.mNumAssertRanges = 97U;
  gmt.mAssertRanges = assert_ranges;
  gmt.mNumInitialAsserts = 0U;
  gmt.mInitialAssertData = initial_assert_data;
  gmt.mNumInitialAssertRanges = 0U;
  gmt.mInitialAssertRanges = initial_assert_ranges;
  gmt.mParameterInfo.mLogicals = paramInfo_logicals;
  gmt.mParameterInfo.mIntegers = paramInfo_integers;
  gmt.mParameterInfo.mIndices = paramInfo_indices;
  gmt.mParameterInfo.mReals = paramInfo_reals;
  gmt.mModeIndices = &mode_indices;
  gmt.mObsIsLinear = &obs_is_linear;
  return &gmt;
}

static int32_T gmt_y (const GlobalMethodTable *sys, const NeDynamicSystemInput
                      *t2, GmtMethodOutput *t3)
{
  PmRealVector out;
  real_T X_idx_1;
  real_T X_idx_2;
  real_T X_idx_3;
  X_idx_1 = t2->mX.mX[1];
  X_idx_2 = t2->mX.mX[2];
  X_idx_3 = t2->mX.mX[3];
  out = t3->mY;
  X_idx_3 *= 0.00099779981710000024;
  out.mX[0] = X_idx_3;
  out.mX[1] = X_idx_3 * 0.0010022050343789343;
  out.mX[2] = -((-X_idx_1 + X_idx_2) - (-X_idx_1)) / -1.0 * 99999.999999999985;
  (void)sys;
  (void)t3;
  return 0;
}

static int32_T gmt_iassert (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_dp_i (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_dp_j (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_init_r (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_init_i (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_cache_r (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_cache_i (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_update_r (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_update_i (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T gmt_init_diff (const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}
