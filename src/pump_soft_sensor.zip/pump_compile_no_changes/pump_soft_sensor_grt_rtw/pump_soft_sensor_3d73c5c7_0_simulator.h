/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#ifndef __pump_soft_sensor_3d73c5c7_0_simulator_h__
#define __pump_soft_sensor_3d73c5c7_0_simulator_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern const Simulator *pump_soft_sensor_3d73c5c7_0_simulator_create(void);
  extern void pump_soft_sensor_3d73c5c7_0_simulator_destroy(void);

#ifdef __cplusplus

}
#endif
#endif                 /* #ifndef __pump_soft_sensor_3d73c5c7_0_simulator_h__ */
