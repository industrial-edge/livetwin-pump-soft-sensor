/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_j.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_sys_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_external_struct.h"
#include "ssc_ml_fun.h"

int32_T pump_soft_sensor_3d73c5c7_0_slc_0_j(const SwitchedLinearClump *sys,
  const NeDynamicSystemInput *t118, SlcMethodOutput *t119)
{
  PmRealVector out;
  real_T zc_int15;
  real_T intermediate_der15;
  real_T intermediate_der18;
  real_T t4[8];
  boolean_T t5[2];
  real_T t9[1];
  size_t t15;
  real_T t28;
  real_T t31;
  real_T t32;
  real_T t34;
  real_T t35;
  real_T t36;
  real_T t38;
  real_T t39;
  real_T t40;
  real_T t42;
  real_T t54;
  real_T t58;
  real_T t62;
  real_T t68;
  real_T t95;
  real_T t97;
  real_T t101;
  real_T t105;
  real_T t110;
  real_T t113;
  real_T t115;
  real_T DP_R[33];
  ETTS0 efOut;
  real_T b_efOut[1];
  real_T U_idx_0;
  real_T X_idx_2;
  int32_T M_idx_9;
  int32_T M_idx_17;
  int32_T M_idx_15;
  int32_T M_idx_16;
  int32_T M_idx_18;
  int32_T M_idx_19;
  int32_T M_idx_0;
  int32_T M_idx_1;
  int32_T M_idx_14;
  int32_T M_idx_20;
  int32_T M_idx_2;
  M_idx_0 = t118->mM.mX[0];
  M_idx_1 = t118->mM.mX[1];
  M_idx_2 = t118->mM.mX[2];
  M_idx_9 = t118->mM.mX[9];
  M_idx_14 = t118->mM.mX[14];
  M_idx_15 = t118->mM.mX[15];
  M_idx_16 = t118->mM.mX[16];
  M_idx_17 = t118->mM.mX[17];
  M_idx_18 = t118->mM.mX[18];
  M_idx_19 = t118->mM.mX[19];
  M_idx_20 = t118->mM.mX[20];
  U_idx_0 = t118->mU.mX[0];
  X_idx_2 = t118->mX.mX[2];
  DP_R[0] = t118->mDP_R.mX[0];
  DP_R[1] = t118->mDP_R.mX[1];
  DP_R[2] = t118->mDP_R.mX[2];
  DP_R[3] = t118->mDP_R.mX[3];
  DP_R[4] = t118->mDP_R.mX[4];
  DP_R[5] = t118->mDP_R.mX[5];
  DP_R[6] = t118->mDP_R.mX[6];
  DP_R[7] = t118->mDP_R.mX[7];
  DP_R[8] = t118->mDP_R.mX[8];
  DP_R[9] = t118->mDP_R.mX[9];
  DP_R[10] = t118->mDP_R.mX[10];
  DP_R[11] = t118->mDP_R.mX[11];
  DP_R[12] = t118->mDP_R.mX[12];
  DP_R[13] = t118->mDP_R.mX[13];
  DP_R[14] = t118->mDP_R.mX[14];
  DP_R[15] = t118->mDP_R.mX[15];
  DP_R[16] = t118->mDP_R.mX[16];
  DP_R[17] = t118->mDP_R.mX[17];
  DP_R[18] = t118->mDP_R.mX[18];
  DP_R[19] = t118->mDP_R.mX[19];
  DP_R[20] = t118->mDP_R.mX[20];
  DP_R[21] = t118->mDP_R.mX[21];
  DP_R[22] = t118->mDP_R.mX[22];
  DP_R[23] = t118->mDP_R.mX[23];
  DP_R[24] = t118->mDP_R.mX[24];
  DP_R[25] = t118->mDP_R.mX[25];
  DP_R[26] = t118->mDP_R.mX[26];
  DP_R[27] = t118->mDP_R.mX[27];
  DP_R[28] = t118->mDP_R.mX[28];
  DP_R[29] = t118->mDP_R.mX[29];
  DP_R[30] = t118->mDP_R.mX[30];
  DP_R[31] = t118->mDP_R.mX[31];
  DP_R[32] = t118->mDP_R.mX[32];
  out = t119->mJ;
  intermediate_der18 = X_idx_2 * 0.00099779981710000024;
  t31 = DP_R[5ULL] * 6.4361463199777107E-5;
  t32 = DP_R[4ULL] * DP_R[4ULL];
  t28 = t31 / (t32 == 0.0 ? 1.0E-16 : t32) / (DP_R[3ULL] == 0.0 ? 1.0E-16 :
    DP_R[3ULL]) / 2.0 * X_idx_2 * 997.7998171;
  t36 = DP_R[10ULL] * 0.10471975511965977;
  t35 = U_idx_0 / (t36 == 0.0 ? 1.0E-16 : t36) * (U_idx_0 / (t36 == 0.0 ?
    1.0E-16 : t36)) * 997.7998171 / (DP_R[11ULL] == 0.0 ? 1.0E-16 : DP_R[11ULL]);
  t40 = DP_R[2ULL] * 6.4361463199777107E-5;
  t95 = DP_R[1ULL] * DP_R[1ULL];
  t38 = t40 / (t95 == 0.0 ? 1.0E-16 : t95) / (DP_R[0ULL] == 0.0 ? 1.0E-16 :
    DP_R[0ULL]) / 2.0 * intermediate_der18 * 999999.99999999977;
  t39 = M_idx_9 != 0 ? 1.0 : -1.0;
  t42 = intermediate_der18 * DP_R[1ULL] * t39 * 1002.2050343789342 / (DP_R[0ULL]
    == 0.0 ? 1.0E-16 : DP_R[0ULL]) / 1.0056478624965173E-6;
  intermediate_der15 = M_idx_17 != 0 ? 1.0 : -1.0;
  t113 = DP_R[4ULL] * X_idx_2 * intermediate_der15 / (DP_R[3ULL] == 0.0 ?
    1.0E-16 : DP_R[3ULL]) / 1.0056478624965173E-6;
  t110 = (t113 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_15 != 0) {
    t115 = 0.0;
  } else if (M_idx_16 != 0) {
    t115 = t110 * t110 * 3.0 - t110 * t110 * t110 * 2.0;
  } else {
    t115 = 1.0;
  }

  if (M_idx_18 != 0) {
    t54 = 0.0;
  } else {
    t54 = pmf_log10(6.9 / (t113 == 0.0 ? 1.0E-16 : t113) * 999999.99999999988 +
                    pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t113 ==
      0.0 ? 1.0E-16 : t113) * 999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7,
      1.11)) * 3.24;
    t54 = 1.0 / (t54 == 0.0 ? 1.0E-16 : t54);
  }

  t97 = DP_R[5ULL] * t54;
  t58 = DP_R[3ULL] * DP_R[3ULL];
  if (M_idx_19 != 0) {
    t101 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[9ULL] * DP_R[9ULL]);
  } else {
    t101 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[9ULL] * DP_R[9ULL]);
  }

  zc_int15 = t36 / (t101 == 0.0 ? 1.0E-16 : t101);
  t101 = (t42 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_0 != 0) {
    t36 = 0.0;
  } else if (M_idx_1 != 0) {
    t36 = t101 * t101 * 3.0 - t101 * t101 * t101 * 2.0;
  } else {
    t36 = 1.0;
  }

  if (M_idx_14 != 0) {
    t54 = 0.0;
  } else {
    t54 = pmf_log10(6.9 / (t42 == 0.0 ? 1.0E-16 : t42) * 999999.99999999988 +
                    pmf_pow(DP_R[28ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t42 ==
      0.0 ? 1.0E-16 : t42) * 999999.99999999988 + pmf_pow(DP_R[28ULL] / 3.7,
      1.11)) * 3.24;
    t54 = 1.0 / (t54 == 0.0 ? 1.0E-16 : t54);
  }

  t62 = DP_R[2ULL] * t54;
  t68 = DP_R[0ULL] * DP_R[0ULL];
  t31 = t31 / (t32 == 0.0 ? 1.0E-16 : t32) / (DP_R[3ULL] == 0.0 ? 1.0E-16 :
    DP_R[3ULL]) / 2.0 * 997.7998171;
  t32 = t40 / (t95 == 0.0 ? 1.0E-16 : t95) / (DP_R[0ULL] == 0.0 ? 1.0E-16 :
    DP_R[0ULL]) / 2.0 * 0.00099779981710000024 * 999999.99999999977;
  t40 = 1.0 / (DP_R[0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) * DP_R[1ULL] *
    0.00099779981710000024 * t39 * 9.9657650729845309E+8;
  t95 = 1.0 / (DP_R[3ULL] == 0.0 ? 1.0E-16 : DP_R[3ULL]) * DP_R[4ULL] *
    intermediate_der15 * 994383.8567085535;
  t34 = t95 * 5.0000000000000013E-10;
  if (M_idx_15 != 0) {
    t105 = 0.0;
  } else if (M_idx_16 != 0) {
    t105 = t34 * t110 * 6.0 - t110 * t110 * t34 * 6.0;
  } else {
    t105 = 0.0;
  }

  if (M_idx_18 != 0) {
    t110 = 0.0;
  } else {
    t34 = (6.9 / (t113 == 0.0 ? 1.0E-16 : t113) * 999999.99999999988 + pmf_pow
           (DP_R[7ULL] / 3.7, 1.11)) * 2.3025850929940459;
    t54 = pmf_log10(6.9 / (t113 == 0.0 ? 1.0E-16 : t113) * 999999.99999999988 +
                    pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t113 ==
      0.0 ? 1.0E-16 : t113) * 999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7,
      1.11)) * pmf_log10(6.9 / (t113 == 0.0 ? 1.0E-16 : t113) *
                         999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7, 1.11)) *
      pmf_log10(6.9 / (t113 == 0.0 ? 1.0E-16 : t113) * 999999.99999999988 +
                pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * 10.497600000000002;
    U_idx_0 = t113 * t113;
    t110 = -1.0 / (t54 == 0.0 ? 1.0E-16 : t54) * (-6.9 / (U_idx_0 == 0.0 ?
      1.0E-16 : U_idx_0)) * (1.0 / (t34 == 0.0 ? 1.0E-16 : t34)) * pmf_log10(6.9
      / (t113 == 0.0 ? 1.0E-16 : t113) * 999999.99999999988 + pmf_pow(DP_R[7ULL]
      / 3.7, 1.11)) * t95 * 6.4799999999999991E+6;
  }

  t113 = ((1.0 / (t58 == 0.0 ? 1.0E-16 : t58) * (1.0 / (DP_R[4ULL] == 0.0 ?
             1.0E-16 : DP_R[4ULL])) * X_idx_2 * DP_R[5ULL] * t110 * 498.89990855
           + t97 / (DP_R[4ULL] == 0.0 ? 1.0E-16 : DP_R[4ULL]) / (t58 == 0.0 ?
            1.0E-16 : t58) / 2.0 * 997.7998171) * X_idx_2 + t97 / (DP_R[4ULL] ==
           0.0 ? 1.0E-16 : DP_R[4ULL]) / (t58 == 0.0 ? 1.0E-16 : t58) / 2.0 *
          X_idx_2 * 997.7998171) * intermediate_der15;
  if (M_idx_15 != 0) {
    t54 = t31 * 1.0000000000000001E-11;
  } else if (M_idx_16 != 0) {
    t54 = (t31 * 1.0000000000000001E-11 + (t97 / (DP_R[4ULL] == 0.0 ? 1.0E-16 :
             DP_R[4ULL]) / (t58 == 0.0 ? 1.0E-16 : t58) / 2.0 * X_idx_2 *
            X_idx_2 * intermediate_der15 * 997.7998171 * 1.0000000000000002E-17
            - t28 * 1.0000000000000001E-11) * t105) + (t113 *
      1.0000000000000002E-17 - t31 * 1.0000000000000001E-11) * t115;
  } else {
    t54 = t113 * 1.0000000000000002E-17;
  }

  t28 = t40 * 5.0000000000000013E-10;
  if (M_idx_0 != 0) {
    intermediate_der15 = 0.0;
  } else if (M_idx_1 != 0) {
    intermediate_der15 = t28 * t101 * 6.0 - t101 * t101 * t28 * 6.0;
  } else {
    intermediate_der15 = 0.0;
  }

  if (M_idx_14 != 0) {
    t28 = 0.0;
  } else {
    t113 = (6.9 / (t42 == 0.0 ? 1.0E-16 : t42) * 999999.99999999988 + pmf_pow
            (DP_R[28ULL] / 3.7, 1.11)) * 2.3025850929940459;
    t95 = pmf_log10(6.9 / (t42 == 0.0 ? 1.0E-16 : t42) * 999999.99999999988 +
                    pmf_pow(DP_R[28ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t42 ==
      0.0 ? 1.0E-16 : t42) * 999999.99999999988 + pmf_pow(DP_R[28ULL] / 3.7,
      1.11)) * pmf_log10(6.9 / (t42 == 0.0 ? 1.0E-16 : t42) * 999999.99999999988
                         + pmf_pow(DP_R[28ULL] / 3.7, 1.11)) * pmf_log10(6.9 /
      (t42 == 0.0 ? 1.0E-16 : t42) * 999999.99999999988 + pmf_pow(DP_R[28ULL] /
      3.7, 1.11)) * 10.497600000000002;
    t34 = t42 * t42;
    t28 = -1.0 / (t95 == 0.0 ? 1.0E-16 : t95) * (-6.9 / (t34 == 0.0 ? 1.0E-16 :
      t34)) * (1.0 / (t113 == 0.0 ? 1.0E-16 : t113)) * pmf_log10(6.9 / (t42 ==
      0.0 ? 1.0E-16 : t42) * 999999.99999999988 + pmf_pow(DP_R[28ULL] / 3.7,
      1.11)) * t40 * 6.4799999999999991E+6;
  }

  t42 = ((1.0 / (t68 == 0.0 ? 1.0E-16 : t68) * (1.0 / (DP_R[1ULL] == 0.0 ?
            1.0E-16 : DP_R[1ULL])) * intermediate_der18 * DP_R[2ULL] * t28 *
          499999.99999999988 + t62 / (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) /
          (t68 == 0.0 ? 1.0E-16 : t68) / 2.0 * 0.00099779981710000024 *
          999999.99999999977) * intermediate_der18 * 1002.2050343789342 + t62 /
         (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) / (t68 == 0.0 ? 1.0E-16 :
          t68) / 2.0 * intermediate_der18 * 0.00099779981710000024 *
         1.002205034378934E+9) * t39;
  if (M_idx_0 != 0) {
    intermediate_der18 = t32 * 1.0000000000000001E-11;
  } else if (M_idx_1 != 0) {
    intermediate_der18 = (t32 * 1.0000000000000001E-11 + (t62 / (DP_R[1ULL] ==
      0.0 ? 1.0E-16 : DP_R[1ULL]) / (t68 == 0.0 ? 1.0E-16 : t68) / 2.0 *
      intermediate_der18 * intermediate_der18 * t39 * 1.002205034378934E+9 *
      1.0000000000000002E-17 - t38 * 1.0000000000000001E-11) *
                          intermediate_der15) + (t42 * 1.0000000000000002E-17 -
      t32 * 1.0000000000000001E-11) * t36;
  } else {
    intermediate_der18 = t42 * 1.0000000000000002E-17;
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15] = DP_R[t15 + 12ULL];
  }

  t9[0ULL] = zc_int15 * X_idx_2;
  t5[0ULL] = (M_idx_20 != 0);
  t5[1ULL] = (M_idx_2 != 0);
  t15 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)&efOut.mField3, (void *)t4, (void *)t9,
    (void *)t5, (void *)&t15);
  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15] = DP_R[t15 + 20ULL];
  }

  t5[0ULL] = (M_idx_20 != 0);
  t5[1ULL] = (M_idx_2 != 0);
  t15 = 8ULL;
  tlu2_1d_linear_linear_derivatives((void *)&b_efOut, (void *)efOut.mField0,
    (void *)efOut.mField1, (void *)efOut.mField2, (void *)efOut.mField3, (void *)
    t4, (void *)t5, (void *)&t15);
  out.mX[0] = 1.0;
  out.mX[1] = -1.0;
  out.mX[2] = 1.0;
  out.mX[3] = 1.0;
  out.mX[4] = -t54;
  out.mX[5] = -(b_efOut[0] * zc_int15 * t35);
  out.mX[6] = -intermediate_der18;
  (void)sys;
  (void)t119;
  return 0;
}
