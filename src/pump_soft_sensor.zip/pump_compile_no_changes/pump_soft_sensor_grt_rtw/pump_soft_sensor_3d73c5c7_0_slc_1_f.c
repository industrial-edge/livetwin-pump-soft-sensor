/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_1_f.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_1_sys_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_1_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_1_external_struct.h"
#include "ssc_ml_fun.h"

int32_T pump_soft_sensor_3d73c5c7_0_slc_1_f(const SwitchedLinearClump *sys,
  const NeDynamicSystemInput *t17, SlcMethodOutput *t18)
{
  PmRealVector out;
  real_T t4[8];
  boolean_T t5[2];
  real_T t6[1];
  size_t t9;
  real_T t10;
  real_T t11;
  real_T DP_R[21];
  ETTS0 efOut;
  real_T b_efOut[1];
  real_T U_idx_0;
  int32_T M_idx_2;
  real_T X_idx_1;
  int32_T M_idx_0;
  int32_T M_idx_1;
  M_idx_0 = t17->mM.mX[0];
  M_idx_1 = t17->mM.mX[1];
  M_idx_2 = t17->mM.mX[2];
  U_idx_0 = t17->mU.mX[0];
  X_idx_1 = t17->mX.mX[1];
  DP_R[0] = t17->mDP_R.mX[0];
  DP_R[1] = t17->mDP_R.mX[1];
  DP_R[2] = t17->mDP_R.mX[2];
  DP_R[3] = t17->mDP_R.mX[3];
  DP_R[4] = t17->mDP_R.mX[4];
  DP_R[5] = t17->mDP_R.mX[5];
  DP_R[6] = t17->mDP_R.mX[6];
  DP_R[7] = t17->mDP_R.mX[7];
  DP_R[8] = t17->mDP_R.mX[8];
  DP_R[9] = t17->mDP_R.mX[9];
  DP_R[10] = t17->mDP_R.mX[10];
  DP_R[11] = t17->mDP_R.mX[11];
  DP_R[12] = t17->mDP_R.mX[12];
  DP_R[13] = t17->mDP_R.mX[13];
  DP_R[14] = t17->mDP_R.mX[14];
  DP_R[15] = t17->mDP_R.mX[15];
  DP_R[16] = t17->mDP_R.mX[16];
  DP_R[17] = t17->mDP_R.mX[17];
  DP_R[18] = t17->mDP_R.mX[18];
  DP_R[19] = t17->mDP_R.mX[19];
  DP_R[20] = t17->mDP_R.mX[20];
  out = t18->mF;
  t11 = DP_R[1ULL] * DP_R[1ULL] * DP_R[1ULL] * 0.001148380617788882;
  t10 = U_idx_0 * U_idx_0 / (t11 == 0.0 ? 1.0E-16 : t11) * 997.7998171 / (DP_R
    [2ULL] == 0.0 ? 1.0E-16 : DP_R[2ULL]);
  if (M_idx_2 != 0) {
    t11 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[0ULL] * DP_R[0ULL]);
  } else {
    t11 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[0ULL] * DP_R[0ULL]);
  }

  for (t9 = 0ULL; t9 < 8ULL; t9++) {
    t4[t9] = DP_R[t9 + 3ULL];
  }

  t6[0ULL] = DP_R[1ULL] * 0.10471975511965977 / (t11 == 0.0 ? 1.0E-16 : t11) *
    X_idx_1;
  t5[0ULL] = (M_idx_0 != 0);
  t5[1ULL] = (M_idx_1 != 0);
  t9 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)&efOut.mField3, (void *)t4, (void *)t6,
    (void *)t5, (void *)&t9);
  for (t9 = 0ULL; t9 < 8ULL; t9++) {
    t4[t9] = DP_R[t9 + 11ULL];
  }

  t5[0ULL] = (M_idx_0 != 0);
  t5[1ULL] = (M_idx_1 != 0);
  t9 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&b_efOut, (void *)efOut.mField0, (void *)
    efOut.mField1, (void *)efOut.mField2, (void *)efOut.mField3, (void *)t4,
    (void *)t5, (void *)&t9);
  out.mX[0] = -(b_efOut[0] * t10 * 1000.0);
  (void)sys;
  (void)t18;
  return 0;
}
