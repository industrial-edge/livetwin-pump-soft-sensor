/*
 * pump_soft_sensor_capi.h
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "pump_soft_sensor".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Dec  1 11:06:18 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pump_soft_sensor_capi_h
#define RTW_HEADER_pump_soft_sensor_capi_h
#include "pump_soft_sensor.h"

extern void pump_soft_sensor_InitializeDataMapInfo(RT_MODEL_pump_soft_sensor_T *
  const pump_soft_sensor_M, B_pump_soft_sensor_T *pump_soft_sensor_B,
  P_pump_soft_sensor_T *pump_soft_sensor_P, DW_pump_soft_sensor_T
  *pump_soft_sensor_DW, X_pump_soft_sensor_T *pump_soft_sensor_X);

#endif                                 /* RTW_HEADER_pump_soft_sensor_capi_h */

/* EOF: pump_soft_sensor_capi.h */
