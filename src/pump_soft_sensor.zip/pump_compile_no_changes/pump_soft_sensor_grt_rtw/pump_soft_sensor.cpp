/*
 * pump_soft_sensor.cpp
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "pump_soft_sensor".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Dec  1 11:06:18 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pump_soft_sensor_capi.h"
#include "pump_soft_sensor.h"
#include "pump_soft_sensor_private.h"

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
void pump_soft_sensorModelClass::rt_ertODEUpdateContinuousStates(RTWSolverInfo
  *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = static_cast<ODE3_IntgData *>(rtsiGetSolverData(si));
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 1;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  pump_soft_sensor_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  this->step();
  pump_soft_sensor_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  this->step();
  pump_soft_sensor_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void pump_soft_sensorModelClass::step()
{
  if (rtmIsMajorTimeStep((&pump_soft_sensor_M))) {
    /* set solver stop time */
    if (!((&pump_soft_sensor_M)->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&(&pump_soft_sensor_M)->solverInfo,
                            (((&pump_soft_sensor_M)->Timing.clockTickH0 + 1) * (
        &pump_soft_sensor_M)->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&(&pump_soft_sensor_M)->solverInfo,
                            (((&pump_soft_sensor_M)->Timing.clockTick0 + 1) *
        (&pump_soft_sensor_M)->Timing.stepSize0 + (&pump_soft_sensor_M)
        ->Timing.clockTickH0 * (&pump_soft_sensor_M)->Timing.stepSize0 *
        4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep((&pump_soft_sensor_M))) {
    (&pump_soft_sensor_M)->Timing.t[0] = rtsiGetT(&(&pump_soft_sensor_M)
      ->solverInfo);
  }

  {
    PmRealVector inputs;
    PmRealVector states;
    PmRealVector outputs;
    boolean_T first_output;
    char *msg;
    real_T rtb_Switch3;
    real_T rtb_Abs;
    if (rtmIsMajorTimeStep((&pump_soft_sensor_M))) {
      /* Outport: '<Root>/angle_velocity' incorporates:
       *  Fcn: '<Root>/U//min in rad//s'
       *  Inport: '<Root>/pump_speed'
       */
      pump_soft_sensor_Y.angle_velocity = pump_soft_sensor_U.pump_speed * 2.0 *
        3.1415926535897931 / 60.0;

      /* SimscapeInputBlock: '<S13>/INPUT_1_1_1' incorporates:
       *  Outport: '<Root>/angle_velocity'
       */
      if (rtmIsMajorTimeStep((&pump_soft_sensor_M))) {
        pump_soft_sensor_B.INPUT_1_1_1[0] = pump_soft_sensor_Y.angle_velocity;
        pump_soft_sensor_B.INPUT_1_1_1[1] = 0.0;
        pump_soft_sensor_B.INPUT_1_1_1[2] = 0.0;
        pump_soft_sensor_DW.INPUT_1_1_1_Discrete[0] =
          !(pump_soft_sensor_B.INPUT_1_1_1[0] ==
            pump_soft_sensor_DW.INPUT_1_1_1_Discrete[1]);
        pump_soft_sensor_DW.INPUT_1_1_1_Discrete[1] =
          pump_soft_sensor_B.INPUT_1_1_1[0];
        pump_soft_sensor_B.INPUT_1_1_1[0] =
          pump_soft_sensor_DW.INPUT_1_1_1_Discrete[1];
        pump_soft_sensor_B.INPUT_1_1_1[3] =
          pump_soft_sensor_DW.INPUT_1_1_1_Discrete[0];
      }

      /* End of SimscapeInputBlock: '<S13>/INPUT_1_1_1' */

      /* SimscapeSwlState: '<S13>/SWL_STATE_0' */
      inputs.mN = 1;
      inputs.mX = &pump_soft_sensor_DW.SWL_STATE_0_Inputs;
      pump_soft_sensor_DW.SWL_STATE_0_Inputs = pump_soft_sensor_B.INPUT_1_1_1[0];
      states.mN = 35;
      states.mX = &pump_soft_sensor_DW.SWL_STATE_0_Discrete[0];
      outputs.mN = 3;
      outputs.mX = &pump_soft_sensor_B.SWL_STATE_0[0];
      first_output = false;
      if (pump_soft_sensor_DW.SWL_STATE_0_FirstOutput == 0.0) {
        pump_soft_sensor_DW.SWL_STATE_0_FirstOutput = 1.0;
        first_output = true;
      }

      first_output = swl_solve((const Simulator *)
        pump_soft_sensor_DW.SWL_STATE_0_SimulatorPtr, &inputs, &states, &outputs,
        (&pump_soft_sensor_M)->Timing.t[0], (NeuDiagnosticManager *)
        pump_soft_sensor_DW.SWL_STATE_0_DiagMgr, first_output);
      if (first_output) {
        first_output = error_buffer_is_empty(rtmGetErrorStatus
          ((&pump_soft_sensor_M)));
        if (first_output) {
          msg = rtw_diagnostics_msg((const NeuDiagnosticTree *)
            pump_soft_sensor_DW.SWL_STATE_0_DiagTree);
          rtmSetErrorStatus((&pump_soft_sensor_M), msg);
        }
      }

      /* End of SimscapeSwlState: '<S13>/SWL_STATE_0' */

      /* Outport: '<Root>/flowrate_l//s' */
      pump_soft_sensor_Y.flowrate_ls = pump_soft_sensor_B.SWL_STATE_0[0];

      /* Outport: '<Root>/flowrate_l//min' incorporates:
       *  Fcn: '<Root>/l//s in l//min'
       */
      pump_soft_sensor_Y.flowrate_lmin = pump_soft_sensor_B.SWL_STATE_0[0] *
        60.0;

      /* Outport: '<Root>/pump_pressure_Pa' */
      pump_soft_sensor_Y.pump_pressure_Pa = pump_soft_sensor_B.SWL_STATE_0[2];

      /* Sum: '<S7>/Subtract1' incorporates:
       *  Inport: '<Root>/pumppressure_sensor_Pa'
       */
      rtb_Abs = pump_soft_sensor_U.pumppressure_sensor_Pa -
        pump_soft_sensor_B.SWL_STATE_0[2];

      /* Outport: '<Root>/pumppressure_delta_Pa' incorporates:
       *  Abs: '<S7>/Abs'
       */
      pump_soft_sensor_Y.pumppressure_delta_Pa = std::abs(rtb_Abs);

      /* Switch: '<S7>/Switch' */
      if (rtb_Abs > pump_soft_sensor_P.Switch_Threshold) {
        /* Product: '<S7>/Divide' incorporates:
         *  Inport: '<Root>/pumppressure_sensor_Pa'
         */
        rtb_Abs = pump_soft_sensor_B.SWL_STATE_0[2] /
          pump_soft_sensor_U.pumppressure_sensor_Pa;
      } else {
        /* Product: '<S7>/Divide1' incorporates:
         *  Inport: '<Root>/pumppressure_sensor_Pa'
         */
        rtb_Abs = pump_soft_sensor_U.pumppressure_sensor_Pa /
          pump_soft_sensor_B.SWL_STATE_0[2];
      }

      /* End of Switch: '<S7>/Switch' */

      /* Switch: '<S7>/Switch1' */
      if (rtb_Abs > pump_soft_sensor_P.Switch1_Threshold) {
        /* Outport: '<Root>/control_pumppressure' incorporates:
         *  Constant: '<S7>/Constant1'
         */
        pump_soft_sensor_Y.control_pumppressure =
          pump_soft_sensor_P.Constant1_Value;
      } else {
        /* Outport: '<Root>/control_pumppressure' incorporates:
         *  Constant: '<S7>/Constant'
         */
        pump_soft_sensor_Y.control_pumppressure =
          pump_soft_sensor_P.Constant_Value;
      }

      /* End of Switch: '<S7>/Switch1' */

      /* Outport: '<Root>/flowrate_m^3//s' */
      pump_soft_sensor_Y.flowrate_m3s = pump_soft_sensor_B.SWL_STATE_0[1];

      /* Fcn: '<Root>/m^3//s in m^3//h' */
      rtb_Abs = pump_soft_sensor_B.SWL_STATE_0[1] * 3600.0;

      /* Outport: '<Root>/flowrate_m^3//h' */
      pump_soft_sensor_Y.flowrate_m3h = rtb_Abs;

      /* Sum: '<S6>/Subtract' incorporates:
       *  Inport: '<Root>/flowrate_sensor_m^3//h'
       */
      rtb_Switch3 = pump_soft_sensor_U.flowrate_sensor_m3h - rtb_Abs;

      /* Outport: '<Root>/flowrate_delta_m^3//h' incorporates:
       *  Abs: '<S6>/Abs'
       */
      pump_soft_sensor_Y.flowrate_delta_m3h = std::abs(rtb_Switch3);

      /* Switch: '<S6>/Switch2' incorporates:
       *  Inport: '<Root>/flowrate_sensor_m^3//h'
       *  Product: '<S6>/Divide2'
       *  Product: '<S6>/Divide3'
       */
      if (rtb_Switch3 > pump_soft_sensor_P.Switch2_Threshold) {
        rtb_Switch3 = rtb_Abs / pump_soft_sensor_U.flowrate_sensor_m3h;
      } else {
        rtb_Switch3 = pump_soft_sensor_U.flowrate_sensor_m3h / rtb_Abs;
      }

      /* End of Switch: '<S6>/Switch2' */

      /* Switch: '<S6>/Switch3' */
      if (rtb_Switch3 > pump_soft_sensor_P.Switch3_Threshold) {
        /* Outport: '<Root>/control_flowrate' incorporates:
         *  Constant: '<S6>/Constant5'
         */
        pump_soft_sensor_Y.control_flowrate = pump_soft_sensor_P.Constant5_Value;
      } else {
        /* Outport: '<Root>/control_flowrate' incorporates:
         *  Constant: '<S6>/Constant4'
         */
        pump_soft_sensor_Y.control_flowrate = pump_soft_sensor_P.Constant4_Value;
      }

      /* End of Switch: '<S6>/Switch3' */
    }

    /* Outport: '<Root>/volume_in_m^3' incorporates:
     *  Integrator: '<Root>/Integrator'
     */
    pump_soft_sensor_Y.volume_in_m3 = pump_soft_sensor_X.Integrator_CSTATE;
  }

  if (rtmIsMajorTimeStep((&pump_soft_sensor_M))) {
    PmRealVector inputs;
    PmRealVector states;
    boolean_T tmp;
    char *msg;
    if (rtmIsMajorTimeStep((&pump_soft_sensor_M))) {
      /* Update for SimscapeSwlState: '<S13>/SWL_STATE_0' */
      inputs.mN = 1;
      inputs.mX = &pump_soft_sensor_DW.SWL_STATE_0_Inputs;
      pump_soft_sensor_DW.SWL_STATE_0_Inputs = pump_soft_sensor_B.INPUT_1_1_1[0];
      states.mN = 35;
      states.mX = &pump_soft_sensor_DW.SWL_STATE_0_Discrete[0];
      tmp = swl_check((const Simulator *)
                      pump_soft_sensor_DW.SWL_STATE_0_SimulatorPtr, &inputs,
                      &states, (&pump_soft_sensor_M)->Timing.t[0],
                      (NeuDiagnosticManager *)
                      pump_soft_sensor_DW.SWL_STATE_0_DiagMgr);
      if (tmp) {
        tmp = error_buffer_is_empty(rtmGetErrorStatus((&pump_soft_sensor_M)));
        if (tmp) {
          msg = rtw_diagnostics_msg((const NeuDiagnosticTree *)
            pump_soft_sensor_DW.SWL_STATE_0_DiagTree);
          rtmSetErrorStatus((&pump_soft_sensor_M), msg);
        }
      }

      /* End of Update for SimscapeSwlState: '<S13>/SWL_STATE_0' */
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep((&pump_soft_sensor_M))) {
    rt_ertODEUpdateContinuousStates(&(&pump_soft_sensor_M)->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++(&pump_soft_sensor_M)->Timing.clockTick0)) {
      ++(&pump_soft_sensor_M)->Timing.clockTickH0;
    }

    (&pump_soft_sensor_M)->Timing.t[0] = rtsiGetSolverStopTime
      (&(&pump_soft_sensor_M)->solverInfo);

    {
      /* Update absolute timer for sample time: [0.001s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.001, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      (&pump_soft_sensor_M)->Timing.clockTick1++;
      if (!(&pump_soft_sensor_M)->Timing.clockTick1) {
        (&pump_soft_sensor_M)->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void pump_soft_sensorModelClass::pump_soft_sensor_derivatives()
{
  XDot_pump_soft_sensor_T *_rtXdot;
  _rtXdot = ((XDot_pump_soft_sensor_T *) (&pump_soft_sensor_M)->derivs);

  /* Derivatives for Integrator: '<Root>/Integrator' */
  _rtXdot->Integrator_CSTATE = pump_soft_sensor_B.SWL_STATE_0[1];
}

/* Model initialize function */
void pump_soft_sensorModelClass::initialize()
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&(&pump_soft_sensor_M)->solverInfo,
                          &(&pump_soft_sensor_M)->Timing.simTimeStep);
    rtsiSetTPtr(&(&pump_soft_sensor_M)->solverInfo, &rtmGetTPtr
                ((&pump_soft_sensor_M)));
    rtsiSetStepSizePtr(&(&pump_soft_sensor_M)->solverInfo, &(&pump_soft_sensor_M)
                       ->Timing.stepSize0);
    rtsiSetdXPtr(&(&pump_soft_sensor_M)->solverInfo, &(&pump_soft_sensor_M)
                 ->derivs);
    rtsiSetContStatesPtr(&(&pump_soft_sensor_M)->solverInfo, (real_T **)
                         &(&pump_soft_sensor_M)->contStates);
    rtsiSetNumContStatesPtr(&(&pump_soft_sensor_M)->solverInfo,
      &(&pump_soft_sensor_M)->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&pump_soft_sensor_M)->solverInfo,
      &(&pump_soft_sensor_M)->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&pump_soft_sensor_M)->solverInfo,
      &(&pump_soft_sensor_M)->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&pump_soft_sensor_M)->solverInfo,
      &(&pump_soft_sensor_M)->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&pump_soft_sensor_M)->solverInfo,
                          (&rtmGetErrorStatus((&pump_soft_sensor_M))));
    rtsiSetRTModelPtr(&(&pump_soft_sensor_M)->solverInfo, (&pump_soft_sensor_M));
  }

  rtsiSetSimTimeStep(&(&pump_soft_sensor_M)->solverInfo, MAJOR_TIME_STEP);
  (&pump_soft_sensor_M)->intgData.y = (&pump_soft_sensor_M)->odeY;
  (&pump_soft_sensor_M)->intgData.f[0] = (&pump_soft_sensor_M)->odeF[0];
  (&pump_soft_sensor_M)->intgData.f[1] = (&pump_soft_sensor_M)->odeF[1];
  (&pump_soft_sensor_M)->intgData.f[2] = (&pump_soft_sensor_M)->odeF[2];
  (&pump_soft_sensor_M)->contStates = ((X_pump_soft_sensor_T *)
    &pump_soft_sensor_X);
  rtsiSetSolverData(&(&pump_soft_sensor_M)->solverInfo, static_cast<void *>
                    (&(&pump_soft_sensor_M)->intgData));
  rtsiSetSolverName(&(&pump_soft_sensor_M)->solverInfo,"ode3");
  rtmSetTPtr((&pump_soft_sensor_M), &(&pump_soft_sensor_M)->Timing.tArray[0]);
  (&pump_soft_sensor_M)->Timing.stepSize0 = 0.001;

  /* block I/O */
  (void) std::memset((static_cast<void *>(&pump_soft_sensor_B)), 0,
                     sizeof(B_pump_soft_sensor_T));

  /* states (continuous) */
  {
    (void) std::memset(static_cast<void *>(&pump_soft_sensor_X), 0,
                       sizeof(X_pump_soft_sensor_T));
  }

  /* states (dwork) */
  (void) std::memset(static_cast<void *>(&pump_soft_sensor_DW), 0,
                     sizeof(DW_pump_soft_sensor_T));

  /* external inputs */
  (void)std::memset(&pump_soft_sensor_U, 0, sizeof(ExtU_pump_soft_sensor_T));

  /* external outputs */
  (void) std::memset(static_cast<void *>(&pump_soft_sensor_Y), 0,
                     sizeof(ExtY_pump_soft_sensor_T));

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  pump_soft_sensor_InitializeDataMapInfo((&pump_soft_sensor_M),
    &pump_soft_sensor_B, &pump_soft_sensor_P, &pump_soft_sensor_DW,
    &pump_soft_sensor_X);

  {
    NeuDiagnosticManager *tmp;
    const NeuDiagnosticTree *tmp_0;
    const Simulator *tmp_1;
    NeParameterBundle parameterBundle;
    real_T tmp_2[43];

    /* Start for SimscapeSwlState: '<S13>/SWL_STATE_0' */
    tmp = rtw_create_diagnostics();
    pump_soft_sensor_DW.SWL_STATE_0_DiagMgr = (void *)tmp;
    tmp_0 = neu_diagnostic_manager_get_initial_tree((NeuDiagnosticManager *)
      pump_soft_sensor_DW.SWL_STATE_0_DiagMgr);
    pump_soft_sensor_DW.SWL_STATE_0_DiagTree = (void *)tmp_0;
    tmp_1 = pump_soft_sensor_3d73c5c7_0_simulator_create();
    pump_soft_sensor_DW.SWL_STATE_0_SimulatorPtr = (void *)tmp_1;
    parameterBundle.mLogicalParameters.mN = 0;
    parameterBundle.mLogicalParameters.mX = NULL;
    parameterBundle.mIntegerParameters.mN = 0;
    parameterBundle.mIntegerParameters.mX = NULL;
    parameterBundle.mIndexParameters.mN = 0;
    parameterBundle.mIndexParameters.mX = NULL;
    tmp_2[0] = pump_soft_sensor_P.Angular_speed_treshold_for_flow_reversal;
    tmp_2[1] = pump_soft_sensor_P.Reference_angular_velocity;
    tmp_2[2] = pump_soft_sensor_P.Reference_density;
    tmp_2[3] = pump_soft_sensor_P.pressure_pipe_internal_diameter;
    tmp_2[4] = pump_soft_sensor_P.pressure_pipe_inlet_heigth;
    tmp_2[5] = pump_soft_sensor_P.pressure_pipe_outlet_heigth;
    tmp_2[6] = pump_soft_sensor_P.pressure_pipe_length;
    tmp_2[7] = pump_soft_sensor_P.suction_pipe_internal_diameter;
    tmp_2[8] = pump_soft_sensor_P.suction_pipe_inlet_heigth;
    tmp_2[9] = pump_soft_sensor_P.suction_pipe_outlet_heigth;
    tmp_2[10] = pump_soft_sensor_P.suction_pipe_length;
    std::memcpy(&tmp_2[11],
                &pump_soft_sensor_P.pump_delivery_vector_pressure_differential[0],
                sizeof(real_T) << 3U);
    std::memcpy(&tmp_2[19],
                &pump_soft_sensor_P.pump_delivery_vector_brake_power[0], sizeof
                (real_T) << 3U);
    std::memcpy(&tmp_2[27],
                &pump_soft_sensor_P.pump_pressure_differential_vector[0], sizeof
                (real_T) << 3U);
    std::memcpy(&tmp_2[35], &pump_soft_sensor_P.pump_brake_power_vector[0],
                sizeof(real_T) << 3U);
    parameterBundle.mRealParameters.mN = 43;
    parameterBundle.mRealParameters.mX = &tmp_2[0];
    swl_start((const Simulator *)pump_soft_sensor_DW.SWL_STATE_0_SimulatorPtr,
              &parameterBundle);
  }

  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  pump_soft_sensor_X.Integrator_CSTATE = pump_soft_sensor_P.Integrator_IC;
}

/* Model terminate function */
void pump_soft_sensorModelClass::terminate()
{
  /* Terminate for SimscapeSwlState: '<S13>/SWL_STATE_0' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    pump_soft_sensor_DW.SWL_STATE_0_DiagMgr);
  pump_soft_sensor_3d73c5c7_0_simulator_destroy();
}

/* Constructor */
pump_soft_sensorModelClass::pump_soft_sensorModelClass() : pump_soft_sensor_M()
{
  /* Currently there is no constructor body generated.*/
}

/* Destructor */
pump_soft_sensorModelClass::~pump_soft_sensorModelClass()
{
  /* Currently there is no destructor body generated.*/
}

/* Real-Time Model get method */
RT_MODEL_pump_soft_sensor_T * pump_soft_sensorModelClass::getRTM()
{
  return (&pump_soft_sensor_M);
}
