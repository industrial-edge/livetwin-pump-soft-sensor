/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_fx.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_sys_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_external_struct.h"
#include "ssc_ml_fun.h"

int32_T pump_soft_sensor_3d73c5c7_0_slc_0_fx(const SwitchedLinearClump *sys,
  const NeDynamicSystemInput *t51, SlcMethodOutput *t52)
{
  PmRealVector out;
  real_T zc_int6;
  real_T t4[8];
  boolean_T t5[2];
  real_T t7[1];
  size_t t9;
  real_T t10;
  real_T t11;
  real_T t12;
  real_T t14;
  real_T t15;
  real_T t18;
  real_T t43;
  real_T t46;
  real_T t47;
  real_T DP_R[33];
  ETTS0 efOut;
  real_T b_efOut[1];
  real_T U_idx_0;
  real_T X_idx_0;
  real_T X_idx_1;
  real_T X_idx_2;
  int32_T M_idx_9;
  int32_T M_idx_17;
  int32_T M_idx_15;
  int32_T M_idx_16;
  int32_T M_idx_18;
  int32_T M_idx_19;
  int32_T M_idx_0;
  int32_T M_idx_1;
  int32_T M_idx_14;
  int32_T M_idx_20;
  int32_T M_idx_2;
  M_idx_0 = t51->mM.mX[0];
  M_idx_1 = t51->mM.mX[1];
  M_idx_2 = t51->mM.mX[2];
  M_idx_9 = t51->mM.mX[9];
  M_idx_14 = t51->mM.mX[14];
  M_idx_15 = t51->mM.mX[15];
  M_idx_16 = t51->mM.mX[16];
  M_idx_17 = t51->mM.mX[17];
  M_idx_18 = t51->mM.mX[18];
  M_idx_19 = t51->mM.mX[19];
  M_idx_20 = t51->mM.mX[20];
  U_idx_0 = t51->mU.mX[0];
  X_idx_0 = t51->mX.mX[0];
  X_idx_1 = t51->mX.mX[1];
  X_idx_2 = t51->mX.mX[2];
  DP_R[0] = t51->mDP_R.mX[0];
  DP_R[1] = t51->mDP_R.mX[1];
  DP_R[2] = t51->mDP_R.mX[2];
  DP_R[3] = t51->mDP_R.mX[3];
  DP_R[4] = t51->mDP_R.mX[4];
  DP_R[5] = t51->mDP_R.mX[5];
  DP_R[6] = t51->mDP_R.mX[6];
  DP_R[7] = t51->mDP_R.mX[7];
  DP_R[8] = t51->mDP_R.mX[8];
  DP_R[9] = t51->mDP_R.mX[9];
  DP_R[10] = t51->mDP_R.mX[10];
  DP_R[11] = t51->mDP_R.mX[11];
  DP_R[12] = t51->mDP_R.mX[12];
  DP_R[13] = t51->mDP_R.mX[13];
  DP_R[14] = t51->mDP_R.mX[14];
  DP_R[15] = t51->mDP_R.mX[15];
  DP_R[16] = t51->mDP_R.mX[16];
  DP_R[17] = t51->mDP_R.mX[17];
  DP_R[18] = t51->mDP_R.mX[18];
  DP_R[19] = t51->mDP_R.mX[19];
  DP_R[20] = t51->mDP_R.mX[20];
  DP_R[21] = t51->mDP_R.mX[21];
  DP_R[22] = t51->mDP_R.mX[22];
  DP_R[23] = t51->mDP_R.mX[23];
  DP_R[24] = t51->mDP_R.mX[24];
  DP_R[25] = t51->mDP_R.mX[25];
  DP_R[26] = t51->mDP_R.mX[26];
  DP_R[27] = t51->mDP_R.mX[27];
  DP_R[28] = t51->mDP_R.mX[28];
  DP_R[29] = t51->mDP_R.mX[29];
  DP_R[30] = t51->mDP_R.mX[30];
  DP_R[31] = t51->mDP_R.mX[31];
  DP_R[32] = t51->mDP_R.mX[32];
  out = t52->mFX;
  zc_int6 = X_idx_2 * 0.00099779981710000024;
  t11 = DP_R[4ULL] * DP_R[4ULL];
  t10 = DP_R[5ULL] * 6.4361463199777107E-5 / (t11 == 0.0 ? 1.0E-16 : t11) /
    (DP_R[3ULL] == 0.0 ? 1.0E-16 : DP_R[3ULL]) / 2.0 * X_idx_2 * 997.7998171;
  t15 = DP_R[10ULL] * 0.10471975511965977;
  t43 = DP_R[1ULL] * DP_R[1ULL];
  t12 = DP_R[2ULL] * 6.4361463199777107E-5 / (t43 == 0.0 ? 1.0E-16 : t43) /
    (DP_R[0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) / 2.0 * zc_int6 *
    999999.99999999977;
  t14 = M_idx_9 != 0 ? 1.0 : -1.0;
  t47 = zc_int6 * DP_R[1ULL] * t14 * 1002.2050343789342 / (DP_R[0ULL] == 0.0 ?
    1.0E-16 : DP_R[0ULL]) / 1.0056478624965173E-6;
  t18 = M_idx_17 != 0 ? 1.0 : -1.0;
  t11 = DP_R[4ULL] * X_idx_2 * t18 / (DP_R[3ULL] == 0.0 ? 1.0E-16 : DP_R[3ULL]) /
    1.0056478624965173E-6;
  t46 = (t11 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_15 != 0) {
    t43 = 0.0;
  } else if (M_idx_16 != 0) {
    t43 = t46 * t46 * 3.0 - t46 * t46 * t46 * 2.0;
  } else {
    t43 = 1.0;
  }

  if (M_idx_18 != 0) {
    t46 = 0.0;
  } else {
    t11 = pmf_log10(6.9 / (t11 == 0.0 ? 1.0E-16 : t11) * 999999.99999999988 +
                    pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t11 ==
      0.0 ? 1.0E-16 : t11) * 999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7, 1.11))
      * 3.24;
    t46 = 1.0 / (t11 == 0.0 ? 1.0E-16 : t11);
  }

  t11 = DP_R[5ULL] * t46;
  t46 = DP_R[3ULL] * DP_R[3ULL];
  t11 = t11 / (DP_R[4ULL] == 0.0 ? 1.0E-16 : DP_R[4ULL]) / (t46 == 0.0 ? 1.0E-16
    : t46) / 2.0 * X_idx_2 * X_idx_2 * t18 * 997.7998171;
  if (M_idx_15 != 0) {
    t11 = t10 * 1.0000000000000001E-11;
  } else if (M_idx_16 != 0) {
    t11 = t10 * 1.0000000000000001E-11 + (t11 * 1.0000000000000002E-17 - t10 *
      1.0000000000000001E-11) * t43;
  } else {
    t11 *= 1.0000000000000002E-17;
  }

  if (M_idx_19 != 0) {
    t10 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[9ULL] * DP_R[9ULL]);
  } else {
    t10 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[9ULL] * DP_R[9ULL]);
  }

  t46 = t15 / (t10 == 0.0 ? 1.0E-16 : t10);
  t10 = (t47 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_0 != 0) {
    t18 = 0.0;
  } else if (M_idx_1 != 0) {
    t18 = t10 * t10 * 3.0 - t10 * t10 * t10 * 2.0;
  } else {
    t18 = 1.0;
  }

  if (M_idx_14 != 0) {
    t10 = 0.0;
  } else {
    t43 = pmf_log10(6.9 / (t47 == 0.0 ? 1.0E-16 : t47) * 999999.99999999988 +
                    pmf_pow(DP_R[28ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t47 ==
      0.0 ? 1.0E-16 : t47) * 999999.99999999988 + pmf_pow(DP_R[28ULL] / 3.7,
      1.11)) * 3.24;
    t10 = 1.0 / (t43 == 0.0 ? 1.0E-16 : t43);
  }

  t47 = DP_R[0ULL] * DP_R[0ULL];
  t10 = DP_R[2ULL] * t10 / (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) / (t47 ==
    0.0 ? 1.0E-16 : t47) / 2.0 * zc_int6 * zc_int6 * t14 * 1.002205034378934E+9;
  if (M_idx_0 != 0) {
    zc_int6 = t12 * 1.0000000000000001E-11;
  } else if (M_idx_1 != 0) {
    zc_int6 = t12 * 1.0000000000000001E-11 + (t10 * 1.0000000000000002E-17 - t12
      * 1.0000000000000001E-11) * t18;
  } else {
    zc_int6 = t10 * 1.0000000000000002E-17;
  }

  for (t9 = 0ULL; t9 < 8ULL; t9++) {
    t4[t9] = DP_R[t9 + 12ULL];
  }

  t7[0ULL] = t46 * X_idx_2;
  t5[0ULL] = (M_idx_20 != 0);
  t5[1ULL] = (M_idx_2 != 0);
  t9 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)&efOut.mField3, (void *)t4, (void *)t7,
    (void *)t5, (void *)&t9);
  for (t9 = 0ULL; t9 < 8ULL; t9++) {
    t4[t9] = DP_R[t9 + 20ULL];
  }

  t5[0ULL] = (M_idx_20 != 0);
  t5[1ULL] = (M_idx_2 != 0);
  t9 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&b_efOut, (void *)efOut.mField0, (void *)
    efOut.mField1, (void *)efOut.mField2, (void *)efOut.mField3, (void *)t4,
    (void *)t5, (void *)&t9);
  out.mX[0] = X_idx_0 - (DP_R[8ULL] * 1.0E-5 + t11);
  out.mX[1] = X_idx_1 - b_efOut[0] * (U_idx_0 / (t15 == 0.0 ? 1.0E-16 : t15) *
    (U_idx_0 / (t15 == 0.0 ? 1.0E-16 : t15)) * 997.7998171 / (DP_R[11ULL] == 0.0
    ? 1.0E-16 : DP_R[11ULL]));
  out.mX[2] = (-X_idx_0 + X_idx_1) - (DP_R[6ULL] * 1.0E-5 + zc_int6);
  (void)sys;
  (void)t52;
  return 0;
}
