/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */
/* pump_soft_sensor_3d73c5c7_0.h - header for module pump_soft_sensor_3d73c5c7_0 */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef PUMP_SOFT_SENSOR_3D73C5C7_0_H
#define PUMP_SOFT_SENSOR_3D73C5C7_0_H  1

  extern SwitchedLinearSystem *pump_soft_sensor_3d73c5c7_0(PmAllocator
    *allocator );

#endif                               /* #ifndef PUMP_SOFT_SENSOR_3D73C5C7_0_H */

#ifdef __cplusplus

}
#endif
