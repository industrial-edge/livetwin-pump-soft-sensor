/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_assert.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_sys_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_external_struct.h"
#include "ssc_ml_fun.h"

int32_T pump_soft_sensor_3d73c5c7_0_gmt_assert(const GlobalMethodTable *sys,
  const NeDynamicSystemInput *t23, GmtMethodOutput *t24)
{
  PmIntVector out;
  real_T intrm_sf_mf_1;
  boolean_T t3[1];
  real_T t4[7];
  real_T t5[7];
  boolean_T t6[1];
  size_t t13;
  size_t t14;
  real_T DP_R[105];
  real_T X_idx_3;
  int32_T DP_L_idx_0;
  int32_T DP_L_idx_1;
  int32_T DP_L_idx_2;
  int32_T DP_L_idx_3;
  int32_T DP_L_idx_4;
  int32_T DP_L_idx_5;
  int32_T M_idx_5;
  int32_T M_idx_6;
  int32_T M_idx_7;
  int32_T M_idx_8;
  int32_T M_idx_9;
  int32_T M_idx_10;
  int32_T M_idx_11;
  int32_T M_idx_13;
  int32_T M_idx_14;
  int32_T M_idx_15;
  int32_T M_idx_16;
  int32_T M_idx_17;
  int32_T M_idx_18;
  int32_T M_idx_19;
  M_idx_5 = t23->mM.mX[5];
  M_idx_6 = t23->mM.mX[6];
  M_idx_7 = t23->mM.mX[7];
  M_idx_8 = t23->mM.mX[8];
  M_idx_9 = t23->mM.mX[9];
  M_idx_10 = t23->mM.mX[10];
  M_idx_11 = t23->mM.mX[11];
  M_idx_13 = t23->mM.mX[13];
  M_idx_14 = t23->mM.mX[14];
  M_idx_15 = t23->mM.mX[15];
  M_idx_16 = t23->mM.mX[16];
  M_idx_17 = t23->mM.mX[17];
  M_idx_18 = t23->mM.mX[18];
  M_idx_19 = t23->mM.mX[19];
  X_idx_3 = t23->mX.mX[3];
  DP_L_idx_0 = t23->mDP_L.mX[0];
  DP_L_idx_1 = t23->mDP_L.mX[1];
  DP_L_idx_2 = t23->mDP_L.mX[2];
  DP_L_idx_3 = t23->mDP_L.mX[3];
  DP_L_idx_4 = t23->mDP_L.mX[4];
  DP_L_idx_5 = t23->mDP_L.mX[5];
  DP_R[0] = t23->mDP_R.mX[0];
  DP_R[1] = t23->mDP_R.mX[1];
  DP_R[2] = t23->mDP_R.mX[2];
  DP_R[3] = t23->mDP_R.mX[3];
  DP_R[4] = t23->mDP_R.mX[4];
  DP_R[5] = t23->mDP_R.mX[5];
  DP_R[6] = t23->mDP_R.mX[6];
  DP_R[7] = t23->mDP_R.mX[7];
  DP_R[8] = t23->mDP_R.mX[8];
  DP_R[9] = t23->mDP_R.mX[9];
  DP_R[10] = t23->mDP_R.mX[10];
  DP_R[11] = t23->mDP_R.mX[11];
  DP_R[12] = t23->mDP_R.mX[12];
  DP_R[13] = t23->mDP_R.mX[13];
  DP_R[14] = t23->mDP_R.mX[14];
  DP_R[15] = t23->mDP_R.mX[15];
  DP_R[16] = t23->mDP_R.mX[16];
  DP_R[17] = t23->mDP_R.mX[17];
  DP_R[18] = t23->mDP_R.mX[18];
  DP_R[19] = t23->mDP_R.mX[19];
  DP_R[20] = t23->mDP_R.mX[20];
  DP_R[21] = t23->mDP_R.mX[21];
  DP_R[22] = t23->mDP_R.mX[22];
  DP_R[23] = t23->mDP_R.mX[23];
  DP_R[24] = t23->mDP_R.mX[24];
  DP_R[25] = t23->mDP_R.mX[25];
  DP_R[26] = t23->mDP_R.mX[26];
  DP_R[27] = t23->mDP_R.mX[27];
  DP_R[28] = t23->mDP_R.mX[28];
  DP_R[29] = t23->mDP_R.mX[29];
  DP_R[30] = t23->mDP_R.mX[30];
  DP_R[31] = t23->mDP_R.mX[31];
  DP_R[32] = t23->mDP_R.mX[32];
  DP_R[33] = t23->mDP_R.mX[33];
  DP_R[34] = t23->mDP_R.mX[34];
  DP_R[35] = t23->mDP_R.mX[35];
  DP_R[36] = t23->mDP_R.mX[36];
  DP_R[37] = t23->mDP_R.mX[37];
  DP_R[38] = t23->mDP_R.mX[38];
  DP_R[39] = t23->mDP_R.mX[39];
  DP_R[40] = t23->mDP_R.mX[40];
  DP_R[41] = t23->mDP_R.mX[41];
  DP_R[42] = t23->mDP_R.mX[42];
  DP_R[43] = t23->mDP_R.mX[43];
  DP_R[44] = t23->mDP_R.mX[44];
  DP_R[45] = t23->mDP_R.mX[45];
  DP_R[46] = t23->mDP_R.mX[46];
  DP_R[47] = t23->mDP_R.mX[47];
  DP_R[48] = t23->mDP_R.mX[48];
  DP_R[49] = t23->mDP_R.mX[49];
  DP_R[50] = t23->mDP_R.mX[50];
  DP_R[51] = t23->mDP_R.mX[51];
  DP_R[52] = t23->mDP_R.mX[52];
  DP_R[53] = t23->mDP_R.mX[53];
  DP_R[54] = t23->mDP_R.mX[54];
  DP_R[55] = t23->mDP_R.mX[55];
  DP_R[56] = t23->mDP_R.mX[56];
  DP_R[57] = t23->mDP_R.mX[57];
  DP_R[58] = t23->mDP_R.mX[58];
  DP_R[59] = t23->mDP_R.mX[59];
  DP_R[60] = t23->mDP_R.mX[60];
  DP_R[61] = t23->mDP_R.mX[61];
  DP_R[62] = t23->mDP_R.mX[62];
  DP_R[63] = t23->mDP_R.mX[63];
  DP_R[64] = t23->mDP_R.mX[64];
  DP_R[65] = t23->mDP_R.mX[65];
  DP_R[66] = t23->mDP_R.mX[66];
  DP_R[67] = t23->mDP_R.mX[67];
  DP_R[68] = t23->mDP_R.mX[68];
  DP_R[69] = t23->mDP_R.mX[69];
  DP_R[70] = t23->mDP_R.mX[70];
  DP_R[71] = t23->mDP_R.mX[71];
  DP_R[72] = t23->mDP_R.mX[72];
  DP_R[73] = t23->mDP_R.mX[73];
  DP_R[74] = t23->mDP_R.mX[74];
  DP_R[75] = t23->mDP_R.mX[75];
  DP_R[76] = t23->mDP_R.mX[76];
  DP_R[77] = t23->mDP_R.mX[77];
  DP_R[78] = t23->mDP_R.mX[78];
  DP_R[79] = t23->mDP_R.mX[79];
  DP_R[80] = t23->mDP_R.mX[80];
  DP_R[81] = t23->mDP_R.mX[81];
  DP_R[82] = t23->mDP_R.mX[82];
  DP_R[83] = t23->mDP_R.mX[83];
  DP_R[84] = t23->mDP_R.mX[84];
  DP_R[85] = t23->mDP_R.mX[85];
  DP_R[86] = t23->mDP_R.mX[86];
  DP_R[87] = t23->mDP_R.mX[87];
  DP_R[88] = t23->mDP_R.mX[88];
  DP_R[89] = t23->mDP_R.mX[89];
  DP_R[90] = t23->mDP_R.mX[90];
  DP_R[91] = t23->mDP_R.mX[91];
  DP_R[92] = t23->mDP_R.mX[92];
  DP_R[93] = t23->mDP_R.mX[93];
  DP_R[94] = t23->mDP_R.mX[94];
  DP_R[95] = t23->mDP_R.mX[95];
  DP_R[96] = t23->mDP_R.mX[96];
  DP_R[97] = t23->mDP_R.mX[97];
  DP_R[98] = t23->mDP_R.mX[98];
  DP_R[99] = t23->mDP_R.mX[99];
  DP_R[100] = t23->mDP_R.mX[100];
  DP_R[101] = t23->mDP_R.mX[101];
  DP_R[102] = t23->mDP_R.mX[102];
  DP_R[103] = t23->mDP_R.mX[103];
  DP_R[104] = t23->mDP_R.mX[104];
  out = t24->mASSERT;
  intrm_sf_mf_1 = X_idx_3 * 0.00099779981710000024;
  intrm_sf_mf_1 = intrm_sf_mf_1 * DP_R[0ULL] * (intrm_sf_mf_1 *
    1002.2050343789342 >= 0.0 ? 1.0 : -1.0) * 1002.2050343789342 / (DP_R[1ULL] ==
    0.0 ? 1.0E-16 : DP_R[1ULL]) / 1.0056478624965173E-6;
  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t4[t13] = DP_R[t13 + 26ULL];
  }

  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t5[t13] = DP_R[t13 + 25ULL];
  }

  t3[0ULL] = true;
  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t14 = t13 / 7ULL;
    t3[t14 > 0ULL ? 0ULL : t14] = (t3[t14 > 0ULL ? 0ULL : t14] && (t4[t13] -
      t5[t13] > 0.0));
  }

  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t4[t13] = DP_R[t13 + 42ULL];
  }

  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t5[t13] = DP_R[t13 + 41ULL];
  }

  t6[0ULL] = true;
  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t14 = t13 / 7ULL;
    t6[t14 > 0ULL ? 0ULL : t14] = (t6[t14 > 0ULL ? 0ULL : t14] && (t4[t13] -
      t5[t13] > 0.0));
  }

  out.mX[0] = (int32_T)!(DP_R[0ULL] <= 0.0);
  out.mX[1] = (int32_T)!(DP_R[4ULL] <= 0.0);
  out.mX[2] = (int32_T)!(DP_R[6ULL] <= 0.0);
  out.mX[3] = (int32_T)!(DP_R[10ULL] <= 0.0);
  out.mX[4] = (int32_T)(DP_R[50ULL] * 0.10471975511965977 > 0.0);
  out.mX[5] = (int32_T)(DP_R[51ULL] > 0.0);
  out.mX[6] = (int32_T)t3[0ULL];
  out.mX[7] = (int32_T)t6[0ULL];
  out.mX[8] = (int32_T)(DP_R[49ULL] > 0.0);
  out.mX[9] = (int32_T)(DP_L_idx_0 != 0);
  out.mX[10] = (int32_T)(DP_L_idx_1 != 0);
  out.mX[11] = (int32_T)(DP_L_idx_2 != 0);
  out.mX[12] = (int32_T)(DP_L_idx_3 != 0);
  out.mX[13] = (int32_T)(DP_L_idx_4 != 0);
  out.mX[14] = (int32_T)(DP_L_idx_5 != 0);
  out.mX[15] = 1;
  out.mX[16] = 1;
  out.mX[17] = 1;
  out.mX[18] = 1;
  out.mX[19] = 1;
  out.mX[20] = 1;
  out.mX[21] = (int32_T)(DP_R[1ULL] != 0.0);
  out.mX[22] = 1;
  out.mX[23] = (int32_T)(DP_R[7ULL] != 0.0);
  out.mX[24] = 1;
  out.mX[25] = (int32_T)(DP_R[6ULL] != 0.0);
  out.mX[26] = (int32_T)(M_idx_5 != 0);
  out.mX[27] = (int32_T)(M_idx_6 != 0);
  out.mX[28] = 1;
  out.mX[29] = (int32_T)((DP_R[6ULL] * X_idx_3 * (X_idx_3 >= 0.0 ? 1.0 : -1.0) /
    (DP_R[7ULL] == 0.0 ? 1.0E-16 : DP_R[7ULL]) / 1.0056478624965173E-6 *
    1.0000000000000002E-6 <= 200.0) || (DP_R[15ULL] / 3.7 >= 0.0));
  out.mX[30] = (int32_T)(M_idx_7 != 0);
  out.mX[31] = 1;
  out.mX[32] = 1;
  out.mX[33] = (int32_T)(M_idx_8 != 0);
  out.mX[34] = 1;
  out.mX[35] = 1;
  out.mX[36] = (int32_T)(DP_R[6ULL] * DP_R[6ULL] != 0.0);
  out.mX[37] = (int32_T)((!(DP_R[6ULL] * DP_R[6ULL] != 0.0)) || (DP_R[7ULL] !=
    0.0));
  out.mX[38] = 1;
  out.mX[39] = (int32_T)(DP_R[6ULL] != 0.0);
  out.mX[40] = 1;
  out.mX[41] = 1;
  out.mX[42] = (int32_T)((!(DP_R[6ULL] != 0.0)) || (DP_R[7ULL] * DP_R[7ULL] !=
    0.0));
  out.mX[43] = 1;
  out.mX[44] = 1;
  out.mX[45] = 1;
  out.mX[46] = 1;
  out.mX[47] = 1;
  out.mX[48] = 1;
  out.mX[49] = 1;
  out.mX[50] = 1;
  out.mX[51] = 1;
  out.mX[52] = (int32_T)(M_idx_9 != 0);
  out.mX[53] = 1;
  out.mX[54] = 1;
  out.mX[55] = 1;
  out.mX[56] = 1;
  out.mX[57] = (int32_T)(M_idx_10 != 0);
  out.mX[58] = (int32_T)(M_idx_11 != 0);
  out.mX[59] = (int32_T)(DP_R[50ULL] * 0.10471975511965977 != 0.0);
  out.mX[60] = 1;
  out.mX[61] = 1;
  out.mX[62] = (int32_T)(M_idx_13 != 0);
  out.mX[63] = 1;
  out.mX[64] = 1;
  out.mX[65] = 1;
  out.mX[66] = 1;
  out.mX[67] = (int32_T)(M_idx_14 != 0);
  out.mX[68] = (int32_T)(M_idx_15 != 0);
  out.mX[69] = (int32_T)(DP_R[0ULL] != 0.0);
  out.mX[70] = (int32_T)(M_idx_16 != 0);
  out.mX[71] = (int32_T)(M_idx_17 != 0);
  out.mX[72] = 1;
  out.mX[73] = (int32_T)((intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
    (DP_R[76ULL] / 3.7 >= 0.0));
  out.mX[74] = (int32_T)(M_idx_18 != 0);
  out.mX[75] = 1;
  out.mX[76] = 1;
  out.mX[77] = (int32_T)(M_idx_19 != 0);
  out.mX[78] = 1;
  out.mX[79] = 1;
  out.mX[80] = (int32_T)(DP_R[0ULL] * DP_R[0ULL] != 0.0);
  out.mX[81] = (int32_T)((!(DP_R[0ULL] * DP_R[0ULL] != 0.0)) || (DP_R[1ULL] !=
    0.0));
  out.mX[82] = 1;
  out.mX[83] = (int32_T)(DP_R[0ULL] != 0.0);
  out.mX[84] = 1;
  out.mX[85] = 1;
  out.mX[86] = (int32_T)((!(DP_R[0ULL] != 0.0)) || (DP_R[1ULL] * DP_R[1ULL] !=
    0.0));
  out.mX[87] = 1;
  out.mX[88] = 1;
  out.mX[89] = 1;
  out.mX[90] = 1;
  out.mX[91] = 1;
  (void)sys;
  (void)t24;
  return 0;
}
