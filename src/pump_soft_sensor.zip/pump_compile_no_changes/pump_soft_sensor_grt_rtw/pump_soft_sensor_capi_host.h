#ifndef RTW_HEADER_pump_soft_sensor_cap_host_h_
#define RTW_HEADER_pump_soft_sensor_cap_host_h_
#ifdef HOST_CAPI_BUILD
#include "rtw_capi.h"
#include "rtw_modelmap.h"

typedef struct {
  rtwCAPI_ModelMappingInfo mmi;
} pump_soft_sensor_host_DataMapInfo_T;

#ifdef __cplusplus

extern "C" {

#endif

  void pump_soft_sensor_host_InitializeDataMapInfo
    (pump_soft_sensor_host_DataMapInfo_T *dataMap, const char *path);

#ifdef __cplusplus

}
#endif
#endif                                 /* HOST_CAPI_BUILD */
#endif                             /* RTW_HEADER_pump_soft_sensor_cap_host_h_ */

/* EOF: pump_soft_sensor_capi_host.h */
