/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_dp_l.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_sys_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_external_struct.h"
#include "ssc_ml_fun.h"

int32_T pump_soft_sensor_3d73c5c7_0_gmt_dp_l(const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t65, GmtMethodOutput *t66)
{
  PmIntVector out;
  real_T parameter_update12[8];
  real_T parameter_update14[8];
  real_T parameter_update19[8];
  real_T parameter_update21[8];
  boolean_T t1[1];
  boolean_T t2[1];
  boolean_T t4[1];
  boolean_T t6[1];
  boolean_T t8[1];
  boolean_T t10[1];
  boolean_T t11[1];
  boolean_T t12[1];
  boolean_T t14[1];
  boolean_T t16[1];
  boolean_T t18[1];
  boolean_T t19[8];
  boolean_T t20[1];
  size_t t61;
  size_t t62;
  real_T P_R[43];
  P_R[0] = t65->mP_R.mX[0];
  P_R[1] = t65->mP_R.mX[1];
  P_R[2] = t65->mP_R.mX[2];
  P_R[3] = t65->mP_R.mX[3];
  P_R[4] = t65->mP_R.mX[4];
  P_R[5] = t65->mP_R.mX[5];
  P_R[6] = t65->mP_R.mX[6];
  P_R[7] = t65->mP_R.mX[7];
  P_R[8] = t65->mP_R.mX[8];
  P_R[9] = t65->mP_R.mX[9];
  P_R[10] = t65->mP_R.mX[10];
  P_R[11] = t65->mP_R.mX[11];
  P_R[12] = t65->mP_R.mX[12];
  P_R[13] = t65->mP_R.mX[13];
  P_R[14] = t65->mP_R.mX[14];
  P_R[15] = t65->mP_R.mX[15];
  P_R[16] = t65->mP_R.mX[16];
  P_R[17] = t65->mP_R.mX[17];
  P_R[18] = t65->mP_R.mX[18];
  P_R[19] = t65->mP_R.mX[19];
  P_R[20] = t65->mP_R.mX[20];
  P_R[21] = t65->mP_R.mX[21];
  P_R[22] = t65->mP_R.mX[22];
  P_R[23] = t65->mP_R.mX[23];
  P_R[24] = t65->mP_R.mX[24];
  P_R[25] = t65->mP_R.mX[25];
  P_R[26] = t65->mP_R.mX[26];
  P_R[27] = t65->mP_R.mX[27];
  P_R[28] = t65->mP_R.mX[28];
  P_R[29] = t65->mP_R.mX[29];
  P_R[30] = t65->mP_R.mX[30];
  P_R[31] = t65->mP_R.mX[31];
  P_R[32] = t65->mP_R.mX[32];
  P_R[33] = t65->mP_R.mX[33];
  P_R[34] = t65->mP_R.mX[34];
  P_R[35] = t65->mP_R.mX[35];
  P_R[36] = t65->mP_R.mX[36];
  P_R[37] = t65->mP_R.mX[37];
  P_R[38] = t65->mP_R.mX[38];
  P_R[39] = t65->mP_R.mX[39];
  P_R[40] = t65->mP_R.mX[40];
  P_R[41] = t65->mP_R.mX[41];
  P_R[42] = t65->mP_R.mX[42];
  out = t66->mDP_L;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    parameter_update12[t61] = P_R[t61 + 11ULL];
  }

  for (t62 = 0ULL; t62 < 8ULL; t62++) {
    parameter_update14[t62] = P_R[t62 + 19ULL];
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    parameter_update19[t61] = P_R[t61 + 27ULL];
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    parameter_update21[t61] = P_R[t61 + 35ULL];
  }

  t1[0ULL] = true;
  for (t61 = 0ULL; t61 < 7ULL; t61++) {
    t62 = t61 / 7ULL;
    t1[t62 > 0ULL ? 0ULL : t62] = (t1[t62 > 0ULL ? 0ULL : t62] &&
      (parameter_update12[t61 + 1ULL] * 16.666666666666664 -
       parameter_update12[t61] * 16.666666666666664 > 0.0));
  }

  t2[0ULL] = true;
  for (t61 = 0ULL; t61 < 7ULL; t61++) {
    t62 = t61 / 7ULL;
    t2[t62 > 0ULL ? 0ULL : t62] = (t2[t62 > 0ULL ? 0ULL : t62] &&
      (-(parameter_update12[t61 + 1ULL] * 16.666666666666664 -
         parameter_update12[t61] * 16.666666666666664) > 0.0));
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update12[t61] * 16.666666666666664 == parameter_update12[t61] *
       16.666666666666664));
  }

  t4[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t4[t62 > 0ULL ? 0ULL : t62] = (t4[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update12[t61] * 16.666666666666664 - parameter_update12[t61] *
       16.666666666666664 == parameter_update12[t61] * 16.666666666666664 -
       parameter_update12[t61] * 16.666666666666664));
  }

  t6[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t6[t62 > 0ULL ? 0ULL : t62] = (t6[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update19[t61] == parameter_update19[t61]));
  }

  t8[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t8[t62 > 0ULL ? 0ULL : t62] = (t8[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update19[t61] - parameter_update19[t61] ==
       parameter_update19[t61] - parameter_update19[t61]));
  }

  t10[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t10[t62 > 0ULL ? 0ULL : t62] = (t10[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  t11[0ULL] = true;
  for (t61 = 0ULL; t61 < 7ULL; t61++) {
    t62 = t61 / 7ULL;
    t11[t62 > 0ULL ? 0ULL : t62] = (t11[t62 > 0ULL ? 0ULL : t62] &&
      (parameter_update14[t61 + 1ULL] * 16.666666666666664 -
       parameter_update14[t61] * 16.666666666666664 > 0.0));
  }

  t12[0ULL] = true;
  for (t61 = 0ULL; t61 < 7ULL; t61++) {
    t62 = t61 / 7ULL;
    t12[t62 > 0ULL ? 0ULL : t62] = (t12[t62 > 0ULL ? 0ULL : t62] &&
      (-(parameter_update14[t61 + 1ULL] * 16.666666666666664 -
         parameter_update14[t61] * 16.666666666666664) > 0.0));
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update14[t61] * 16.666666666666664 == parameter_update14[t61] *
       16.666666666666664));
  }

  t14[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t14[t62 > 0ULL ? 0ULL : t62] = (t14[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update14[t61] * 16.666666666666664 - parameter_update14[t61] *
       16.666666666666664 == parameter_update14[t61] * 16.666666666666664 -
       parameter_update14[t61] * 16.666666666666664));
  }

  t16[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t16[t62 > 0ULL ? 0ULL : t62] = (t16[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update21[t61] == parameter_update21[t61]));
  }

  t18[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t18[t62 > 0ULL ? 0ULL : t62] = (t18[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61] = true;
  }

  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t19[t61 > 7ULL ? 7ULL : t61] = (t19[t61 > 7ULL ? 7ULL : t61] &&
      (parameter_update21[t61] - parameter_update21[t61] ==
       parameter_update21[t61] - parameter_update21[t61]));
  }

  t20[0ULL] = true;
  for (t61 = 0ULL; t61 < 8ULL; t61++) {
    t62 = t61 / 8ULL;
    t20[t62 > 0ULL ? 0ULL : t62] = (t20[t62 > 0ULL ? 0ULL : t62] && t19[t61]);
  }

  out.mX[0] = (int32_T)(((parameter_update12[1ULL] * 16.666666666666664 -
    parameter_update12[0ULL] * 16.666666666666664 > 0.0) && t1[0ULL]) ||
                        ((-(parameter_update12[1ULL] * 16.666666666666664 -
    parameter_update12[0ULL] * 16.666666666666664) > 0.0) && t2[0ULL]));
  out.mX[1] = (int32_T)(t4[0ULL] && t6[0ULL]);
  out.mX[2] = (int32_T)(t8[0ULL] && t10[0ULL]);
  out.mX[3] = (int32_T)(((parameter_update14[1ULL] * 16.666666666666664 -
    parameter_update14[0ULL] * 16.666666666666664 > 0.0) && t11[0ULL]) ||
                        ((-(parameter_update14[1ULL] * 16.666666666666664 -
    parameter_update14[0ULL] * 16.666666666666664) > 0.0) && t12[0ULL]));
  out.mX[4] = (int32_T)(t14[0ULL] && t16[0ULL]);
  out.mX[5] = (int32_T)(t18[0ULL] && t20[0ULL]);
  (void)sys;
  (void)t66;
  return 0;
}
