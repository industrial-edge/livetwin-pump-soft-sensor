/*
 * pump_soft_sensor_data.cpp
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "pump_soft_sensor".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Dec  1 11:06:18 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "pump_soft_sensor.h"
#include "pump_soft_sensor_private.h"

/* Block parameters (default storage) */
P_pump_soft_sensor_T pump_soft_sensorModelClass::pump_soft_sensor_P = {
  /* Variable: Angular_speed_treshold_for_flow_reversal
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  1.0E-9,

  /* Variable: Reference_angular_velocity
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  2900.0,

  /* Variable: Reference_density
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  1000.0,

  /* Variable: pressure_pipe_inlet_heigth
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  0.0,

  /* Variable: pressure_pipe_internal_diameter
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  0.1,

  /* Variable: pressure_pipe_length
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  5.0,

  /* Variable: pressure_pipe_outlet_heigth
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  0.0,

  /* Variable: pump_brake_power_vector
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  { 8.0, 12.5, 16.0, 19.0, 21.0, 24.5, 25.0, 25.5 },

  /* Variable: pump_delivery_vector_brake_power
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  { 0.0, 333.0, 666.0, 1000.0, 1333.0, 1666.0, 2000.0, 2333.0 },

  /* Variable: pump_delivery_vector_pressure_differential
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  { 0.0, 333.0, 666.0, 1000.0, 1333.0, 1666.0, 2000.0, 2333.0 },

  /* Variable: pump_pressure_differential_vector
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  { 8.1, 8.05, 7.9, 7.5, 7.0, 6.3, 5.5, 4.5 },

  /* Variable: suction_pipe_inlet_heigth
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  0.0,

  /* Variable: suction_pipe_internal_diameter
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  0.1,

  /* Variable: suction_pipe_length
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  5.0,

  /* Variable: suction_pipe_outlet_heigth
   * Referenced by: '<S13>/SWL_STATE_0'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S6>/Constant4'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S6>/Constant5'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S7>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S7>/Constant1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S7>/Switch'
   */
  0.0,

  /* Expression: 0.9
   * Referenced by: '<S7>/Switch1'
   */
  0.9,

  /* Expression: 0
   * Referenced by: '<Root>/Integrator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S6>/Switch2'
   */
  0.0,

  /* Expression: 0.9
   * Referenced by: '<S6>/Switch3'
   */
  0.9
};
