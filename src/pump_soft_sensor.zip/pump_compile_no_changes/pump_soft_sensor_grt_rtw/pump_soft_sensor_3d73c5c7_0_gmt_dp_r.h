/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */
/* pump_soft_sensor_3d73c5c7_0_gmt_dp_r.h - header for method pump_soft_sensor_3d73c5c7_0_gmt_dp_r */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef PUMP_SOFT_SENSOR_3D73C5C7_0_GMT_DP_R_H
#define PUMP_SOFT_SENSOR_3D73C5C7_0_GMT_DP_R_H 1

  extern int32_T pump_soft_sensor_3d73c5c7_0_gmt_dp_r(const GlobalMethodTable
    *sys, const NeDynamicSystemInput *in,GmtMethodOutput *ou );

#endif                      /* #ifndef PUMP_SOFT_SENSOR_3D73C5C7_0_GMT_DP_R_H */

#ifdef __cplusplus

}
#endif
