/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_mode.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_sys_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_slc_0_external_struct.h"
#include "ssc_ml_fun.h"

int32_T pump_soft_sensor_3d73c5c7_0_slc_0_mode(const SwitchedLinearClump *sys,
  const NeDynamicSystemInput *t16, SlcMethodOutput *t17)
{
  PmIntVector out;
  real_T intrm_sf_mf_1;
  real_T t15;
  int32_T t0_idx_7;
  int32_T t0_idx_8;
  int32_T t0_idx_12;
  int32_T t0_idx_13;
  real_T U_idx_0;
  real_T X_idx_2;
  real_T DP_R_idx_1;
  real_T DP_R_idx_0;
  real_T DP_R_idx_4;
  real_T DP_R_idx_3;
  real_T DP_R_idx_9;
  real_T DP_R_idx_10;
  real_T DP_R_idx_30;
  real_T DP_R_idx_31;
  real_T DP_R_idx_32;
  real_T DP_R_idx_7;
  real_T DP_R_idx_28;
  real_T DP_R_idx_29;
  U_idx_0 = t16->mU.mX[0];
  X_idx_2 = t16->mX.mX[2];
  DP_R_idx_0 = t16->mDP_R.mX[0];
  DP_R_idx_1 = t16->mDP_R.mX[1];
  DP_R_idx_3 = t16->mDP_R.mX[3];
  DP_R_idx_4 = t16->mDP_R.mX[4];
  DP_R_idx_7 = t16->mDP_R.mX[7];
  DP_R_idx_9 = t16->mDP_R.mX[9];
  DP_R_idx_10 = t16->mDP_R.mX[10];
  DP_R_idx_28 = t16->mDP_R.mX[28];
  DP_R_idx_29 = t16->mDP_R.mX[29];
  DP_R_idx_30 = t16->mDP_R.mX[30];
  DP_R_idx_31 = t16->mDP_R.mX[31];
  DP_R_idx_32 = t16->mDP_R.mX[32];
  out = t17->mMODE;
  t15 = X_idx_2 * 0.00099779981710000024;
  intrm_sf_mf_1 = t15 * DP_R_idx_1 * (t15 * 1002.2050343789342 >= 0.0 ? 1.0 :
    -1.0) * 1002.2050343789342 / (DP_R_idx_0 == 0.0 ? 1.0E-16 : DP_R_idx_0) /
    1.0056478624965173E-6;
  DP_R_idx_1 = DP_R_idx_4 * X_idx_2 * (X_idx_2 >= 0.0 ? 1.0 : -1.0) /
    (DP_R_idx_3 == 0.0 ? 1.0E-16 : DP_R_idx_3) / 1.0056478624965173E-6;
  if (U_idx_0 >= 0.0) {
    DP_R_idx_0 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R_idx_9 * DP_R_idx_9);
  } else {
    DP_R_idx_0 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R_idx_9 * DP_R_idx_9);
  }

  DP_R_idx_0 = DP_R_idx_10 * 0.10471975511965977 / (DP_R_idx_0 == 0.0 ? 1.0E-16 :
    DP_R_idx_0);
  t0_idx_7 = (int32_T)((!(DP_R_idx_1 != 0.0)) || (!(DP_R_idx_7 / 3.7 >= 0.0)) ||
                       (DP_R_idx_1 * 1.0000000000000002E-6 <= 200.0) || (6.9 /
    (DP_R_idx_1 == 0.0 ? 1.0E-16 : DP_R_idx_1) * 999999.99999999988 + pmf_pow
    (DP_R_idx_7 / 3.7, 1.11) > 0.0));
  t0_idx_8 = (int32_T)((!(DP_R_idx_1 != 0.0)) || (!(DP_R_idx_7 / 3.7 >= 0.0)) ||
                       ((DP_R_idx_1 != 0.0) && (DP_R_idx_7 / 3.7 >= 0.0) &&
                        (!(6.9 / (DP_R_idx_1 == 0.0 ? 1.0E-16 : DP_R_idx_1) *
    999999.99999999988 + pmf_pow(DP_R_idx_7 / 3.7, 1.11) > 0.0))) || (DP_R_idx_1
    * 1.0000000000000002E-6 <= 200.0) || (pmf_log10(6.9 / (DP_R_idx_1 == 0.0 ?
    1.0E-16 : DP_R_idx_1) * 999999.99999999988 + pmf_pow(DP_R_idx_7 / 3.7, 1.11))
    * pmf_log10(6.9 / (DP_R_idx_1 == 0.0 ? 1.0E-16 : DP_R_idx_1) *
                999999.99999999988 + pmf_pow(DP_R_idx_7 / 3.7, 1.11)) * 3.24 !=
    0.0));
  t0_idx_12 = (int32_T)((!(intrm_sf_mf_1 != 0.0)) || (!(DP_R_idx_28 / 3.7 >= 0.0))
                        || (intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
                        (6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 : intrm_sf_mf_1) *
    999999.99999999988 + pmf_pow(DP_R_idx_28 / 3.7, 1.11) > 0.0));
  t0_idx_13 = (int32_T)((!(intrm_sf_mf_1 != 0.0)) || (!(DP_R_idx_28 / 3.7 >= 0.0))
                        || ((intrm_sf_mf_1 != 0.0) && (DP_R_idx_28 / 3.7 >= 0.0)
    && (!(6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 : intrm_sf_mf_1) *
          999999.99999999988 + pmf_pow(DP_R_idx_28 / 3.7, 1.11) > 0.0))) ||
                        (intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
                        (pmf_log10(6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 :
    intrm_sf_mf_1) * 999999.99999999988 + pmf_pow(DP_R_idx_28 / 3.7, 1.11)) *
    pmf_log10(6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 : intrm_sf_mf_1) *
              999999.99999999988 + pmf_pow(DP_R_idx_28 / 3.7, 1.11)) * 3.24 !=
    0.0));
  out.mX[0] = (int32_T)(intrm_sf_mf_1 * 1.0000000000000002E-6 <= 2000.0);
  out.mX[1] = (int32_T)(intrm_sf_mf_1 * 1.0000000000000002E-6 <= 4000.0);
  out.mX[2] = (int32_T)(DP_R_idx_0 * X_idx_2 <= DP_R_idx_30);
  out.mX[3] = (int32_T)(DP_R_idx_0 * X_idx_2 < DP_R_idx_31);
  out.mX[4] = (int32_T)(DP_R_idx_0 * X_idx_2 <= DP_R_idx_32);
  out.mX[5] = (int32_T)((DP_R_idx_1 * 1.0000000000000002E-6 <= 200.0) ||
                        (DP_R_idx_1 != 0.0));
  out.mX[6] = 1;
  out.mX[7] = t0_idx_7;
  out.mX[8] = t0_idx_8;
  out.mX[9] = (int32_T)(t15 * 1002.2050343789342 >= 0.0);
  out.mX[10] = (int32_T)((intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
    (intrm_sf_mf_1 != 0.0));
  out.mX[11] = 1;
  out.mX[12] = t0_idx_12;
  out.mX[13] = t0_idx_13;
  out.mX[14] = (int32_T)(intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0);
  out.mX[15] = (int32_T)(DP_R_idx_1 * 1.0000000000000002E-6 <= 2000.0);
  out.mX[16] = (int32_T)(DP_R_idx_1 * 1.0000000000000002E-6 <= 4000.0);
  out.mX[17] = (int32_T)(X_idx_2 >= 0.0);
  out.mX[18] = (int32_T)(DP_R_idx_1 * 1.0000000000000002E-6 <= 200.0);
  out.mX[19] = (int32_T)(DP_R_idx_0 * X_idx_2 < DP_R_idx_29);
  (void)sys;
  (void)t17;
  return 0;
}
