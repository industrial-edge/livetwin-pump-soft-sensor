/*
 * pump_soft_sensor.h
 *
 * Sponsored Third Party Support License -- for use only to support
 * products interfaced to MathWorks software under terms specified in your
 * company's restricted use license agreement.
 *
 * Code generation for model "pump_soft_sensor".
 *
 * Model version              : 1.3
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C++ source code generated on : Thu Dec  1 11:06:18 2022
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Linux 64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_pump_soft_sensor_h_
#define RTW_HEADER_pump_soft_sensor_h_
#include <cmath>
#include <cstring>
#include <stddef.h>
#include "rtw_modelmap.h"
#ifndef pump_soft_sensor_COMMON_INCLUDES_
# define pump_soft_sensor_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_simulator.h"
#endif                                 /* pump_soft_sensor_COMMON_INCLUDES_ */

#include "pump_soft_sensor_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetContStateDisabled
# define rtmGetContStateDisabled(rtm)  ((rtm)->contStateDisabled)
#endif

#ifndef rtmSetContStateDisabled
# define rtmSetContStateDisabled(rtm, val) ((rtm)->contStateDisabled = (val))
#endif

#ifndef rtmGetContStates
# define rtmGetContStates(rtm)         ((rtm)->contStates)
#endif

#ifndef rtmSetContStates
# define rtmSetContStates(rtm, val)    ((rtm)->contStates = (val))
#endif

#ifndef rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmGetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm) ((rtm)->CTOutputIncnstWithState)
#endif

#ifndef rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag
# define rtmSetContTimeOutputInconsistentWithStateAtMajorStepFlag(rtm, val) ((rtm)->CTOutputIncnstWithState = (val))
#endif

#ifndef rtmGetDataMapInfo
# define rtmGetDataMapInfo(rtm)        ((rtm)->DataMapInfo)
#endif

#ifndef rtmSetDataMapInfo
# define rtmSetDataMapInfo(rtm, val)   ((rtm)->DataMapInfo = (val))
#endif

#ifndef rtmGetDerivCacheNeedsReset
# define rtmGetDerivCacheNeedsReset(rtm) ((rtm)->derivCacheNeedsReset)
#endif

#ifndef rtmSetDerivCacheNeedsReset
# define rtmSetDerivCacheNeedsReset(rtm, val) ((rtm)->derivCacheNeedsReset = (val))
#endif

#ifndef rtmGetIntgData
# define rtmGetIntgData(rtm)           ((rtm)->intgData)
#endif

#ifndef rtmSetIntgData
# define rtmSetIntgData(rtm, val)      ((rtm)->intgData = (val))
#endif

#ifndef rtmGetOdeF
# define rtmGetOdeF(rtm)               ((rtm)->odeF)
#endif

#ifndef rtmSetOdeF
# define rtmSetOdeF(rtm, val)          ((rtm)->odeF = (val))
#endif

#ifndef rtmGetOdeY
# define rtmGetOdeY(rtm)               ((rtm)->odeY)
#endif

#ifndef rtmSetOdeY
# define rtmSetOdeY(rtm, val)          ((rtm)->odeY = (val))
#endif

#ifndef rtmGetPeriodicContStateIndices
# define rtmGetPeriodicContStateIndices(rtm) ((rtm)->periodicContStateIndices)
#endif

#ifndef rtmSetPeriodicContStateIndices
# define rtmSetPeriodicContStateIndices(rtm, val) ((rtm)->periodicContStateIndices = (val))
#endif

#ifndef rtmGetPeriodicContStateRanges
# define rtmGetPeriodicContStateRanges(rtm) ((rtm)->periodicContStateRanges)
#endif

#ifndef rtmSetPeriodicContStateRanges
# define rtmSetPeriodicContStateRanges(rtm, val) ((rtm)->periodicContStateRanges = (val))
#endif

#ifndef rtmGetZCCacheNeedsReset
# define rtmGetZCCacheNeedsReset(rtm)  ((rtm)->zCCacheNeedsReset)
#endif

#ifndef rtmSetZCCacheNeedsReset
# define rtmSetZCCacheNeedsReset(rtm, val) ((rtm)->zCCacheNeedsReset = (val))
#endif

#ifndef rtmGetdX
# define rtmGetdX(rtm)                 ((rtm)->derivs)
#endif

#ifndef rtmSetdX
# define rtmSetdX(rtm, val)            ((rtm)->derivs = (val))
#endif

#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

#ifndef rtmGetStopRequested
# define rtmGetStopRequested(rtm)      ((rtm)->Timing.stopRequestedFlag)
#endif

#ifndef rtmSetStopRequested
# define rtmSetStopRequested(rtm, val) ((rtm)->Timing.stopRequestedFlag = (val))
#endif

#ifndef rtmGetStopRequestedPtr
# define rtmGetStopRequestedPtr(rtm)   (&((rtm)->Timing.stopRequestedFlag))
#endif

#ifndef rtmGetT
# define rtmGetT(rtm)                  (rtmGetTPtr((rtm))[0])
#endif

#ifndef rtmGetTPtr
# define rtmGetTPtr(rtm)               ((rtm)->Timing.t)
#endif

/* Block signals (default storage) */
typedef struct {
  real_T INPUT_1_1_1[4];               /* '<S13>/INPUT_1_1_1' */
  real_T SWL_STATE_0[3];               /* '<S13>/SWL_STATE_0' */
} B_pump_soft_sensor_T;

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T INPUT_1_1_1_Discrete[2];      /* '<S13>/INPUT_1_1_1' */
  real_T SWL_STATE_0_Discrete[35];     /* '<S13>/SWL_STATE_0' */
  real_T SWL_STATE_0_FirstOutput;      /* '<S13>/SWL_STATE_0' */
  real_T SWL_STATE_0_Inputs;           /* '<S13>/SWL_STATE_0' */
  void* SWL_STATE_0_DiagMgr;           /* '<S13>/SWL_STATE_0' */
  void* SWL_STATE_0_DiagTree;          /* '<S13>/SWL_STATE_0' */
  void* SWL_STATE_0_SimulatorPtr;      /* '<S13>/SWL_STATE_0' */
  void* SWL_STATE_0_StateDirPtr;       /* '<S13>/SWL_STATE_0' */
} DW_pump_soft_sensor_T;

/* Continuous states (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<Root>/Integrator' */
} X_pump_soft_sensor_T;

/* State derivatives (default storage) */
typedef struct {
  real_T Integrator_CSTATE;            /* '<Root>/Integrator' */
} XDot_pump_soft_sensor_T;

/* State disabled  */
typedef struct {
  boolean_T Integrator_CSTATE;         /* '<Root>/Integrator' */
} XDis_pump_soft_sensor_T;

#ifndef ODE3_INTG
#define ODE3_INTG

/* ODE3 Integration Data */
typedef struct {
  real_T *y;                           /* output */
  real_T *f[3];                        /* derivatives */
} ODE3_IntgData;

#endif

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T flowrate_sensor_m3h;          /* '<Root>/flowrate_sensor_m^3//h' */
  real_T pump_speed;                   /* '<Root>/pump_speed' */
  real_T pumppressure_sensor_Pa;       /* '<Root>/pumppressure_sensor_Pa' */
} ExtU_pump_soft_sensor_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T flowrate_ls;                  /* '<Root>/flowrate_l//s' */
  real_T pump_pressure_Pa;             /* '<Root>/pump_pressure_Pa' */
  real_T flowrate_m3s;                 /* '<Root>/flowrate_m^3//s' */
  real_T flowrate_m3h;                 /* '<Root>/flowrate_m^3//h' */
  real_T flowrate_lmin;                /* '<Root>/flowrate_l//min' */
  real_T angle_velocity;               /* '<Root>/angle_velocity' */
  real_T volume_in_m3;                 /* '<Root>/volume_in_m^3' */
  real_T flowrate_delta_m3h;           /* '<Root>/flowrate_delta_m^3//h' */
  real_T pumppressure_delta_Pa;        /* '<Root>/pumppressure_delta_Pa' */
  real_T control_pumppressure;         /* '<Root>/control_pumppressure' */
  real_T control_flowrate;             /* '<Root>/control_flowrate' */
} ExtY_pump_soft_sensor_T;

/* Parameters (default storage) */
struct P_pump_soft_sensor_T_ {
  real_T Angular_speed_treshold_for_flow_reversal;
                           /* Variable: Angular_speed_treshold_for_flow_reversal
                            * Referenced by: '<S13>/SWL_STATE_0'
                            */
  real_T Reference_angular_velocity;   /* Variable: Reference_angular_velocity
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T Reference_density;            /* Variable: Reference_density
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T pressure_pipe_inlet_heigth;   /* Variable: pressure_pipe_inlet_heigth
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T pressure_pipe_internal_diameter;
                                    /* Variable: pressure_pipe_internal_diameter
                                     * Referenced by: '<S13>/SWL_STATE_0'
                                     */
  real_T pressure_pipe_length;         /* Variable: pressure_pipe_length
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T pressure_pipe_outlet_heigth;  /* Variable: pressure_pipe_outlet_heigth
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T pump_brake_power_vector[8];   /* Variable: pump_brake_power_vector
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T pump_delivery_vector_brake_power[8];
                                   /* Variable: pump_delivery_vector_brake_power
                                    * Referenced by: '<S13>/SWL_STATE_0'
                                    */
  real_T pump_delivery_vector_pressure_differential[8];
                         /* Variable: pump_delivery_vector_pressure_differential
                          * Referenced by: '<S13>/SWL_STATE_0'
                          */
  real_T pump_pressure_differential_vector[8];
                                  /* Variable: pump_pressure_differential_vector
                                   * Referenced by: '<S13>/SWL_STATE_0'
                                   */
  real_T suction_pipe_inlet_heigth;    /* Variable: suction_pipe_inlet_heigth
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T suction_pipe_internal_diameter;
                                     /* Variable: suction_pipe_internal_diameter
                                      * Referenced by: '<S13>/SWL_STATE_0'
                                      */
  real_T suction_pipe_length;          /* Variable: suction_pipe_length
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T suction_pipe_outlet_heigth;   /* Variable: suction_pipe_outlet_heigth
                                        * Referenced by: '<S13>/SWL_STATE_0'
                                        */
  real_T Constant4_Value;              /* Expression: 1
                                        * Referenced by: '<S6>/Constant4'
                                        */
  real_T Constant5_Value;              /* Expression: 0
                                        * Referenced by: '<S6>/Constant5'
                                        */
  real_T Constant_Value;               /* Expression: 1
                                        * Referenced by: '<S7>/Constant'
                                        */
  real_T Constant1_Value;              /* Expression: 0
                                        * Referenced by: '<S7>/Constant1'
                                        */
  real_T Switch_Threshold;             /* Expression: 0
                                        * Referenced by: '<S7>/Switch'
                                        */
  real_T Switch1_Threshold;            /* Expression: 0.9
                                        * Referenced by: '<S7>/Switch1'
                                        */
  real_T Integrator_IC;                /* Expression: 0
                                        * Referenced by: '<Root>/Integrator'
                                        */
  real_T Switch2_Threshold;            /* Expression: 0
                                        * Referenced by: '<S6>/Switch2'
                                        */
  real_T Switch3_Threshold;            /* Expression: 0.9
                                        * Referenced by: '<S6>/Switch3'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_pump_soft_sensor_T {
  const char_T *errorStatus;
  RTWSolverInfo solverInfo;
  X_pump_soft_sensor_T *contStates;
  int_T *periodicContStateIndices;
  real_T *periodicContStateRanges;
  real_T *derivs;
  boolean_T *contStateDisabled;
  boolean_T zCCacheNeedsReset;
  boolean_T derivCacheNeedsReset;
  boolean_T CTOutputIncnstWithState;
  real_T odeY[1];
  real_T odeF[3][1];
  ODE3_IntgData intgData;

  /*
   * DataMapInfo:
   * The following substructure contains information regarding
   * structures generated in the model's C API.
   */
  struct {
    rtwCAPI_ModelMappingInfo mmi;
    void* dataAddress[30];
    int32_T* vardimsAddress[30];
    RTWLoggingFcnPtr loggingPtrs[30];
  } DataMapInfo;

  /*
   * Sizes:
   * The following substructure contains sizes information
   * for many of the model attributes such as inputs, outputs,
   * dwork, sample times, etc.
   */
  struct {
    int_T numContStates;
    int_T numPeriodicContStates;
    int_T numSampTimes;
  } Sizes;

  /*
   * Timing:
   * The following substructure contains information regarding
   * the timing information for the model.
   */
  struct {
    uint32_T clockTick0;
    uint32_T clockTickH0;
    time_T stepSize0;
    uint32_T clockTick1;
    uint32_T clockTickH1;
    SimTimeStep simTimeStep;
    boolean_T stopRequestedFlag;
    time_T *t;
    time_T tArray[2];
  } Timing;
};

/* Function to get C API Model Mapping Static Info */
extern const rtwCAPI_ModelMappingStaticInfo*
  pump_soft_sensor_GetCAPIStaticMap(void);

/* Class declaration for model pump_soft_sensor */
class pump_soft_sensorModelClass {
  /* public data and function members */
 public:
  /* External inputs */
  ExtU_pump_soft_sensor_T pump_soft_sensor_U;

  /* External outputs */
  ExtY_pump_soft_sensor_T pump_soft_sensor_Y;

  /* model initialize function */
  void initialize();

  /* model step function */
  void step();

  /* model terminate function */
  void terminate();

  /* Constructor */
  pump_soft_sensorModelClass();

  /* Destructor */
  ~pump_soft_sensorModelClass();

  /* Real-Time Model get method */
  RT_MODEL_pump_soft_sensor_T * getRTM();

  /* private data and function members */
 private:
  /* Tunable parameters */
  static P_pump_soft_sensor_T pump_soft_sensor_P;

  /* Block signals */
  B_pump_soft_sensor_T pump_soft_sensor_B;

  /* Block states */
  DW_pump_soft_sensor_T pump_soft_sensor_DW;
  X_pump_soft_sensor_T pump_soft_sensor_X;/* Block continuous states */

  /* Real-Time Model */
  RT_MODEL_pump_soft_sensor_T pump_soft_sensor_M;

  /* Continuous states update member function*/
  void rt_ertODEUpdateContinuousStates(RTWSolverInfo *si );

  /* Derivatives member function */
  void pump_soft_sensor_derivatives();
};

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'pump_soft_sensor'
 * '<S1>'   : 'pump_soft_sensor/PS-Simulink Converter'
 * '<S2>'   : 'pump_soft_sensor/PS-Simulink Converter3'
 * '<S3>'   : 'pump_soft_sensor/PS-Simulink Converter4'
 * '<S4>'   : 'pump_soft_sensor/Simulink-PS Converter'
 * '<S5>'   : 'pump_soft_sensor/Solver Configuration'
 * '<S6>'   : 'pump_soft_sensor/calculation flowrate delta'
 * '<S7>'   : 'pump_soft_sensor/calculation pumppressure delta'
 * '<S8>'   : 'pump_soft_sensor/hydraulic systems'
 * '<S9>'   : 'pump_soft_sensor/PS-Simulink Converter/EVAL_KEY'
 * '<S10>'  : 'pump_soft_sensor/PS-Simulink Converter3/EVAL_KEY'
 * '<S11>'  : 'pump_soft_sensor/PS-Simulink Converter4/EVAL_KEY'
 * '<S12>'  : 'pump_soft_sensor/Simulink-PS Converter/EVAL_KEY'
 * '<S13>'  : 'pump_soft_sensor/Solver Configuration/EVAL_KEY'
 */
#endif                                 /* RTW_HEADER_pump_soft_sensor_h_ */
