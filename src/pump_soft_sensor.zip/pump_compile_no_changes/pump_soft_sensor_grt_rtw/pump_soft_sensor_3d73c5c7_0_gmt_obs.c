/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_obs.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_sys_struct.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_externals.h"
#include "pump_soft_sensor_3d73c5c7_0_gmt_external_struct.h"
#include "ssc_ml_fun.h"

int32_T pump_soft_sensor_3d73c5c7_0_gmt_obs(const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t2, GmtMethodOutput *t3)
{
  PmRealVector out;
  real_T hydraulic_systems_Resistive_Pipe_LP3_p;
  real_T hydraulic_systems_hydraulic_flow_rate_sensor_M;
  real_T hydraulic_systems_hydraulic_pressure_sensor_P;
  real_T U_idx_0;
  real_T X_idx_1;
  real_T X_idx_2;
  real_T X_idx_3;
  real_T X_idx_0;
  U_idx_0 = t2->mU.mX[0];
  X_idx_0 = t2->mX.mX[0];
  X_idx_1 = t2->mX.mX[1];
  X_idx_2 = t2->mX.mX[2];
  X_idx_3 = t2->mX.mX[3];
  out = t3->mOBS;
  hydraulic_systems_Resistive_Pipe_LP3_p = -X_idx_1 + X_idx_2;
  hydraulic_systems_hydraulic_flow_rate_sensor_M = X_idx_3 *
    0.00099779981710000024;
  hydraulic_systems_hydraulic_pressure_sensor_P =
    -(hydraulic_systems_Resistive_Pipe_LP3_p - (-X_idx_1)) / -1.0;
  out.mX[0] = 0.0;
  out.mX[1] = 0.0;
  out.mX[2] = 0.0;
  out.mX[3] = U_idx_0;
  out.mX[4] = U_idx_0;
  out.mX[5] = X_idx_0;
  out.mX[6] = U_idx_0;
  out.mX[7] = 0.0;
  out.mX[8] = 0.0;
  out.mX[9] = hydraulic_systems_Resistive_Pipe_LP3_p * 99999.999999999985;
  out.mX[10] = -X_idx_1 * 99999.999999999985;
  out.mX[11] = 0.0;
  out.mX[12] = 0.0;
  out.mX[13] = 0.0;
  out.mX[14] = 0.0;
  out.mX[15] = hydraulic_systems_hydraulic_flow_rate_sensor_M;
  out.mX[16] = hydraulic_systems_hydraulic_flow_rate_sensor_M *
    0.0010022050343789343;
  out.mX[17] = 0.0;
  out.mX[18] = hydraulic_systems_hydraulic_flow_rate_sensor_M *
    0.0010022050343789343;
  out.mX[19] = 0.0;
  out.mX[20] = hydraulic_systems_Resistive_Pipe_LP3_p * 99999.999999999985;
  out.mX[21] = -X_idx_1 * 99999.999999999985;
  out.mX[22] = hydraulic_systems_hydraulic_pressure_sensor_P *
    99999.999999999985;
  out.mX[23] = hydraulic_systems_hydraulic_pressure_sensor_P *
    99999.999999999985;
  out.mX[24] = 0.0;
  out.mX[25] = hydraulic_systems_Resistive_Pipe_LP3_p * 99999.999999999985;
  out.mX[26] = 0.0;
  out.mX[27] = hydraulic_systems_hydraulic_flow_rate_sensor_M *
    0.0010022050343789343;
  out.mX[28] = hydraulic_systems_Resistive_Pipe_LP3_p * 99999.999999999985;
  out.mX[29] = 0.0;
  out.mX[30] = -X_idx_1 * 99999.999999999985;
  out.mX[31] = X_idx_3 * 1.0000000000000002E-6;
  out.mX[32] = X_idx_1 * 99999.999999999985;
  out.mX[33] = hydraulic_systems_Resistive_Pipe_LP3_p * 99999.999999999985;
  out.mX[34] = U_idx_0;
  out.mX[35] = -X_idx_1 * 99999.999999999985;
  out.mX[36] = hydraulic_systems_Resistive_Pipe_LP3_p * 99999.999999999985;
  out.mX[37] = U_idx_0;
  out.mX[38] = -X_idx_1 * 99999.999999999985;
  out.mX[39] = X_idx_2 * 99999.999999999985;
  out.mX[40] = X_idx_3 * 1.0000000000000002E-6;
  out.mX[41] = -X_idx_0;
  out.mX[42] = U_idx_0;
  (void)sys;
  (void)t3;
  return 0;
}
