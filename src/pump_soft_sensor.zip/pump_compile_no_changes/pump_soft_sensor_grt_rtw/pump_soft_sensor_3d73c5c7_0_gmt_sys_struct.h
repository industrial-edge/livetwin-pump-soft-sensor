/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'pump_soft_sensor/Solver Configuration'.
 */

#ifndef struct__GlobalMethodTableTag
#define struct__GlobalMethodTableTag

typedef struct _GlobalMethodTableTag {
  GlobalMethodTable mBase;
  int32_T mRefCnt;
  PmAllocator mAlloc;
} _GlobalMethodTable;

#else

typedef struct _GlobalMethodTableTag _GlobalMethodTable;

#endif
