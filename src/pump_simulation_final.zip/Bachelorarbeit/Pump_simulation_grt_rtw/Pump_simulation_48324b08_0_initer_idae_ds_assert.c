/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_assert.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_sys_struct.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_externals.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_initer_idae_ds_assert(const NeDynamicSystem
  *sys, const NeDynamicSystemInput *t16, NeDsMethodOutput *t17)
{
  PmIntVector out;
  real_T intrm_sf_mf_1;
  real_T intrm_sf_mf_24;
  real_T DP_R[101];
  int32_T t0_idx_4;
  int32_T t0_idx_7;
  int32_T t0_idx_34;
  int32_T t0_idx_37;
  real_T U_idx_0;
  real_T X_idx_3;
  U_idx_0 = t16->mU.mX[0];
  X_idx_3 = t16->mX.mX[3];
  for (t0_idx_4 = 0; t0_idx_4 < 101; t0_idx_4++) {
    DP_R[t0_idx_4] = t16->mDP_R.mX[t0_idx_4];
  }

  out = t17->mASSERT;
  intrm_sf_mf_1 = X_idx_3 * 0.00099779981710000024;
  intrm_sf_mf_1 = intrm_sf_mf_1 * DP_R[0ULL] * (intrm_sf_mf_1 *
    1002.2050343789342 >= 0.0 ? 1.0 : -1.0) * 1002.2050343789342 / (DP_R[1ULL] ==
    0.0 ? 1.0E-16 : DP_R[1ULL]) / 1.0056478624965173E-6;
  X_idx_3 = DP_R[6ULL] * X_idx_3 * (X_idx_3 >= 0.0 ? 1.0 : -1.0) / (DP_R[7ULL] ==
    0.0 ? 1.0E-16 : DP_R[7ULL]) / 1.0056478624965173E-6;
  if (U_idx_0 >= 0.0) {
    intrm_sf_mf_24 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  } else {
    intrm_sf_mf_24 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  }

  t0_idx_4 = (int32_T)((!(X_idx_3 != 0.0)) || (!(DP_R[15ULL] / 3.7 >= 0.0)) ||
                       (X_idx_3 * 1.0000000000000002E-6 <= 200.0) || (6.9 /
    (X_idx_3 == 0.0 ? 1.0E-16 : X_idx_3) * 999999.99999999988 + pmf_pow(DP_R
    [15ULL] / 3.7, 1.11) > 0.0));
  t0_idx_7 = (int32_T)((!(X_idx_3 != 0.0)) || (!(DP_R[15ULL] / 3.7 >= 0.0)) ||
                       ((X_idx_3 != 0.0) && (DP_R[15ULL] / 3.7 >= 0.0) && (!(6.9
    / (X_idx_3 == 0.0 ? 1.0E-16 : X_idx_3) * 999999.99999999988 + pmf_pow(DP_R
    [15ULL] / 3.7, 1.11) > 0.0))) || (X_idx_3 * 1.0000000000000002E-6 <= 200.0) ||
                       (pmf_log10(6.9 / (X_idx_3 == 0.0 ? 1.0E-16 : X_idx_3) *
    999999.99999999988 + pmf_pow(DP_R[15ULL] / 3.7, 1.11)) * pmf_log10(6.9 /
    (X_idx_3 == 0.0 ? 1.0E-16 : X_idx_3) * 999999.99999999988 + pmf_pow(DP_R
    [15ULL] / 3.7, 1.11)) * 3.24 != 0.0));
  t0_idx_34 = (int32_T)((!(intrm_sf_mf_1 != 0.0)) || (!(DP_R[76ULL] / 3.7 >= 0.0))
                        || (intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
                        (6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 : intrm_sf_mf_1) *
    999999.99999999988 + pmf_pow(DP_R[76ULL] / 3.7, 1.11) > 0.0));
  t0_idx_37 = (int32_T)((!(intrm_sf_mf_1 != 0.0)) || (!(DP_R[76ULL] / 3.7 >= 0.0))
                        || ((intrm_sf_mf_1 != 0.0) && (DP_R[76ULL] / 3.7 >= 0.0)
    && (!(6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 : intrm_sf_mf_1) *
          999999.99999999988 + pmf_pow(DP_R[76ULL] / 3.7, 1.11) > 0.0))) ||
                        (intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
                        (pmf_log10(6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 :
    intrm_sf_mf_1) * 999999.99999999988 + pmf_pow(DP_R[76ULL] / 3.7, 1.11)) *
    pmf_log10(6.9 / (intrm_sf_mf_1 == 0.0 ? 1.0E-16 : intrm_sf_mf_1) *
              999999.99999999988 + pmf_pow(DP_R[76ULL] / 3.7, 1.11)) * 3.24 !=
    0.0));
  out.mX[0] = (int32_T)((X_idx_3 * 1.0000000000000002E-6 <= 200.0) || (X_idx_3
    != 0.0));
  out.mX[1] = 1;
  out.mX[2] = 1;
  out.mX[3] = (int32_T)((X_idx_3 * 1.0000000000000002E-6 <= 200.0) || (DP_R
    [15ULL] / 3.7 >= 0.0));
  out.mX[4] = t0_idx_4;
  out.mX[5] = 1;
  out.mX[6] = 1;
  out.mX[7] = t0_idx_7;
  out.mX[8] = 1;
  out.mX[9] = 1;
  out.mX[10] = 1;
  out.mX[11] = 1;
  out.mX[12] = 1;
  out.mX[13] = 1;
  out.mX[14] = 1;
  out.mX[15] = 1;
  out.mX[16] = (int32_T)((!(U_idx_0 >= 0.0)) || (U_idx_0 * U_idx_0 + DP_R[49ULL]
    * DP_R[49ULL] >= 0.0));
  out.mX[17] = 1;
  out.mX[18] = 1;
  out.mX[19] = 1;
  out.mX[20] = 1;
  out.mX[21] = (int32_T)((U_idx_0 >= 0.0) || (U_idx_0 * U_idx_0 + DP_R[49ULL] *
    DP_R[49ULL] >= 0.0));
  out.mX[22] = (int32_T)(intrm_sf_mf_24 != 0.0);
  out.mX[23] = 1;
  out.mX[24] = 1;
  out.mX[25] = (int32_T)((!(DP_R[50ULL] * 0.10471975511965977 != 0.0)) || (DP_R
    [51ULL] != 0.0));
  out.mX[26] = 1;
  out.mX[27] = 1;
  out.mX[28] = (int32_T)(DP_R[50ULL] * DP_R[50ULL] * DP_R[50ULL] *
    0.001148380617788882 != 0.0);
  out.mX[29] = (int32_T)((!(DP_R[50ULL] * DP_R[50ULL] * DP_R[50ULL] *
    0.001148380617788882 != 0.0)) || (DP_R[51ULL] != 0.0));
  out.mX[30] = (int32_T)((intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
    (intrm_sf_mf_1 != 0.0));
  out.mX[31] = 1;
  out.mX[32] = 1;
  out.mX[33] = (int32_T)((intrm_sf_mf_1 * 1.0000000000000002E-6 <= 200.0) ||
    (DP_R[76ULL] / 3.7 >= 0.0));
  out.mX[34] = t0_idx_34;
  out.mX[35] = 1;
  out.mX[36] = 1;
  out.mX[37] = t0_idx_37;
  out.mX[38] = 1;
  out.mX[39] = 1;
  out.mX[40] = 1;
  out.mX[41] = 1;
  (void)sys;
  (void)t17;
  return 0;
}
