/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef struct__SwitchedLinearSystemTag
#define struct__SwitchedLinearSystemTag

typedef struct _SwitchedLinearSystemTag {
  SwitchedLinearSystem mBase;
  int32_T mRefCnt;
  PmAllocator mAlloc;
} _SwitchedLinearSystem;

#else

typedef struct _SwitchedLinearSystemTag _SwitchedLinearSystem;

#endif
