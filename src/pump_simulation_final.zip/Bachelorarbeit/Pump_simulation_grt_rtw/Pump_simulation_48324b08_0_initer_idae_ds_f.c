/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_f.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_sys_struct.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_externals.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_initer_idae_ds_f(const NeDynamicSystem *sys,
  const NeDynamicSystemInput *t60, NeDsMethodOutput *t61)
{
  PmRealVector out;
  real_T intrm_sf_mf_20;
  real_T intrm_sf_mf_8;
  real_T intrm_sf_mf_9;
  real_T t4[8];
  real_T t7[8];
  real_T t9[1];
  size_t t14;
  real_T t15;
  real_T t17;
  real_T t18;
  real_T t19;
  real_T t20;
  real_T t49;
  real_T t51;
  real_T DP_R[101];
  ETTS0 efOut;
  ETTS0 b_efOut;
  real_T c_efOut[1];
  real_T d_efOut[1];
  int32_T b;
  real_T U_idx_0;
  real_T X_idx_3;
  U_idx_0 = t60->mU.mX[0];
  X_idx_3 = t60->mX.mX[3];
  for (b = 0; b < 101; b++) {
    DP_R[b] = t60->mDP_R.mX[b];
  }

  out = t61->mF;
  intrm_sf_mf_9 = X_idx_3 * 0.00099779981710000024;
  intrm_sf_mf_8 = intrm_sf_mf_9 * 1002.2050343789342 >= 0.0 ? 1.0 : -1.0;
  t15 = intrm_sf_mf_9 * DP_R[0ULL] * intrm_sf_mf_8 * 1002.2050343789342 / (DP_R
    [1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) / 1.0056478624965173E-6;
  t17 = X_idx_3 >= 0.0 ? 1.0 : -1.0;
  t18 = DP_R[6ULL] * X_idx_3 * t17 / (DP_R[7ULL] == 0.0 ? 1.0E-16 : DP_R[7ULL]) /
    1.0056478624965173E-6;
  if (t18 * 1.0000000000000002E-6 <= 200.0) {
    t20 = 0.0;
  } else {
    t49 = pmf_log10(6.9 / (t18 == 0.0 ? 1.0E-16 : t18) * 999999.99999999988 +
                    pmf_pow(DP_R[15ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t18 ==
      0.0 ? 1.0E-16 : t18) * 999999.99999999988 + pmf_pow(DP_R[15ULL] / 3.7,
      1.11)) * 3.24;
    t20 = 1.0 / (t49 == 0.0 ? 1.0E-16 : t49);
  }

  t49 = DP_R[6ULL] * DP_R[6ULL];
  t19 = DP_R[11ULL] * 6.4361463199777107E-5 / (t49 == 0.0 ? 1.0E-16 : t49) /
    (DP_R[7ULL] == 0.0 ? 1.0E-16 : DP_R[7ULL]) / 2.0 * X_idx_3 * 997.7998171;
  t51 = DP_R[7ULL] * DP_R[7ULL];
  t20 = DP_R[11ULL] * t20 / (DP_R[6ULL] == 0.0 ? 1.0E-16 : DP_R[6ULL]) / (t51 ==
    0.0 ? 1.0E-16 : t51) / 2.0 * X_idx_3 * X_idx_3 * t17 * 997.7998171;
  intrm_sf_mf_20 = (t18 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (t18 * 1.0000000000000002E-6 <= 2000.0) {
    t17 = 0.0;
  } else if (t18 * 1.0000000000000002E-6 <= 4000.0) {
    t17 = intrm_sf_mf_20 * intrm_sf_mf_20 * 3.0 - intrm_sf_mf_20 *
      intrm_sf_mf_20 * intrm_sf_mf_20 * 2.0;
  } else {
    t17 = 1.0;
  }

  if (t18 * 1.0000000000000002E-6 <= 2000.0) {
    intrm_sf_mf_20 = t19 * 1.0000000000000001E-11;
  } else if (t18 * 1.0000000000000002E-6 <= 4000.0) {
    intrm_sf_mf_20 = t19 * 1.0000000000000001E-11 + (t20 *
      1.0000000000000002E-17 - t19 * 1.0000000000000001E-11) * t17;
  } else {
    intrm_sf_mf_20 = t20 * 1.0000000000000002E-17;
  }

  if (U_idx_0 >= 0.0) {
    t17 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  } else {
    t17 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  }

  t51 = DP_R[50ULL] * 0.10471975511965977;
  t18 = t51 / (t17 == 0.0 ? 1.0E-16 : t17);
  t49 = DP_R[50ULL] * DP_R[50ULL] * DP_R[50ULL] * 0.001148380617788882;
  t17 = U_idx_0 * U_idx_0 / (t49 == 0.0 ? 1.0E-16 : t49) * 997.7998171 / (DP_R
    [51ULL] == 0.0 ? 1.0E-16 : DP_R[51ULL]);
  if (t15 * 1.0000000000000002E-6 <= 200.0) {
    t20 = 0.0;
  } else {
    t49 = pmf_log10(6.9 / (t15 == 0.0 ? 1.0E-16 : t15) * 999999.99999999988 +
                    pmf_pow(DP_R[76ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t15 ==
      0.0 ? 1.0E-16 : t15) * 999999.99999999988 + pmf_pow(DP_R[76ULL] / 3.7,
      1.11)) * 3.24;
    t20 = 1.0 / (t49 == 0.0 ? 1.0E-16 : t49);
  }

  t49 = DP_R[0ULL] * DP_R[0ULL];
  t19 = DP_R[5ULL] * 6.4361463199777107E-5 / (t49 == 0.0 ? 1.0E-16 : t49) /
    (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) / 2.0 * intrm_sf_mf_9 *
    999999.99999999977;
  t49 = DP_R[1ULL] * DP_R[1ULL];
  t20 = DP_R[5ULL] * t20 / (DP_R[0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) / (t49 ==
    0.0 ? 1.0E-16 : t49) / 2.0 * intrm_sf_mf_9 * intrm_sf_mf_9 * intrm_sf_mf_8 *
    1.002205034378934E+9;
  intrm_sf_mf_9 = (t15 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (t15 * 1.0000000000000002E-6 <= 2000.0) {
    intrm_sf_mf_8 = 0.0;
  } else if (t15 * 1.0000000000000002E-6 <= 4000.0) {
    intrm_sf_mf_8 = intrm_sf_mf_9 * intrm_sf_mf_9 * 3.0 - intrm_sf_mf_9 *
      intrm_sf_mf_9 * intrm_sf_mf_9 * 2.0;
  } else {
    intrm_sf_mf_8 = 1.0;
  }

  if (t15 * 1.0000000000000002E-6 <= 2000.0) {
    intrm_sf_mf_9 = t19 * 1.0000000000000001E-11;
  } else if (t15 * 1.0000000000000002E-6 <= 4000.0) {
    intrm_sf_mf_9 = t19 * 1.0000000000000001E-11 + (t20 * 1.0000000000000002E-17
      - t19 * 1.0000000000000001E-11) * intrm_sf_mf_8;
  } else {
    intrm_sf_mf_9 = t20 * 1.0000000000000002E-17;
  }

  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t4[t14] = DP_R[t14 + 60ULL];
  }

  t9[0ULL] = t18 * X_idx_3;
  t14 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)t4, (void *)t9, (void *)&t14);
  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t4[t14] = DP_R[t14 + 85ULL];
  }

  t9[0ULL] = t18 * X_idx_3;
  t14 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&b_efOut.mField0, (void *)
    &b_efOut.mField1, (void *)&b_efOut.mField2, (void *)t4, (void *)t9, (void *)
    &t14);
  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t4[t14] = DP_R[t14 + 68ULL];
  }

  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t7[t14] = DP_R[t14 + 93ULL];
  }

  t14 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&c_efOut, (void *)efOut.mField0, (void *)
    efOut.mField1, (void *)efOut.mField2, (void *)t4, (void *)&t14);
  t14 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&d_efOut, (void *)b_efOut.mField0, (void *)
    b_efOut.mField1, (void *)b_efOut.mField2, (void *)t7, (void *)&t14);
  out.mX[0] = -(DP_R[13ULL] * 1.0E-5 + intrm_sf_mf_9);
  out.mX[1] = -(DP_R[16ULL] * 1.0E-5 + intrm_sf_mf_20);
  out.mX[2] = -(c_efOut[0] * (U_idx_0 / (t51 == 0.0 ? 1.0E-16 : t51) * (U_idx_0 /
    (t51 == 0.0 ? 1.0E-16 : t51)) * 997.7998171 / (DP_R[51ULL] == 0.0 ? 1.0E-16 :
    DP_R[51ULL])));
  out.mX[3] = -(d_efOut[0] * t17 * 1000.0);
  (void)sys;
  (void)t61;
  return 0;
}
