/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef __Pump_simulation_48324b08_0_initer_h__
#define __Pump_simulation_48324b08_0_initer_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern SscIniter *Pump_simulation_48324b08_0_initer(const NeModelParameters
    *modelParams, const NeSolverParameters *solverParams);

#ifdef __cplusplus

}
#endif
#endif                      /* ifndef __Pump_simulation_48324b08_0_initer_h__ */
