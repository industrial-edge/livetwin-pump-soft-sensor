/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */
/* Pump_simulation_48324b08_0_gmt_dp_r.h - header for method Pump_simulation_48324b08_0_gmt_dp_r */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef PUMP_SIMULATION_48324B08_0_GMT_DP_R_H
#define PUMP_SIMULATION_48324B08_0_GMT_DP_R_H 1

  extern int32_T Pump_simulation_48324b08_0_gmt_dp_r(const GlobalMethodTable
    *sys, const NeDynamicSystemInput *in,GmtMethodOutput *ou );

#endif                       /* #ifndef PUMP_SIMULATION_48324B08_0_GMT_DP_R_H */

#ifdef __cplusplus

}
#endif
