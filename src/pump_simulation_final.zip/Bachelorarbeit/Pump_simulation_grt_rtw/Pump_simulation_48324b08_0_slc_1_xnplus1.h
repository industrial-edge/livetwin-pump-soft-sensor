/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */
/* Pump_simulation_48324b08_0_slc_1_xnplus1.h - header for method Pump_simulation_48324b08_0_slc_1_xnplus1 */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef PUMP_SIMULATION_48324B08_0_SLC_1_XNPLUS1_H
#define PUMP_SIMULATION_48324B08_0_SLC_1_XNPLUS1_H 1

  extern int32_T Pump_simulation_48324b08_0_slc_1_xnplus1(const
    SwitchedLinearClump *sys, const NeDynamicSystemInput *in,SlcMethodOutput *ou
    );

#endif                  /* #ifndef PUMP_SIMULATION_48324B08_0_SLC_1_XNPLUS1_H */

#ifdef __cplusplus

}
#endif
