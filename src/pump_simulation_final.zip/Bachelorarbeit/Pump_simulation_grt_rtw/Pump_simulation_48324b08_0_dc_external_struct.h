/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef struct__ExternalFunctionStructTag
#define struct__ExternalFunctionStructTag
#endif
