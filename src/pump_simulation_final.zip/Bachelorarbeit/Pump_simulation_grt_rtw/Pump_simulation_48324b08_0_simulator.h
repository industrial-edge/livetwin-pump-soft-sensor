/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef __Pump_simulation_48324b08_0_simulator_h__
#define __Pump_simulation_48324b08_0_simulator_h__
#include "nesl_rtw_swl.h"
#ifdef __cplusplus

extern "C" {

#endif

  extern Simulator *Pump_simulation_48324b08_0_simulator_create(void);
  extern void Pump_simulation_48324b08_0_simulator_destroy(void);

#ifdef __cplusplus

}
#endif
#endif                  /* #ifndef __Pump_simulation_48324b08_0_simulator_h__ */
