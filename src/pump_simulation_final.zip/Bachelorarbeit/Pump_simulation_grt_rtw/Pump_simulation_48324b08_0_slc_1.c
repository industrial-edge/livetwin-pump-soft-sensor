/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "Pump_simulation_48324b08_0_slc_1_xnplus1.h"
#include "Pump_simulation_48324b08_0_slc_1_f.h"
#include "ssc_ml_fun.h"
#include "Pump_simulation_48324b08_0_slc_1_external_struct.h"
#include "Pump_simulation_48324b08_0_slc_1_externals.h"

static int32_T slc_m_p(const SwitchedLinearClump *ds, const NeDynamicSystemInput
  *in, SlcMethodOutput *out);
static int32_T slc_m(const SwitchedLinearClump *ds, const NeDynamicSystemInput
                     *in, SlcMethodOutput *out);
static int32_T slc_j_p(const SwitchedLinearClump *ds, const NeDynamicSystemInput
  *in, SlcMethodOutput *out);
static int32_T slc_j(const SwitchedLinearClump *ds, const NeDynamicSystemInput
                     *in, SlcMethodOutput *out);
static int32_T slc_fx(const SwitchedLinearClump *ds, const NeDynamicSystemInput *
                      in, SlcMethodOutput *out);
static int32_T slc_mode(const SwitchedLinearClump *ds, const
  NeDynamicSystemInput *in, SlcMethodOutput *out);
SwitchedLinearClump *Pump_simulation_48324b08_0_slc_1(PmAllocator *allocator)
{
  static NeDynamicSystemInputSizes sizes = { { 0U, 1U, 1U, 1U, 0U, 2U, 0U, 0U,
      0U, 0U, 0U, 1U, 0U, 0U, 0U, 19U, 0U, 0U, 0U, 19U, } };

  static PmSizeVector selector_Q = { 0U, NULL };

  static size_t selector_M_[1] = { 21U };

  static PmSizeVector selector_M = { 1U, selector_M_ };

  static size_t selector_T_[1] = { 0U };

  static PmSizeVector selector_T = { 1U, selector_T_ };

  static size_t selector_U_[1] = { 0U };

  static PmSizeVector selector_U = { 1U, selector_U_ };

  static PmSizeVector selector_V = { 0U, NULL };

  static size_t selector_X_[2] = { 0U, 3U };

  static PmSizeVector selector_X = { 2U, selector_X_ };

  static PmSizeVector selector_D = { 0U, NULL };

  static PmSizeVector selector_E = { 0U, NULL };

  static PmSizeVector selector_CR = { 0U, NULL };

  static PmSizeVector selector_CI = { 0U, NULL };

  static PmSizeVector selector_W = { 0U, NULL };

  static size_t selector_S_[1] = { 0U };

  static PmSizeVector selector_S = { 1U, selector_S_ };

  static PmSizeVector selector_P_L = { 0U, NULL };

  static PmSizeVector selector_P_I = { 0U, NULL };

  static PmSizeVector selector_P_J = { 0U, NULL };

  static size_t selector_P_R_[19] = { 0U, 1U, 2U, 3U, 4U, 5U, 6U, 7U, 8U, 25U,
    26U, 27U, 28U, 29U, 30U, 31U, 32U, 33U, 34U };

  static PmSizeVector selector_P_R = { 19U, selector_P_R_ };

  static PmSizeVector selector_DP_L = { 0U, NULL };

  static PmSizeVector selector_DP_I = { 0U, NULL };

  static PmSizeVector selector_DP_J = { 0U, NULL };

  static size_t selector_DP_R_[19] = { 51U, 50U, 85U, 86U, 87U, 88U, 89U, 90U,
    91U, 92U, 93U, 94U, 95U, 96U, 97U, 98U, 99U, 100U, 49U };

  static PmSizeVector selector_DP_R = { 19U, selector_DP_R_ };

  static int32_T state_indices_[1] = { 0 };

  static PmIntVector state_indices = { 1U, state_indices_ };

  static PmIntVector mode_indices = { 0U, NULL };

  static PmIntVector m_ref_indices = { 0U, NULL };

  static PmIntVector q_ref_indices = { 0U, NULL };

  static SwitchedLinearClump slc;
  (void) allocator;
  slc.mMethods[SLC_METHOD_M_P] = slc_m_p;
  slc.mMethods[SLC_METHOD_M] = slc_m;
  slc.mMethods[SLC_METHOD_J_P] = slc_j_p;
  slc.mMethods[SLC_METHOD_J] = slc_j;
  slc.mMethods[SLC_METHOD_FX] = slc_fx;
  slc.mMethods[SLC_METHOD_F] = Pump_simulation_48324b08_0_slc_1_f;
  slc.mMethods[SLC_METHOD_XNPLUS1] = Pump_simulation_48324b08_0_slc_1_xnplus1;
  slc.mMethods[SLC_METHOD_MODE] = slc_mode;
  slc.mMNnz = 0U;
  slc.mJNnz = 1U;
  slc.mSizes = sizes;
  slc.mSelectors[0] = &selector_Q;
  slc.mSelectors[1] = &selector_M;
  slc.mSelectors[2] = &selector_T;
  slc.mSelectors[3] = &selector_U;
  slc.mSelectors[4] = &selector_V;
  slc.mSelectors[5] = &selector_X;
  slc.mSelectors[6] = &selector_D;
  slc.mSelectors[7] = &selector_E;
  slc.mSelectors[8] = &selector_CR;
  slc.mSelectors[9] = &selector_CI;
  slc.mSelectors[10] = &selector_W;
  slc.mSelectors[11] = &selector_S;
  slc.mSelectors[12] = &selector_P_L;
  slc.mSelectors[13] = &selector_P_I;
  slc.mSelectors[14] = &selector_P_J;
  slc.mSelectors[15] = &selector_P_R;
  slc.mSelectors[16] = &selector_DP_L;
  slc.mSelectors[17] = &selector_DP_I;
  slc.mSelectors[18] = &selector_DP_J;
  slc.mSelectors[19] = &selector_DP_R;
  slc.mStateIndices = &state_indices;
  slc.mModeIndices = &mode_indices;
  slc.mMRefIndices = &m_ref_indices;
  slc.mQRefIndices = &q_ref_indices;
  slc.mIsModeBoolean = TRUE;
  slc.mIsLti = TRUE;
  slc.mModeCardinality = SWL_FINITE;
  return &slc;
}

static int32_T slc_fx (const SwitchedLinearClump *sys, const
  NeDynamicSystemInput *t1, SlcMethodOutput *t2)
{
  PmRealVector out;
  real_T X_idx_0;
  X_idx_0 = t1->mX.mX[0];
  out = t2->mFX;
  out.mX[0] = -X_idx_0;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T slc_m (const SwitchedLinearClump *sys, const NeDynamicSystemInput
                      *t1, SlcMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T slc_m_p (const SwitchedLinearClump *sys, const
  NeDynamicSystemInput *t1, SlcMethodOutput *t2)
{
  PmSparsityPattern out;
  (void)t1;
  out = t2->mM_P;
  out.mNumCol = 1ULL;
  out.mNumRow = 1ULL;
  out.mJc[0] = 0;
  out.mJc[1] = 0;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T slc_j (const SwitchedLinearClump *sys, const NeDynamicSystemInput
                      *t1, SlcMethodOutput *t2)
{
  PmRealVector out;
  (void)t1;
  out = t2->mJ;
  out.mX[0] = -1.0;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T slc_j_p (const SwitchedLinearClump *sys, const
  NeDynamicSystemInput *t1, SlcMethodOutput *t2)
{
  PmSparsityPattern out;
  (void)t1;
  out = t2->mJ_P;
  out.mNumCol = 1ULL;
  out.mNumRow = 1ULL;
  out.mJc[0] = 0;
  out.mJc[1] = 1;
  out.mIr[0] = 0;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T slc_mode (const SwitchedLinearClump *sys, const
  NeDynamicSystemInput *t1, SlcMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}
