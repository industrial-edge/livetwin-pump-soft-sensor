/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "ne_std.h"
#include "ne_dae_fwd.h"
#include "ne_profiler_fwd.h"
#include "ne_dae_construct.h"
#include "ne_initer_dae.h"
#include "Pump_simulation_48324b08_0_initer_idae.h"

SscIniter *Pump_simulation_48324b08_0_initer(const NeModelParameters
  *modelParams, const NeSolverParameters *solverParams)
{
  NeSolverParameters ftParams = *solverParams;
  NeDae* idae = NULL;
  ftParams.mUseLocalSolver = false;
  ftParams.mEquationFormulation = NE_TIME_EF;
  Pump_simulation_48324b08_0_initer_idae(&idae, modelParams, &ftParams);
  return sec_create_initer(idae, FALSE);
}
