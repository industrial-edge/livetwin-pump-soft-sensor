/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_duf.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_sys_struct.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_externals.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_initer_idae_ds_duf(const NeDynamicSystem *sys,
  const NeDynamicSystemInput *t44, NeDsMethodOutput *t45)
{
  PmRealVector out;
  real_T intrm_sf_mf_25;
  real_T intermediate_der14;
  real_T t4[8];
  real_T t7[8];
  real_T t8[8];
  real_T t9[8];
  real_T t11[1];
  size_t t19;
  real_T t27;
  real_T t33;
  real_T t34;
  real_T t36;
  real_T DP_R[101];
  ETTS0 efOut;
  ETTS0 b_efOut;
  real_T c_efOut[1];
  real_T d_efOut[1];
  real_T e_efOut[1];
  real_T f_efOut[1];
  int32_T b;
  real_T U_idx_0;
  real_T X_idx_3;
  U_idx_0 = t44->mU.mX[0];
  X_idx_3 = t44->mX.mX[3];
  for (b = 0; b < 101; b++) {
    DP_R[b] = t44->mDP_R.mX[b];
  }

  out = t45->mDUF;
  if (U_idx_0 >= 0.0) {
    intermediate_der14 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  } else {
    intermediate_der14 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  }

  t27 = DP_R[50ULL] * 0.10471975511965977;
  intrm_sf_mf_25 = t27 / (intermediate_der14 == 0.0 ? 1.0E-16 :
    intermediate_der14);
  t33 = DP_R[50ULL] * DP_R[50ULL] * DP_R[50ULL] * 0.001148380617788882;
  if (U_idx_0 >= 0.0) {
    t36 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]) * 2.0;
    t34 = 1.0 / (t36 == 0.0 ? 1.0E-16 : t36) * U_idx_0 * 2.0;
  } else {
    t36 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]) * 2.0;
    t34 = -(1.0 / (t36 == 0.0 ? 1.0E-16 : t36) * U_idx_0 * 2.0);
  }

  t36 = intermediate_der14 * intermediate_der14;
  intermediate_der14 = -(DP_R[50ULL] * 0.10471975511965977) / (t36 == 0.0 ?
    1.0E-16 : t36) * t34;
  for (t19 = 0ULL; t19 < 8ULL; t19++) {
    t4[t19] = DP_R[t19 + 60ULL];
  }

  t11[0ULL] = intrm_sf_mf_25 * X_idx_3;
  t19 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)t4, (void *)t11, (void *)&t19);
  for (t19 = 0ULL; t19 < 8ULL; t19++) {
    t4[t19] = DP_R[t19 + 85ULL];
  }

  t11[0ULL] = intrm_sf_mf_25 * X_idx_3;
  t19 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&b_efOut.mField0, (void *)
    &b_efOut.mField1, (void *)&b_efOut.mField2, (void *)t4, (void *)t11, (void *)
    &t19);
  for (t19 = 0ULL; t19 < 8ULL; t19++) {
    t4[t19] = DP_R[t19 + 68ULL];
  }

  for (t19 = 0ULL; t19 < 8ULL; t19++) {
    t7[t19] = DP_R[t19 + 68ULL];
  }

  for (t19 = 0ULL; t19 < 8ULL; t19++) {
    t8[t19] = DP_R[t19 + 93ULL];
  }

  for (t19 = 0ULL; t19 < 8ULL; t19++) {
    t9[t19] = DP_R[t19 + 93ULL];
  }

  t19 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&c_efOut, (void *)efOut.mField0, (void *)
    efOut.mField1, (void *)efOut.mField2, (void *)t4, (void *)&t19);
  t19 = 8ULL;
  tlu2_1d_linear_linear_derivatives((void *)&d_efOut, (void *)efOut.mField0,
    (void *)efOut.mField1, (void *)efOut.mField2, (void *)t7, (void *)&t19);
  t19 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&e_efOut, (void *)b_efOut.mField0, (void *)
    b_efOut.mField1, (void *)b_efOut.mField2, (void *)t8, (void *)&t19);
  t19 = 8ULL;
  tlu2_1d_linear_linear_derivatives((void *)&f_efOut, (void *)b_efOut.mField0,
    (void *)b_efOut.mField1, (void *)b_efOut.mField2, (void *)t9, (void *)&t19);
  out.mX[0] = -(c_efOut[0] * (U_idx_0 / (t27 == 0.0 ? 1.0E-16 : t27) * (1.0 /
    (DP_R[51ULL] == 0.0 ? 1.0E-16 : DP_R[51ULL])) * (1.0 / (t27 == 0.0 ? 1.0E-16
    : t27)) * 1995.5996342) + d_efOut[0] * X_idx_3 * intermediate_der14 *
                (U_idx_0 / (t27 == 0.0 ? 1.0E-16 : t27) * (U_idx_0 / (t27 == 0.0
    ? 1.0E-16 : t27)) * 997.7998171 / (DP_R[51ULL] == 0.0 ? 1.0E-16 : DP_R[51ULL])));
  out.mX[1] = -((e_efOut[0] * (1.0 / (DP_R[51ULL] == 0.0 ? 1.0E-16 : DP_R[51ULL])
    * (1.0 / (t33 == 0.0 ? 1.0E-16 : t33)) * U_idx_0 * 1995.5996342) + f_efOut[0]
                 * X_idx_3 * intermediate_der14 * (U_idx_0 * U_idx_0 / (t33 ==
    0.0 ? 1.0E-16 : t33) * 997.7998171 / (DP_R[51ULL] == 0.0 ? 1.0E-16 : DP_R
    [51ULL]))) * 1000.0);
  (void)sys;
  (void)t45;
  return 0;
}
