/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef struct__ExternalFunctionStructTag
#define struct__ExternalFunctionStructTag

typedef struct ETTS1Tag {
  real_T mField0[8];
  real_T mField1[8];
} ETTS1;

typedef struct ETTS0Tag {
  real_T mField0[2];
  real_T mField1[2];
  size_t mField2[1];
} ETTS0;

#endif
