/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "Pump_simulation_48324b08_0_slc_0_fx.h"
#include "Pump_simulation_48324b08_0_slc_0_sys_struct.h"
#include "Pump_simulation_48324b08_0_slc_0_externals.h"
#include "Pump_simulation_48324b08_0_slc_0_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_slc_0_fx(const SwitchedLinearClump *sys,
  const NeDynamicSystemInput *t49, SlcMethodOutput *t50)
{
  PmRealVector out;
  real_T zc_int6;
  real_T t3[8];
  real_T t5[1];
  size_t t7;
  real_T t8;
  real_T t9;
  real_T t10;
  real_T t12;
  real_T t13;
  real_T t16;
  real_T t40;
  real_T t41;
  real_T t45;
  real_T DP_R[29];
  ETTS0 efOut;
  real_T b_efOut[1];
  real_T U_idx_0;
  real_T X_idx_0;
  real_T X_idx_1;
  real_T X_idx_2;
  int32_T M_idx_6;
  int32_T M_idx_13;
  int32_T M_idx_11;
  int32_T M_idx_12;
  int32_T M_idx_14;
  int32_T M_idx_15;
  int32_T M_idx_0;
  int32_T M_idx_1;
  int32_T M_idx_10;
  M_idx_0 = t49->mM.mX[0];
  M_idx_1 = t49->mM.mX[1];
  M_idx_6 = t49->mM.mX[6];
  M_idx_10 = t49->mM.mX[10];
  M_idx_11 = t49->mM.mX[11];
  M_idx_12 = t49->mM.mX[12];
  M_idx_13 = t49->mM.mX[13];
  M_idx_14 = t49->mM.mX[14];
  M_idx_15 = t49->mM.mX[15];
  U_idx_0 = t49->mU.mX[0];
  X_idx_0 = t49->mX.mX[0];
  X_idx_1 = t49->mX.mX[1];
  X_idx_2 = t49->mX.mX[2];
  DP_R[0] = t49->mDP_R.mX[0];
  DP_R[1] = t49->mDP_R.mX[1];
  DP_R[2] = t49->mDP_R.mX[2];
  DP_R[3] = t49->mDP_R.mX[3];
  DP_R[4] = t49->mDP_R.mX[4];
  DP_R[5] = t49->mDP_R.mX[5];
  DP_R[6] = t49->mDP_R.mX[6];
  DP_R[7] = t49->mDP_R.mX[7];
  DP_R[8] = t49->mDP_R.mX[8];
  DP_R[9] = t49->mDP_R.mX[9];
  DP_R[10] = t49->mDP_R.mX[10];
  DP_R[11] = t49->mDP_R.mX[11];
  DP_R[12] = t49->mDP_R.mX[12];
  DP_R[13] = t49->mDP_R.mX[13];
  DP_R[14] = t49->mDP_R.mX[14];
  DP_R[15] = t49->mDP_R.mX[15];
  DP_R[16] = t49->mDP_R.mX[16];
  DP_R[17] = t49->mDP_R.mX[17];
  DP_R[18] = t49->mDP_R.mX[18];
  DP_R[19] = t49->mDP_R.mX[19];
  DP_R[20] = t49->mDP_R.mX[20];
  DP_R[21] = t49->mDP_R.mX[21];
  DP_R[22] = t49->mDP_R.mX[22];
  DP_R[23] = t49->mDP_R.mX[23];
  DP_R[24] = t49->mDP_R.mX[24];
  DP_R[25] = t49->mDP_R.mX[25];
  DP_R[26] = t49->mDP_R.mX[26];
  DP_R[27] = t49->mDP_R.mX[27];
  DP_R[28] = t49->mDP_R.mX[28];
  out = t50->mFX;
  zc_int6 = X_idx_2 * 0.00099779981710000024;
  t9 = DP_R[4ULL] * DP_R[4ULL];
  t8 = DP_R[5ULL] * 6.4361463199777107E-5 / (t9 == 0.0 ? 1.0E-16 : t9) / (DP_R
    [3ULL] == 0.0 ? 1.0E-16 : DP_R[3ULL]) / 2.0 * X_idx_2 * 997.7998171;
  t13 = DP_R[10ULL] * 0.10471975511965977;
  t41 = DP_R[1ULL] * DP_R[1ULL];
  t10 = DP_R[2ULL] * 6.4361463199777107E-5 / (t41 == 0.0 ? 1.0E-16 : t41) /
    (DP_R[0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) / 2.0 * zc_int6 *
    999999.99999999977;
  t12 = M_idx_6 != 0 ? 1.0 : -1.0;
  t45 = zc_int6 * DP_R[1ULL] * t12 * 1002.2050343789342 / (DP_R[0ULL] == 0.0 ?
    1.0E-16 : DP_R[0ULL]) / 1.0056478624965173E-6;
  t16 = M_idx_13 != 0 ? 1.0 : -1.0;
  t9 = DP_R[4ULL] * X_idx_2 * t16 / (DP_R[3ULL] == 0.0 ? 1.0E-16 : DP_R[3ULL]) /
    1.0056478624965173E-6;
  t40 = (t9 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_11 != 0) {
    t41 = 0.0;
  } else if (M_idx_12 != 0) {
    t41 = t40 * t40 * 3.0 - t40 * t40 * t40 * 2.0;
  } else {
    t41 = 1.0;
  }

  if (M_idx_14 != 0) {
    t40 = 0.0;
  } else {
    t9 = pmf_log10(6.9 / (t9 == 0.0 ? 1.0E-16 : t9) * 999999.99999999988 +
                   pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t9 == 0.0
      ? 1.0E-16 : t9) * 999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7, 1.11)) *
      3.24;
    t40 = 1.0 / (t9 == 0.0 ? 1.0E-16 : t9);
  }

  t9 = DP_R[5ULL] * t40;
  t40 = DP_R[3ULL] * DP_R[3ULL];
  t9 = t9 / (DP_R[4ULL] == 0.0 ? 1.0E-16 : DP_R[4ULL]) / (t40 == 0.0 ? 1.0E-16 :
    t40) / 2.0 * X_idx_2 * X_idx_2 * t16 * 997.7998171;
  if (M_idx_11 != 0) {
    t9 = t8 * 1.0000000000000001E-11;
  } else if (M_idx_12 != 0) {
    t9 = t8 * 1.0000000000000001E-11 + (t9 * 1.0000000000000002E-17 - t8 *
      1.0000000000000001E-11) * t41;
  } else {
    t9 *= 1.0000000000000002E-17;
  }

  if (M_idx_15 != 0) {
    t8 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[28ULL] * DP_R[28ULL]);
  } else {
    t8 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[28ULL] * DP_R[28ULL]);
  }

  t40 = t13 / (t8 == 0.0 ? 1.0E-16 : t8);
  t8 = (t45 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_0 != 0) {
    t16 = 0.0;
  } else if (M_idx_1 != 0) {
    t16 = t8 * t8 * 3.0 - t8 * t8 * t8 * 2.0;
  } else {
    t16 = 1.0;
  }

  if (M_idx_10 != 0) {
    t8 = 0.0;
  } else {
    t41 = pmf_log10(6.9 / (t45 == 0.0 ? 1.0E-16 : t45) * 999999.99999999988 +
                    pmf_pow(DP_R[27ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t45 ==
      0.0 ? 1.0E-16 : t45) * 999999.99999999988 + pmf_pow(DP_R[27ULL] / 3.7,
      1.11)) * 3.24;
    t8 = 1.0 / (t41 == 0.0 ? 1.0E-16 : t41);
  }

  t45 = DP_R[0ULL] * DP_R[0ULL];
  t8 = DP_R[2ULL] * t8 / (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) / (t45 ==
    0.0 ? 1.0E-16 : t45) / 2.0 * zc_int6 * zc_int6 * t12 * 1.002205034378934E+9;
  if (M_idx_0 != 0) {
    zc_int6 = t10 * 1.0000000000000001E-11;
  } else if (M_idx_1 != 0) {
    zc_int6 = t10 * 1.0000000000000001E-11 + (t8 * 1.0000000000000002E-17 - t10 *
      1.0000000000000001E-11) * t16;
  } else {
    zc_int6 = t8 * 1.0000000000000002E-17;
  }

  for (t7 = 0ULL; t7 < 8ULL; t7++) {
    t3[t7] = DP_R[t7 + 11ULL];
  }

  t5[0ULL] = t40 * X_idx_2;
  t7 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)t3, (void *)t5, (void *)&t7);
  for (t7 = 0ULL; t7 < 8ULL; t7++) {
    t3[t7] = DP_R[t7 + 19ULL];
  }

  t7 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&b_efOut, (void *)efOut.mField0, (void *)
    efOut.mField1, (void *)efOut.mField2, (void *)t3, (void *)&t7);
  out.mX[0] = X_idx_0 - (DP_R[8ULL] * 1.0E-5 + t9);
  out.mX[1] = X_idx_1 - b_efOut[0] * (U_idx_0 / (t13 == 0.0 ? 1.0E-16 : t13) *
    (U_idx_0 / (t13 == 0.0 ? 1.0E-16 : t13)) * 997.7998171 / (DP_R[9ULL] == 0.0 ?
    1.0E-16 : DP_R[9ULL]));
  out.mX[2] = (-X_idx_0 + X_idx_1) - (DP_R[6ULL] * 1.0E-5 + zc_int6);
  (void)sys;
  (void)t50;
  return 0;
}
