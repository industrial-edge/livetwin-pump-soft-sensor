/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "Pump_simulation_48324b08_0_slc_0_mode.h"
#include "Pump_simulation_48324b08_0_slc_0_sys_struct.h"
#include "Pump_simulation_48324b08_0_slc_0_externals.h"
#include "Pump_simulation_48324b08_0_slc_0_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_slc_0_mode(const SwitchedLinearClump *sys,
  const NeDynamicSystemInput *t15, SlcMethodOutput *t16)
{
  PmIntVector out;
  real_T t14;
  int32_T t0_idx_3;
  int32_T t0_idx_4;
  int32_T t0_idx_8;
  int32_T t0_idx_9;
  real_T X_idx_2;
  real_T DP_R_idx_1;
  real_T DP_R_idx_0;
  real_T DP_R_idx_4;
  real_T DP_R_idx_3;
  real_T DP_R_idx_7;
  real_T DP_R_idx_27;
  X_idx_2 = t15->mX.mX[2];
  DP_R_idx_0 = t15->mDP_R.mX[0];
  DP_R_idx_1 = t15->mDP_R.mX[1];
  DP_R_idx_3 = t15->mDP_R.mX[3];
  DP_R_idx_4 = t15->mDP_R.mX[4];
  DP_R_idx_7 = t15->mDP_R.mX[7];
  DP_R_idx_27 = t15->mDP_R.mX[27];
  out = t16->mMODE;
  t14 = X_idx_2 * 0.00099779981710000024;
  DP_R_idx_1 = t14 * DP_R_idx_1 * (t14 * 1002.2050343789342 >= 0.0 ? 1.0 : -1.0)
    * 1002.2050343789342 / (DP_R_idx_0 == 0.0 ? 1.0E-16 : DP_R_idx_0) /
    1.0056478624965173E-6;
  DP_R_idx_0 = DP_R_idx_4 * X_idx_2 * (X_idx_2 >= 0.0 ? 1.0 : -1.0) /
    (DP_R_idx_3 == 0.0 ? 1.0E-16 : DP_R_idx_3) / 1.0056478624965173E-6;
  t0_idx_3 = (int32_T)((!(DP_R_idx_0 != 0.0)) || (!(DP_R_idx_7 / 3.7 >= 0.0)) ||
                       (DP_R_idx_0 * 1.0000000000000002E-6 <= 200.0) || (6.9 /
    (DP_R_idx_0 == 0.0 ? 1.0E-16 : DP_R_idx_0) * 999999.99999999988 + pmf_pow
    (DP_R_idx_7 / 3.7, 1.11) > 0.0));
  t0_idx_4 = (int32_T)((!(DP_R_idx_0 != 0.0)) || (!(DP_R_idx_7 / 3.7 >= 0.0)) ||
                       ((DP_R_idx_0 != 0.0) && (DP_R_idx_7 / 3.7 >= 0.0) &&
                        (!(6.9 / (DP_R_idx_0 == 0.0 ? 1.0E-16 : DP_R_idx_0) *
    999999.99999999988 + pmf_pow(DP_R_idx_7 / 3.7, 1.11) > 0.0))) || (DP_R_idx_0
    * 1.0000000000000002E-6 <= 200.0) || (pmf_log10(6.9 / (DP_R_idx_0 == 0.0 ?
    1.0E-16 : DP_R_idx_0) * 999999.99999999988 + pmf_pow(DP_R_idx_7 / 3.7, 1.11))
    * pmf_log10(6.9 / (DP_R_idx_0 == 0.0 ? 1.0E-16 : DP_R_idx_0) *
                999999.99999999988 + pmf_pow(DP_R_idx_7 / 3.7, 1.11)) * 3.24 !=
    0.0));
  t0_idx_8 = (int32_T)((!(DP_R_idx_1 != 0.0)) || (!(DP_R_idx_27 / 3.7 >= 0.0)) ||
                       (DP_R_idx_1 * 1.0000000000000002E-6 <= 200.0) || (6.9 /
    (DP_R_idx_1 == 0.0 ? 1.0E-16 : DP_R_idx_1) * 999999.99999999988 + pmf_pow
    (DP_R_idx_27 / 3.7, 1.11) > 0.0));
  t0_idx_9 = (int32_T)((!(DP_R_idx_1 != 0.0)) || (!(DP_R_idx_27 / 3.7 >= 0.0)) ||
                       ((DP_R_idx_1 != 0.0) && (DP_R_idx_27 / 3.7 >= 0.0) &&
                        (!(6.9 / (DP_R_idx_1 == 0.0 ? 1.0E-16 : DP_R_idx_1) *
    999999.99999999988 + pmf_pow(DP_R_idx_27 / 3.7, 1.11) > 0.0))) ||
                       (DP_R_idx_1 * 1.0000000000000002E-6 <= 200.0) ||
                       (pmf_log10(6.9 / (DP_R_idx_1 == 0.0 ? 1.0E-16 :
    DP_R_idx_1) * 999999.99999999988 + pmf_pow(DP_R_idx_27 / 3.7, 1.11)) *
                        pmf_log10(6.9 / (DP_R_idx_1 == 0.0 ? 1.0E-16 :
    DP_R_idx_1) * 999999.99999999988 + pmf_pow(DP_R_idx_27 / 3.7, 1.11)) * 3.24
                        != 0.0));
  out.mX[0] = (int32_T)(DP_R_idx_1 * 1.0000000000000002E-6 <= 2000.0);
  out.mX[1] = (int32_T)(DP_R_idx_1 * 1.0000000000000002E-6 <= 4000.0);
  out.mX[2] = 1;
  out.mX[3] = t0_idx_3;
  out.mX[4] = t0_idx_4;
  out.mX[5] = (int32_T)((DP_R_idx_1 * 1.0000000000000002E-6 <= 200.0) ||
                        (DP_R_idx_1 != 0.0));
  out.mX[6] = (int32_T)(t14 * 1002.2050343789342 >= 0.0);
  out.mX[7] = 1;
  out.mX[8] = t0_idx_8;
  out.mX[9] = t0_idx_9;
  out.mX[10] = (int32_T)(DP_R_idx_1 * 1.0000000000000002E-6 <= 200.0);
  out.mX[11] = (int32_T)(DP_R_idx_0 * 1.0000000000000002E-6 <= 2000.0);
  out.mX[12] = (int32_T)(DP_R_idx_0 * 1.0000000000000002E-6 <= 4000.0);
  out.mX[13] = (int32_T)(X_idx_2 >= 0.0);
  out.mX[14] = (int32_T)(DP_R_idx_0 * 1.0000000000000002E-6 <= 200.0);
  out.mX[15] = (int32_T)((DP_R_idx_0 * 1.0000000000000002E-6 <= 200.0) ||
    (DP_R_idx_0 != 0.0));
  (void)sys;
  (void)t16;
  return 0;
}
