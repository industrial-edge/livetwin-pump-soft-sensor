/*
 * Pump_simulation.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Pump_simulation".
 *
 * Model version              : 1.12
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C++ source code generated on : Thu Feb 11 11:26:20 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Pump_simulation_capi.h"
#include "Pump_simulation.h"
#include "Pump_simulation_private.h"

/*
 * This function updates continuous states using the ODE3 fixed-step
 * solver algorithm
 */
void Pump_simulationModelClass::rt_ertODEUpdateContinuousStates(RTWSolverInfo
  *si )
{
  /* Solver Matrices */
  static const real_T rt_ODE3_A[3] = {
    1.0/2.0, 3.0/4.0, 1.0
  };

  static const real_T rt_ODE3_B[3][3] = {
    { 1.0/2.0, 0.0, 0.0 },

    { 0.0, 3.0/4.0, 0.0 },

    { 2.0/9.0, 1.0/3.0, 4.0/9.0 }
  };

  time_T t = rtsiGetT(si);
  time_T tnew = rtsiGetSolverStopTime(si);
  time_T h = rtsiGetStepSize(si);
  real_T *x = rtsiGetContStates(si);
  ODE3_IntgData *id = static_cast<ODE3_IntgData *>(rtsiGetSolverData(si));
  real_T *y = id->y;
  real_T *f0 = id->f[0];
  real_T *f1 = id->f[1];
  real_T *f2 = id->f[2];
  real_T hB[3];
  int_T i;
  int_T nXc = 1;
  rtsiSetSimTimeStep(si,MINOR_TIME_STEP);

  /* Save the state values at time t in y, we'll use x as ynew. */
  (void) std::memcpy(y, x,
                     static_cast<uint_T>(nXc)*sizeof(real_T));

  /* Assumes that rtsiSetT and ModelOutputs are up-to-date */
  /* f0 = f(t,y) */
  rtsiSetdX(si, f0);
  Pump_simulation_derivatives();

  /* f(:,2) = feval(odefile, t + hA(1), y + f*hB(:,1), args(:)(*)); */
  hB[0] = h * rt_ODE3_B[0][0];
  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[0]);
  rtsiSetdX(si, f1);
  this->step();
  Pump_simulation_derivatives();

  /* f(:,3) = feval(odefile, t + hA(2), y + f*hB(:,2), args(:)(*)); */
  for (i = 0; i <= 1; i++) {
    hB[i] = h * rt_ODE3_B[1][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1]);
  }

  rtsiSetT(si, t + h*rt_ODE3_A[1]);
  rtsiSetdX(si, f2);
  this->step();
  Pump_simulation_derivatives();

  /* tnew = t + hA(3);
     ynew = y + f*hB(:,3); */
  for (i = 0; i <= 2; i++) {
    hB[i] = h * rt_ODE3_B[2][i];
  }

  for (i = 0; i < nXc; i++) {
    x[i] = y[i] + (f0[i]*hB[0] + f1[i]*hB[1] + f2[i]*hB[2]);
  }

  rtsiSetT(si, tnew);
  rtsiSetSimTimeStep(si,MAJOR_TIME_STEP);
}

/* Model step function */
void Pump_simulationModelClass::step()
{
  if (rtmIsMajorTimeStep((&Pump_simulation_M))) {
    /* set solver stop time */
    if (!((&Pump_simulation_M)->Timing.clockTick0+1)) {
      rtsiSetSolverStopTime(&(&Pump_simulation_M)->solverInfo,
                            (((&Pump_simulation_M)->Timing.clockTickH0 + 1) *
        (&Pump_simulation_M)->Timing.stepSize0 * 4294967296.0));
    } else {
      rtsiSetSolverStopTime(&(&Pump_simulation_M)->solverInfo,
                            (((&Pump_simulation_M)->Timing.clockTick0 + 1) *
        (&Pump_simulation_M)->Timing.stepSize0 + (&Pump_simulation_M)
        ->Timing.clockTickH0 * (&Pump_simulation_M)->Timing.stepSize0 *
        4294967296.0));
    }
  }                                    /* end MajorTimeStep */

  /* Update absolute time of base rate at minor time step */
  if (rtmIsMinorTimeStep((&Pump_simulation_M))) {
    (&Pump_simulation_M)->Timing.t[0] = rtsiGetT(&(&Pump_simulation_M)
      ->solverInfo);
  }

  {
    real_T *parameterBundle_mRealParameters;
    real_T tmp[43];
    NeuDiagnosticManager *diag;
    NeuDiagnosticTree *diagTree;
    boolean_T ok;
    char *msg;
    const Simulator *simulator;
    NeuDiagnosticManager *diagnosticManager;
    PmRealVector inputs;
    PmRealVector states;
    PmRealVector outputs;
    boolean_T first_output;
    char *msg_0;
    char *msg_1;
    real_T rtb_Switch3;
    real_T rtb_Abs;
    NeParameterBundle expl_temp;
    if (rtmIsMajorTimeStep((&Pump_simulation_M))) {
      /* Outport: '<Root>/angle_velocity' incorporates:
       *  Fcn: '<Root>/U//min in rad//s'
       *  Inport: '<Root>/pump_speed'
       */
      Pump_simulation_Y.angle_velocity = Pump_simulation_U.pump_speed * 2.0 *
        3.1415926535897931 / 60.0;

      /* SimscapeInputBlock: '<S13>/INPUT_1_1_1' incorporates:
       *  Outport: '<Root>/angle_velocity'
       */
      if (rtmIsMajorTimeStep((&Pump_simulation_M))) {
        Pump_simulation_B.INPUT_1_1_1[0] = Pump_simulation_Y.angle_velocity;
        Pump_simulation_B.INPUT_1_1_1[1] = 0.0;
        Pump_simulation_B.INPUT_1_1_1[2] = 0.0;
        Pump_simulation_DW.INPUT_1_1_1_Discrete[0] =
          !(Pump_simulation_B.INPUT_1_1_1[0] ==
            Pump_simulation_DW.INPUT_1_1_1_Discrete[1]);
        Pump_simulation_DW.INPUT_1_1_1_Discrete[1] =
          Pump_simulation_B.INPUT_1_1_1[0];
        Pump_simulation_B.INPUT_1_1_1[0] =
          Pump_simulation_DW.INPUT_1_1_1_Discrete[1];
        Pump_simulation_B.INPUT_1_1_1[3] =
          Pump_simulation_DW.INPUT_1_1_1_Discrete[0];
      }

      /* End of SimscapeInputBlock: '<S13>/INPUT_1_1_1' */

      /* SimscapeRtp: '<S5>/RTP_0' incorporates:
       *  Constant: '<Root>/Subsystem_around_RTP_6B36CDB1_omega_threshold'
       *  Constant: '<Root>/Subsystem_around_RTP_6B36CDB1_power_1D'
       *  Constant: '<Root>/Subsystem_around_RTP_6B36CDB1_press_diff_1D'
       *  Constant: '<Root>/Subsystem_around_RTP_6B36CDB1_pump_del_1D'
       *  Constant: '<Root>/Subsystem_around_RTP_6B36CDB1_pump_del_power_1D'
       *  Constant: '<Root>/Subsystem_around_RTP_6B36CDB1_ref_density'
       *  Constant: '<Root>/Subsystem_around_RTP_6B36CDB1_ref_velocity'
       *  Constant: '<S8>/Subsystem_around_RTP_AC11BC34_d_in'
       *  Constant: '<S8>/Subsystem_around_RTP_AC11BC34_elevation_A'
       *  Constant: '<S8>/Subsystem_around_RTP_AC11BC34_elevation_B'
       *  Constant: '<S8>/Subsystem_around_RTP_AC11BC34_length'
       *  Constant: '<S8>/Subsystem_around_RTP_EF33F071_d_in'
       *  Constant: '<S8>/Subsystem_around_RTP_EF33F071_elevation_A'
       *  Constant: '<S8>/Subsystem_around_RTP_EF33F071_elevation_B'
       *  Constant: '<S8>/Subsystem_around_RTP_EF33F071_length'
       */
      if (Pump_simulation_DW.RTP_0_SetParametersNeeded) {
        tmp[0] = Pump_simulation_P.Angular_speed_treshold_for_flow_reversal;
        std::memcpy(&tmp[1], &Pump_simulation_P.pump_brake_power_vector[0],
                    sizeof(real_T) << 3U);
        std::memcpy(&tmp[9],
                    &Pump_simulation_P.pump_pressure_differential_vector[0],
                    sizeof(real_T) << 3U);
        std::memcpy(&tmp[17],
                    &Pump_simulation_P.pump_delivery_vector_pressure_differential
                    [0], sizeof(real_T) << 3U);
        std::memcpy(&tmp[25],
                    &Pump_simulation_P.pump_delivery_vector_brake_power[0],
                    sizeof(real_T) << 3U);
        tmp[33] = Pump_simulation_P.Reference_density;
        tmp[34] = Pump_simulation_P.Reference_angular_velocity;
        tmp[35] = Pump_simulation_P.suction_pipe_internal_diameter;
        tmp[36] = Pump_simulation_P.suction_pipe_inlet_heigth;
        tmp[37] = Pump_simulation_P.suction_pipe_outlet_heigth;
        tmp[38] = Pump_simulation_P.suction_pipe_length;
        tmp[39] = Pump_simulation_P.pressure_pipe_internal_diameter;
        tmp[40] = Pump_simulation_P.pressure_pipe_inlet_heigth;
        tmp[41] = Pump_simulation_P.pressure_pipe_outlet_heigth;
        tmp[42] = Pump_simulation_P.pressure_pipe_length;
        parameterBundle_mRealParameters = &tmp[0];
        diag = rtw_create_diagnostics();
        diagTree = neu_diagnostic_manager_get_initial_tree(diag);
        expl_temp.mRealParameters.mN = 43;
        expl_temp.mRealParameters.mX = parameterBundle_mRealParameters;
        expl_temp.mLogicalParameters.mN = 0;
        expl_temp.mLogicalParameters.mX = NULL;
        expl_temp.mIntegerParameters.mN = 0;
        expl_temp.mIntegerParameters.mX = NULL;
        expl_temp.mIndexParameters.mN = 0;
        expl_temp.mIndexParameters.mX = NULL;
        ok = nesl_rtp_manager_set_rtps((NeslRtpManager *)
          Pump_simulation_DW.RTP_0_RtpManager, (&Pump_simulation_M)->Timing.t[0],
          expl_temp, diag);
        if (!ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus((&Pump_simulation_M)));
          if (ok) {
            msg = rtw_diagnostics_msg(diagTree);
            rtmSetErrorStatus((&Pump_simulation_M), msg);
          }
        }
      }

      Pump_simulation_DW.RTP_0_SetParametersNeeded = false;

      /* End of SimscapeRtp: '<S5>/RTP_0' */

      /* SimscapeSwlState: '<S13>/SWL_STATE_0' */
      simulator = (const Simulator *)Pump_simulation_DW.SWL_STATE_0_SimulatorPtr;
      diagnosticManager = (NeuDiagnosticManager *)
        Pump_simulation_DW.SWL_STATE_0_DiagMgr;
      inputs.mN = 1;
      inputs.mX = &Pump_simulation_DW.SWL_STATE_0_Inputs;
      Pump_simulation_DW.SWL_STATE_0_Inputs = Pump_simulation_B.INPUT_1_1_1[0];
      states.mN = 31;
      states.mX = &Pump_simulation_DW.SWL_STATE_0_Discrete[0];
      outputs.mN = 3;
      outputs.mX = &Pump_simulation_B.SWL_STATE_0[0];
      first_output = false;
      if (Pump_simulation_DW.SWL_STATE_0_FirstOutput == 0.0) {
        Pump_simulation_DW.SWL_STATE_0_FirstOutput = 1.0;
        first_output = true;
        ok = swl_start(simulator, diagnosticManager);
        if (ok) {
          ok = error_buffer_is_empty(rtmGetErrorStatus((&Pump_simulation_M)));
          if (ok) {
            msg_0 = rtw_diagnostics_msg((const NeuDiagnosticTree *)
              Pump_simulation_DW.SWL_STATE_0_DiagTree);
            rtmSetErrorStatus((&Pump_simulation_M), msg_0);
          }
        }
      }

      ok = swl_solve(simulator, &inputs, &states, &outputs, (&Pump_simulation_M
                     )->Timing.t[0], diagnosticManager, first_output);
      if (ok) {
        ok = error_buffer_is_empty(rtmGetErrorStatus((&Pump_simulation_M)));
        if (ok) {
          msg_1 = rtw_diagnostics_msg((const NeuDiagnosticTree *)
            Pump_simulation_DW.SWL_STATE_0_DiagTree);
          rtmSetErrorStatus((&Pump_simulation_M), msg_1);
        }
      }

      /* End of SimscapeSwlState: '<S13>/SWL_STATE_0' */

      /* Outport: '<Root>/flowrate_l//s' */
      Pump_simulation_Y.flowrate_ls = Pump_simulation_B.SWL_STATE_0[0];

      /* Outport: '<Root>/flowrate_l//min' incorporates:
       *  Fcn: '<Root>/l//s in l//min'
       */
      Pump_simulation_Y.flowrate_lmin = Pump_simulation_B.SWL_STATE_0[0] * 60.0;

      /* Outport: '<Root>/pump_pressure_Pa' */
      Pump_simulation_Y.pump_pressure_Pa = Pump_simulation_B.SWL_STATE_0[2];

      /* Sum: '<S7>/Subtract1' incorporates:
       *  Inport: '<Root>/pumppressure_sensor_Pa'
       */
      rtb_Abs = Pump_simulation_U.pumppressure_sensor_Pa -
        Pump_simulation_B.SWL_STATE_0[2];

      /* Outport: '<Root>/pumppressure_delta_Pa' incorporates:
       *  Abs: '<S7>/Abs'
       */
      Pump_simulation_Y.pumppressure_delta_Pa = std::abs(rtb_Abs);

      /* Switch: '<S7>/Switch' */
      if (rtb_Abs > Pump_simulation_P.Switch_Threshold) {
        /* Product: '<S7>/Divide' incorporates:
         *  Inport: '<Root>/pumppressure_sensor_Pa'
         */
        rtb_Abs = Pump_simulation_B.SWL_STATE_0[2] /
          Pump_simulation_U.pumppressure_sensor_Pa;
      } else {
        /* Product: '<S7>/Divide1' incorporates:
         *  Inport: '<Root>/pumppressure_sensor_Pa'
         */
        rtb_Abs = Pump_simulation_U.pumppressure_sensor_Pa /
          Pump_simulation_B.SWL_STATE_0[2];
      }

      /* End of Switch: '<S7>/Switch' */

      /* Switch: '<S7>/Switch1' */
      if (rtb_Abs > Pump_simulation_P.Switch1_Threshold) {
        /* Outport: '<Root>/control_pumppressure' incorporates:
         *  Constant: '<S7>/Constant1'
         */
        Pump_simulation_Y.control_pumppressure =
          Pump_simulation_P.Constant1_Value;
      } else {
        /* Outport: '<Root>/control_pumppressure' incorporates:
         *  Constant: '<S7>/Constant'
         */
        Pump_simulation_Y.control_pumppressure =
          Pump_simulation_P.Constant_Value;
      }

      /* End of Switch: '<S7>/Switch1' */

      /* Outport: '<Root>/flowrate_m^3//s' */
      Pump_simulation_Y.flowrate_m3s = Pump_simulation_B.SWL_STATE_0[1];

      /* Fcn: '<Root>/m^3//s in m^3//h' */
      rtb_Abs = Pump_simulation_B.SWL_STATE_0[1] * 3600.0;

      /* Outport: '<Root>/flowrate_m^3//h' */
      Pump_simulation_Y.flowrate_m3h = rtb_Abs;

      /* Sum: '<S6>/Subtract' incorporates:
       *  Inport: '<Root>/flowrate_sensor_m^3//h'
       */
      rtb_Switch3 = Pump_simulation_U.flowrate_sensor_m3h - rtb_Abs;

      /* Outport: '<Root>/flowrate_delta_m^3//h' incorporates:
       *  Abs: '<S6>/Abs'
       */
      Pump_simulation_Y.flowrate_delta_m3h = std::abs(rtb_Switch3);

      /* Switch: '<S6>/Switch2' incorporates:
       *  Inport: '<Root>/flowrate_sensor_m^3//h'
       *  Product: '<S6>/Divide2'
       *  Product: '<S6>/Divide3'
       */
      if (rtb_Switch3 > Pump_simulation_P.Switch2_Threshold) {
        rtb_Switch3 = rtb_Abs / Pump_simulation_U.flowrate_sensor_m3h;
      } else {
        rtb_Switch3 = Pump_simulation_U.flowrate_sensor_m3h / rtb_Abs;
      }

      /* End of Switch: '<S6>/Switch2' */

      /* Switch: '<S6>/Switch3' */
      if (rtb_Switch3 > Pump_simulation_P.Switch3_Threshold) {
        /* Outport: '<Root>/control_flowrate' incorporates:
         *  Constant: '<S6>/Constant5'
         */
        Pump_simulation_Y.control_flowrate = Pump_simulation_P.Constant5_Value;
      } else {
        /* Outport: '<Root>/control_flowrate' incorporates:
         *  Constant: '<S6>/Constant4'
         */
        Pump_simulation_Y.control_flowrate = Pump_simulation_P.Constant4_Value;
      }

      /* End of Switch: '<S6>/Switch3' */
    }

    /* Outport: '<Root>/volume_in_m^3' incorporates:
     *  Integrator: '<Root>/Integrator'
     */
    Pump_simulation_Y.volume_in_m3 = Pump_simulation_X.Integrator_CSTATE;
  }

  if (rtmIsMajorTimeStep((&Pump_simulation_M))) {
    PmRealVector inputs;
    PmRealVector states;
    boolean_T tmp;
    char *msg;
    if (rtmIsMajorTimeStep((&Pump_simulation_M))) {
      /* Update for SimscapeSwlState: '<S13>/SWL_STATE_0' */
      inputs.mN = 1;
      inputs.mX = &Pump_simulation_DW.SWL_STATE_0_Inputs;
      Pump_simulation_DW.SWL_STATE_0_Inputs = Pump_simulation_B.INPUT_1_1_1[0];
      states.mN = 31;
      states.mX = &Pump_simulation_DW.SWL_STATE_0_Discrete[0];
      tmp = swl_check((const Simulator *)
                      Pump_simulation_DW.SWL_STATE_0_SimulatorPtr, &inputs,
                      &states, (&Pump_simulation_M)->Timing.t[0],
                      (NeuDiagnosticManager *)
                      Pump_simulation_DW.SWL_STATE_0_DiagMgr);
      if (tmp) {
        tmp = error_buffer_is_empty(rtmGetErrorStatus((&Pump_simulation_M)));
        if (tmp) {
          msg = rtw_diagnostics_msg((const NeuDiagnosticTree *)
            Pump_simulation_DW.SWL_STATE_0_DiagTree);
          rtmSetErrorStatus((&Pump_simulation_M), msg);
        }
      }

      /* End of Update for SimscapeSwlState: '<S13>/SWL_STATE_0' */
    }
  }                                    /* end MajorTimeStep */

  if (rtmIsMajorTimeStep((&Pump_simulation_M))) {
    rt_ertODEUpdateContinuousStates(&(&Pump_simulation_M)->solverInfo);

    /* Update absolute time for base rate */
    /* The "clockTick0" counts the number of times the code of this task has
     * been executed. The absolute time is the multiplication of "clockTick0"
     * and "Timing.stepSize0". Size of "clockTick0" ensures timer will not
     * overflow during the application lifespan selected.
     * Timer of this task consists of two 32 bit unsigned integers.
     * The two integers represent the low bits Timing.clockTick0 and the high bits
     * Timing.clockTickH0. When the low bit overflows to 0, the high bits increment.
     */
    if (!(++(&Pump_simulation_M)->Timing.clockTick0)) {
      ++(&Pump_simulation_M)->Timing.clockTickH0;
    }

    (&Pump_simulation_M)->Timing.t[0] = rtsiGetSolverStopTime
      (&(&Pump_simulation_M)->solverInfo);

    {
      /* Update absolute timer for sample time: [0.001s, 0.0s] */
      /* The "clockTick1" counts the number of times the code of this task has
       * been executed. The resolution of this integer timer is 0.001, which is the step size
       * of the task. Size of "clockTick1" ensures timer will not overflow during the
       * application lifespan selected.
       * Timer of this task consists of two 32 bit unsigned integers.
       * The two integers represent the low bits Timing.clockTick1 and the high bits
       * Timing.clockTickH1. When the low bit overflows to 0, the high bits increment.
       */
      (&Pump_simulation_M)->Timing.clockTick1++;
      if (!(&Pump_simulation_M)->Timing.clockTick1) {
        (&Pump_simulation_M)->Timing.clockTickH1++;
      }
    }
  }                                    /* end MajorTimeStep */
}

/* Derivatives for root system: '<Root>' */
void Pump_simulationModelClass::Pump_simulation_derivatives()
{
  XDot_Pump_simulation_T *_rtXdot;
  _rtXdot = ((XDot_Pump_simulation_T *) (&Pump_simulation_M)->derivs);

  /* Derivatives for Integrator: '<Root>/Integrator' */
  _rtXdot->Integrator_CSTATE = Pump_simulation_B.SWL_STATE_0[1];
}

/* Model initialize function */
void Pump_simulationModelClass::initialize()
{
  /* Registration code */
  {
    /* Setup solver object */
    rtsiSetSimTimeStepPtr(&(&Pump_simulation_M)->solverInfo,
                          &(&Pump_simulation_M)->Timing.simTimeStep);
    rtsiSetTPtr(&(&Pump_simulation_M)->solverInfo, &rtmGetTPtr
                ((&Pump_simulation_M)));
    rtsiSetStepSizePtr(&(&Pump_simulation_M)->solverInfo, &(&Pump_simulation_M
                       )->Timing.stepSize0);
    rtsiSetdXPtr(&(&Pump_simulation_M)->solverInfo, &(&Pump_simulation_M)
                 ->derivs);
    rtsiSetContStatesPtr(&(&Pump_simulation_M)->solverInfo, (real_T **)
                         &(&Pump_simulation_M)->contStates);
    rtsiSetNumContStatesPtr(&(&Pump_simulation_M)->solverInfo,
      &(&Pump_simulation_M)->Sizes.numContStates);
    rtsiSetNumPeriodicContStatesPtr(&(&Pump_simulation_M)->solverInfo,
      &(&Pump_simulation_M)->Sizes.numPeriodicContStates);
    rtsiSetPeriodicContStateIndicesPtr(&(&Pump_simulation_M)->solverInfo,
      &(&Pump_simulation_M)->periodicContStateIndices);
    rtsiSetPeriodicContStateRangesPtr(&(&Pump_simulation_M)->solverInfo,
      &(&Pump_simulation_M)->periodicContStateRanges);
    rtsiSetErrorStatusPtr(&(&Pump_simulation_M)->solverInfo, (&rtmGetErrorStatus
      ((&Pump_simulation_M))));
    rtsiSetRTModelPtr(&(&Pump_simulation_M)->solverInfo, (&Pump_simulation_M));
  }

  rtsiSetSimTimeStep(&(&Pump_simulation_M)->solverInfo, MAJOR_TIME_STEP);
  (&Pump_simulation_M)->intgData.y = (&Pump_simulation_M)->odeY;
  (&Pump_simulation_M)->intgData.f[0] = (&Pump_simulation_M)->odeF[0];
  (&Pump_simulation_M)->intgData.f[1] = (&Pump_simulation_M)->odeF[1];
  (&Pump_simulation_M)->intgData.f[2] = (&Pump_simulation_M)->odeF[2];
  (&Pump_simulation_M)->contStates = ((X_Pump_simulation_T *) &Pump_simulation_X);
  rtsiSetSolverData(&(&Pump_simulation_M)->solverInfo, static_cast<void *>
                    (&(&Pump_simulation_M)->intgData));
  rtsiSetSolverName(&(&Pump_simulation_M)->solverInfo,"ode3");
  rtmSetTPtr((&Pump_simulation_M), &(&Pump_simulation_M)->Timing.tArray[0]);
  (&Pump_simulation_M)->Timing.stepSize0 = 0.001;

  /* Initialize DataMapInfo substructure containing ModelMap for C API */
  Pump_simulation_InitializeDataMapInfo((&Pump_simulation_M), &Pump_simulation_B,
    &Pump_simulation_P, &Pump_simulation_DW, &Pump_simulation_X);

  {
    const Simulator *simulator;
    NeslRtpManager *manager;
    NeuDiagnosticManager *tmp;
    NeuDiagnosticTree *tmp_0;
    Simulator *tmp_1;

    /* Start for SimscapeRtp: '<S5>/RTP_0' */
    simulator = Pump_simulation_48324b08_0_simulator_create();
    manager = swl_rtp_manager_create(simulator);
    Pump_simulation_DW.RTP_0_RtpManager = (void *)manager;
    Pump_simulation_DW.RTP_0_SetParametersNeeded = true;

    /* Start for SimscapeSwlState: '<S13>/SWL_STATE_0' */
    tmp = rtw_create_diagnostics();
    Pump_simulation_DW.SWL_STATE_0_DiagMgr = (void *)tmp;
    tmp_0 = neu_diagnostic_manager_get_initial_tree((NeuDiagnosticManager *)
      Pump_simulation_DW.SWL_STATE_0_DiagMgr);
    Pump_simulation_DW.SWL_STATE_0_DiagTree = (void *)tmp_0;
    tmp_1 = Pump_simulation_48324b08_0_simulator_create();
    Pump_simulation_DW.SWL_STATE_0_SimulatorPtr = (void *)tmp_1;
  }

  /* InitializeConditions for Integrator: '<Root>/Integrator' */
  Pump_simulation_X.Integrator_CSTATE = Pump_simulation_P.Integrator_IC;
}

/* Model terminate function */
void Pump_simulationModelClass::terminate()
{
  /* Terminate for SimscapeSwlState: '<S13>/SWL_STATE_0' */
  neu_destroy_diagnostic_manager((NeuDiagnosticManager *)
    Pump_simulation_DW.SWL_STATE_0_DiagMgr);
  Pump_simulation_48324b08_0_simulator_destroy();
}

/* Constructor */
Pump_simulationModelClass::Pump_simulationModelClass():
  Pump_simulation_B()
  ,Pump_simulation_DW()
  ,Pump_simulation_X()
  ,Pump_simulation_U()
  ,Pump_simulation_Y()
  ,Pump_simulation_M()
{
  /* Currently there is no constructor body generated.*/
}

/* Destructor */
Pump_simulationModelClass::~Pump_simulationModelClass()
{
  /* Currently there is no destructor body generated.*/
}

/* Real-Time Model get method */
RT_MODEL_Pump_simulation_T * Pump_simulationModelClass::getRTM()
{
  return (&Pump_simulation_M);
}
