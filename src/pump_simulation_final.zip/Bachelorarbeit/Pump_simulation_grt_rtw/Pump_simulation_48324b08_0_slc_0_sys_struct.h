/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef struct__SwitchedLinearClumpTag
#define struct__SwitchedLinearClumpTag

typedef struct _SwitchedLinearClumpTag {
  SwitchedLinearClump mBase;
  int32_T mRefCnt;
  PmAllocator mAlloc;
} _SwitchedLinearClump;

#else

typedef struct _SwitchedLinearClumpTag _SwitchedLinearClump;

#endif
