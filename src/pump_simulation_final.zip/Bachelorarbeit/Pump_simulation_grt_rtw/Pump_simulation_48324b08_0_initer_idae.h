/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef __Pump_simulation_48324b08_0_initer_idae_h__
#define __Pump_simulation_48324b08_0_initer_idae_h__
#ifdef __cplusplus

extern "C" {

#endif

  extern void Pump_simulation_48324b08_0_initer_idae( NeDae **dae, const
    NeModelParameters *modelParams,
    const NeSolverParameters *solverParams);

#ifdef __cplusplus

}
#endif
#endif                 /* ifndef __Pump_simulation_48324b08_0_initer_idae_h__ */
