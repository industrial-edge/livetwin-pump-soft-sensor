/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef struct__GlobalMethodTableTag
#define struct__GlobalMethodTableTag

typedef struct _GlobalMethodTableTag {
  GlobalMethodTable mBase;
  int32_T mRefCnt;
  PmAllocator mAlloc;
} _GlobalMethodTable;

#else

typedef struct _GlobalMethodTableTag _GlobalMethodTable;

#endif
