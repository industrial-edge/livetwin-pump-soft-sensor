/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_passert.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_sys_struct.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_externals.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_initer_idae_ds_passert(const NeDynamicSystem *
  sys, const NeDynamicSystemInput *t15, NeDsMethodOutput *t16)
{
  PmIntVector out;
  boolean_T t3[1];
  real_T t4[7];
  real_T t5[7];
  boolean_T t6[1];
  size_t t13;
  size_t t14;
  real_T DP_R[101];
  int32_T b;
  int32_T DP_L_idx_0;
  int32_T DP_L_idx_1;
  int32_T DP_L_idx_2;
  int32_T DP_L_idx_3;
  int32_T DP_L_idx_4;
  int32_T DP_L_idx_5;
  DP_L_idx_0 = t15->mDP_L.mX[0];
  DP_L_idx_1 = t15->mDP_L.mX[1];
  DP_L_idx_2 = t15->mDP_L.mX[2];
  DP_L_idx_3 = t15->mDP_L.mX[3];
  DP_L_idx_4 = t15->mDP_L.mX[4];
  DP_L_idx_5 = t15->mDP_L.mX[5];
  for (b = 0; b < 101; b++) {
    DP_R[b] = t15->mDP_R.mX[b];
  }

  out = t16->mPASSERT;
  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t4[t13] = DP_R[t13 + 26ULL];
  }

  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t5[t13] = DP_R[t13 + 25ULL];
  }

  t3[0ULL] = true;
  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t14 = t13 / 7ULL;
    t3[t14 > 0ULL ? 0ULL : t14] = (t3[t14 > 0ULL ? 0ULL : t14] && (t4[t13] -
      t5[t13] > 0.0));
  }

  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t4[t13] = DP_R[t13 + 42ULL];
  }

  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t5[t13] = DP_R[t13 + 41ULL];
  }

  t6[0ULL] = true;
  for (t13 = 0ULL; t13 < 7ULL; t13++) {
    t14 = t13 / 7ULL;
    t6[t14 > 0ULL ? 0ULL : t14] = (t6[t14 > 0ULL ? 0ULL : t14] && (t4[t13] -
      t5[t13] > 0.0));
  }

  out.mX[0] = (int32_T)!(DP_R[0ULL] <= 0.0);
  out.mX[1] = (int32_T)!(DP_R[4ULL] <= 0.0);
  out.mX[2] = (int32_T)!(DP_R[6ULL] <= 0.0);
  out.mX[3] = (int32_T)!(DP_R[10ULL] <= 0.0);
  out.mX[4] = (int32_T)(DP_R[50ULL] * 0.10471975511965977 > 0.0);
  out.mX[5] = (int32_T)(DP_R[51ULL] > 0.0);
  out.mX[6] = (int32_T)t3[0ULL];
  out.mX[7] = (int32_T)t6[0ULL];
  out.mX[8] = (int32_T)(DP_R[49ULL] > 0.0);
  out.mX[9] = (int32_T)(DP_L_idx_0 != 0);
  out.mX[10] = (int32_T)(DP_L_idx_1 != 0);
  out.mX[11] = (int32_T)(DP_L_idx_2 != 0);
  out.mX[12] = (int32_T)(DP_L_idx_3 != 0);
  out.mX[13] = (int32_T)(DP_L_idx_4 != 0);
  out.mX[14] = (int32_T)(DP_L_idx_5 != 0);
  out.mX[15] = 1;
  out.mX[16] = 1;
  out.mX[17] = 1;
  out.mX[18] = 1;
  out.mX[19] = 1;
  out.mX[20] = 1;
  out.mX[21] = (int32_T)(DP_R[1ULL] != 0.0);
  out.mX[22] = 1;
  out.mX[23] = (int32_T)(DP_R[7ULL] != 0.0);
  out.mX[24] = 1;
  out.mX[25] = (int32_T)(DP_R[6ULL] != 0.0);
  out.mX[26] = 1;
  out.mX[27] = 1;
  out.mX[28] = (int32_T)(DP_R[6ULL] * DP_R[6ULL] != 0.0);
  out.mX[29] = (int32_T)((!(DP_R[6ULL] * DP_R[6ULL] != 0.0)) || (DP_R[7ULL] !=
    0.0));
  out.mX[30] = 1;
  out.mX[31] = (int32_T)(DP_R[6ULL] != 0.0);
  out.mX[32] = 1;
  out.mX[33] = 1;
  out.mX[34] = (int32_T)((!(DP_R[6ULL] != 0.0)) || (DP_R[7ULL] * DP_R[7ULL] !=
    0.0));
  out.mX[35] = 1;
  out.mX[36] = (int32_T)(DP_R[50ULL] * 0.10471975511965977 != 0.0);
  out.mX[37] = 1;
  out.mX[38] = 1;
  out.mX[39] = (int32_T)(DP_R[0ULL] != 0.0);
  out.mX[40] = 1;
  out.mX[41] = 1;
  out.mX[42] = (int32_T)(DP_R[0ULL] * DP_R[0ULL] != 0.0);
  out.mX[43] = (int32_T)((!(DP_R[0ULL] * DP_R[0ULL] != 0.0)) || (DP_R[1ULL] !=
    0.0));
  out.mX[44] = 1;
  out.mX[45] = (int32_T)(DP_R[0ULL] != 0.0);
  out.mX[46] = 1;
  out.mX[47] = 1;
  out.mX[48] = (int32_T)((!(DP_R[0ULL] != 0.0)) || (DP_R[1ULL] * DP_R[1ULL] !=
    0.0));
  out.mX[49] = 1;
  (void)sys;
  (void)t16;
  return 0;
}
