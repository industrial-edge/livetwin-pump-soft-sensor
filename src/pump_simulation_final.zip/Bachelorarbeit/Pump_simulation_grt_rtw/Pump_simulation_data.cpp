/*
 * Pump_simulation_data.cpp
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Pump_simulation".
 *
 * Model version              : 1.12
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C++ source code generated on : Thu Feb 11 11:26:20 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Pump_simulation.h"
#include "Pump_simulation_private.h"

/* Block parameters (default storage) */
P_Pump_simulation_T Pump_simulationModelClass::Pump_simulation_P = {
  /* Variable: Angular_speed_treshold_for_flow_reversal
   * Referenced by: synthesized block
   */
  1.0E-9,

  /* Variable: Reference_angular_velocity
   * Referenced by: synthesized block
   */
  2900.0,

  /* Variable: Reference_density
   * Referenced by: synthesized block
   */
  1000.0,

  /* Variable: pressure_pipe_inlet_heigth
   * Referenced by: synthesized block
   */
  0.0,

  /* Variable: pressure_pipe_internal_diameter
   * Referenced by: synthesized block
   */
  0.1,

  /* Variable: pressure_pipe_length
   * Referenced by: synthesized block
   */
  5.0,

  /* Variable: pressure_pipe_outlet_heigth
   * Referenced by: synthesized block
   */
  0.0,

  /* Variable: pump_brake_power_vector
   * Referenced by: synthesized block
   */
  { 8.0, 12.5, 16.0, 19.0, 21.0, 24.5, 25.0, 25.5 },

  /* Variable: pump_delivery_vector_brake_power
   * Referenced by: synthesized block
   */
  { 0.0, 333.0, 666.0, 1000.0, 1333.0, 1666.0, 2000.0, 2333.0 },

  /* Variable: pump_delivery_vector_pressure_differential
   * Referenced by: synthesized block
   */
  { 0.0, 333.0, 666.0, 1000.0, 1333.0, 1666.0, 2000.0, 2333.0 },

  /* Variable: pump_pressure_differential_vector
   * Referenced by: synthesized block
   */
  { 8.1, 8.05, 7.9, 7.5, 7.0, 6.3, 5.5, 4.5 },

  /* Variable: suction_pipe_inlet_heigth
   * Referenced by: synthesized block
   */
  0.0,

  /* Variable: suction_pipe_internal_diameter
   * Referenced by: synthesized block
   */
  0.1,

  /* Variable: suction_pipe_length
   * Referenced by: synthesized block
   */
  5.0,

  /* Variable: suction_pipe_outlet_heigth
   * Referenced by: synthesized block
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S6>/Constant4'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S6>/Constant5'
   */
  0.0,

  /* Expression: 1
   * Referenced by: '<S7>/Constant'
   */
  1.0,

  /* Expression: 0
   * Referenced by: '<S7>/Constant1'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S7>/Switch'
   */
  0.0,

  /* Expression: 0.9
   * Referenced by: '<S7>/Switch1'
   */
  0.9,

  /* Expression: 0
   * Referenced by: '<Root>/Integrator'
   */
  0.0,

  /* Expression: 0
   * Referenced by: '<S6>/Switch2'
   */
  0.0,

  /* Expression: 0.9
   * Referenced by: '<S6>/Switch3'
   */
  0.9
};
