/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#ifndef struct__DifferentialClumpTag
#define struct__DifferentialClumpTag

typedef struct _DifferentialClumpTag {
  DifferentialClump mBase;
  int32_T mRefCnt;
  PmAllocator mAlloc;
} _DifferentialClump;

#else

typedef struct _DifferentialClumpTag _DifferentialClump;

#endif
