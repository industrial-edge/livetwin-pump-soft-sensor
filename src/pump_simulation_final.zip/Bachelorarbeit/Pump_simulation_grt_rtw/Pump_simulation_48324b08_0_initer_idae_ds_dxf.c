/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "ne_ds.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_dxf.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_sys_struct.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_externals.h"
#include "Pump_simulation_48324b08_0_initer_idae_ds_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_initer_idae_ds_dxf(const NeDynamicSystem *sys,
  const NeDynamicSystemInput *t116, NeDsMethodOutput *t117)
{
  PmRealVector out;
  real_T intrm_sf_mf_27;
  real_T intermediate_der19;
  real_T intermediate_der21;
  real_T intermediate_der22;
  real_T t4[8];
  real_T t7[8];
  real_T t9[1];
  size_t t14;
  real_T t23;
  real_T t25;
  real_T t26;
  real_T t34;
  real_T t36;
  real_T t39;
  real_T t40;
  real_T t41;
  real_T t42;
  real_T t43;
  real_T t48;
  real_T t55;
  real_T t56;
  real_T t60;
  real_T t63;
  real_T t72;
  real_T t81;
  real_T t83;
  real_T t88;
  real_T t92;
  real_T t94;
  real_T t106;
  real_T t111;
  real_T DP_R[101];
  ETTS0 efOut;
  ETTS0 b_efOut;
  real_T c_efOut[1];
  real_T d_efOut[1];
  int32_T b;
  real_T U_idx_0;
  real_T X_idx_3;
  U_idx_0 = t116->mU.mX[0];
  X_idx_3 = t116->mX.mX[3];
  for (b = 0; b < 101; b++) {
    DP_R[b] = t116->mDP_R.mX[b];
  }

  out = t117->mDXF;
  intermediate_der22 = X_idx_3 * 0.00099779981710000024;
  intermediate_der21 = intermediate_der22 * 1002.2050343789342 >= 0.0 ? 1.0 :
    -1.0;
  t23 = intermediate_der22 * DP_R[0ULL] * intermediate_der21 *
    1002.2050343789342 / (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) /
    1.0056478624965173E-6;
  t25 = X_idx_3 >= 0.0 ? 1.0 : -1.0;
  t26 = DP_R[6ULL] * X_idx_3 * t25 / (DP_R[7ULL] == 0.0 ? 1.0E-16 : DP_R[7ULL]) /
    1.0056478624965173E-6;
  if (t26 * 1.0000000000000002E-6 <= 200.0) {
    intermediate_der19 = 0.0;
  } else {
    t111 = pmf_log10(6.9 / (t26 == 0.0 ? 1.0E-16 : t26) * 999999.99999999988 +
                     pmf_pow(DP_R[15ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t26 ==
      0.0 ? 1.0E-16 : t26) * 999999.99999999988 + pmf_pow(DP_R[15ULL] / 3.7,
      1.11)) * 3.24;
    intermediate_der19 = 1.0 / (t111 == 0.0 ? 1.0E-16 : t111);
  }

  t81 = DP_R[11ULL] * 6.4361463199777107E-5;
  t83 = DP_R[6ULL] * DP_R[6ULL];
  t88 = DP_R[11ULL] * intermediate_der19;
  t40 = DP_R[7ULL] * DP_R[7ULL];
  intermediate_der19 = t88 / (DP_R[6ULL] == 0.0 ? 1.0E-16 : DP_R[6ULL]) / (t40 ==
    0.0 ? 1.0E-16 : t40) / 2.0 * X_idx_3 * X_idx_3 * t25 * 997.7998171;
  t106 = (t26 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (t26 * 1.0000000000000002E-6 <= 2000.0) {
    t111 = 0.0;
  } else if (t26 * 1.0000000000000002E-6 <= 4000.0) {
    t111 = t106 * t106 * 3.0 - t106 * t106 * t106 * 2.0;
  } else {
    t111 = 1.0;
  }

  if (U_idx_0 >= 0.0) {
    t34 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  } else {
    t34 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[49ULL] * DP_R[49ULL]);
  }

  t43 = DP_R[50ULL] * 0.10471975511965977;
  t36 = t43 / (t34 == 0.0 ? 1.0E-16 : t34);
  t34 = U_idx_0 / (t43 == 0.0 ? 1.0E-16 : t43) * (U_idx_0 / (t43 == 0.0 ?
    1.0E-16 : t43)) * 997.7998171 / (DP_R[51ULL] == 0.0 ? 1.0E-16 : DP_R[51ULL]);
  t92 = DP_R[50ULL] * DP_R[50ULL] * DP_R[50ULL] * 0.001148380617788882;
  intrm_sf_mf_27 = U_idx_0 * U_idx_0 / (t92 == 0.0 ? 1.0E-16 : t92) *
    997.7998171 / (DP_R[51ULL] == 0.0 ? 1.0E-16 : DP_R[51ULL]);
  if (t23 * 1.0000000000000002E-6 <= 200.0) {
    t39 = 0.0;
  } else {
    t56 = pmf_log10(6.9 / (t23 == 0.0 ? 1.0E-16 : t23) * 999999.99999999988 +
                    pmf_pow(DP_R[76ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t23 ==
      0.0 ? 1.0E-16 : t23) * 999999.99999999988 + pmf_pow(DP_R[76ULL] / 3.7,
      1.11)) * 3.24;
    t39 = 1.0 / (t56 == 0.0 ? 1.0E-16 : t56);
  }

  t55 = DP_R[5ULL] * 6.4361463199777107E-5;
  t56 = DP_R[0ULL] * DP_R[0ULL];
  t41 = t55 / (t56 == 0.0 ? 1.0E-16 : t56) / (DP_R[1ULL] == 0.0 ? 1.0E-16 :
    DP_R[1ULL]) / 2.0 * intermediate_der22 * 999999.99999999977;
  t60 = DP_R[5ULL] * t39;
  t63 = DP_R[1ULL] * DP_R[1ULL];
  t39 = t60 / (DP_R[0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) / (t63 == 0.0 ? 1.0E-16
    : t63) / 2.0 * intermediate_der22 * intermediate_der22 * intermediate_der21 *
    1.002205034378934E+9;
  t42 = (t23 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (t23 * 1.0000000000000002E-6 <= 2000.0) {
    t43 = 0.0;
  } else if (t23 * 1.0000000000000002E-6 <= 4000.0) {
    t43 = t42 * t42 * 3.0 - t42 * t42 * t42 * 2.0;
  } else {
    t43 = 1.0;
  }

  t48 = 1.0 / (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) * DP_R[0ULL] *
    0.00099779981710000024 * intermediate_der21 * 9.9657650729845309E+8;
  t92 = 1.0 / (DP_R[7ULL] == 0.0 ? 1.0E-16 : DP_R[7ULL]) * DP_R[6ULL] * t25 *
    994383.8567085535;
  if (t26 * 1.0000000000000002E-6 <= 200.0) {
    U_idx_0 = 0.0;
  } else {
    t94 = (6.9 / (t26 == 0.0 ? 1.0E-16 : t26) * 999999.99999999988 + pmf_pow
           (DP_R[15ULL] / 3.7, 1.11)) * 2.3025850929940459;
    U_idx_0 = pmf_log10(6.9 / (t26 == 0.0 ? 1.0E-16 : t26) * 999999.99999999988
                        + pmf_pow(DP_R[15ULL] / 3.7, 1.11)) * pmf_log10(6.9 /
      (t26 == 0.0 ? 1.0E-16 : t26) * 999999.99999999988 + pmf_pow(DP_R[15ULL] /
      3.7, 1.11)) * pmf_log10(6.9 / (t26 == 0.0 ? 1.0E-16 : t26) *
      999999.99999999988 + pmf_pow(DP_R[15ULL] / 3.7, 1.11)) * pmf_log10(6.9 /
      (t26 == 0.0 ? 1.0E-16 : t26) * 999999.99999999988 + pmf_pow(DP_R[15ULL] /
      3.7, 1.11)) * 10.497600000000002;
    t72 = t26 * t26;
    U_idx_0 = -1.0 / (U_idx_0 == 0.0 ? 1.0E-16 : U_idx_0) * (-6.9 / (t72 == 0.0 ?
      1.0E-16 : t72)) * (1.0 / (t94 == 0.0 ? 1.0E-16 : t94)) * pmf_log10(6.9 /
      (t26 == 0.0 ? 1.0E-16 : t26) * 999999.99999999988 + pmf_pow(DP_R[15ULL] /
      3.7, 1.11)) * t92 * 6.4799999999999991E+6;
  }

  t94 = t81 / (t83 == 0.0 ? 1.0E-16 : t83) / (DP_R[7ULL] == 0.0 ? 1.0E-16 :
    DP_R[7ULL]) / 2.0 * 997.7998171;
  t88 = ((1.0 / (t40 == 0.0 ? 1.0E-16 : t40) * (1.0 / (DP_R[6ULL] == 0.0 ?
            1.0E-16 : DP_R[6ULL])) * X_idx_3 * DP_R[11ULL] * U_idx_0 *
          498.89990855 + t88 / (DP_R[6ULL] == 0.0 ? 1.0E-16 : DP_R[6ULL]) / (t40
           == 0.0 ? 1.0E-16 : t40) / 2.0 * 997.7998171) * X_idx_3 + t88 / (DP_R
          [6ULL] == 0.0 ? 1.0E-16 : DP_R[6ULL]) / (t40 == 0.0 ? 1.0E-16 : t40) /
         2.0 * X_idx_3 * 997.7998171) * t25;
  t72 = t92 * 5.0000000000000013E-10;
  if (t26 * 1.0000000000000002E-6 <= 2000.0) {
    t25 = 0.0;
  } else if (t26 * 1.0000000000000002E-6 <= 4000.0) {
    t25 = t72 * t106 * 6.0 - t106 * t106 * t72 * 6.0;
  } else {
    t25 = 0.0;
  }

  if (t26 * 1.0000000000000002E-6 <= 2000.0) {
    t72 = t94 * 1.0000000000000001E-11;
  } else if (t26 * 1.0000000000000002E-6 <= 4000.0) {
    t72 = (t94 * 1.0000000000000001E-11 + (intermediate_der19 *
            1.0000000000000002E-17 - t81 / (t83 == 0.0 ? 1.0E-16 : t83) / (DP_R
             [7ULL] == 0.0 ? 1.0E-16 : DP_R[7ULL]) / 2.0 * X_idx_3 * 997.7998171
            * 1.0000000000000001E-11) * t25) + (t88 * 1.0000000000000002E-17 -
      t94 * 1.0000000000000001E-11) * t111;
  } else {
    t72 = t88 * 1.0000000000000002E-17;
  }

  if (t23 * 1.0000000000000002E-6 <= 200.0) {
    t25 = 0.0;
  } else {
    U_idx_0 = (6.9 / (t23 == 0.0 ? 1.0E-16 : t23) * 999999.99999999988 + pmf_pow
               (DP_R[76ULL] / 3.7, 1.11)) * 2.3025850929940459;
    t94 = pmf_log10(6.9 / (t23 == 0.0 ? 1.0E-16 : t23) * 999999.99999999988 +
                    pmf_pow(DP_R[76ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t23 ==
      0.0 ? 1.0E-16 : t23) * 999999.99999999988 + pmf_pow(DP_R[76ULL] / 3.7,
      1.11)) * pmf_log10(6.9 / (t23 == 0.0 ? 1.0E-16 : t23) * 999999.99999999988
                         + pmf_pow(DP_R[76ULL] / 3.7, 1.11)) * pmf_log10(6.9 /
      (t23 == 0.0 ? 1.0E-16 : t23) * 999999.99999999988 + pmf_pow(DP_R[76ULL] /
      3.7, 1.11)) * 10.497600000000002;
    t88 = t23 * t23;
    t25 = -1.0 / (t94 == 0.0 ? 1.0E-16 : t94) * (-6.9 / (t88 == 0.0 ? 1.0E-16 :
      t88)) * (1.0 / (U_idx_0 == 0.0 ? 1.0E-16 : U_idx_0)) * pmf_log10(6.9 /
      (t23 == 0.0 ? 1.0E-16 : t23) * 999999.99999999988 + pmf_pow(DP_R[76ULL] /
      3.7, 1.11)) * t48 * 6.4799999999999991E+6;
  }

  t26 = t55 / (t56 == 0.0 ? 1.0E-16 : t56) / (DP_R[1ULL] == 0.0 ? 1.0E-16 :
    DP_R[1ULL]) / 2.0 * 0.00099779981710000024 * 999999.99999999977;
  intermediate_der19 = ((1.0 / (t63 == 0.0 ? 1.0E-16 : t63) * (1.0 / (DP_R[0ULL]
    == 0.0 ? 1.0E-16 : DP_R[0ULL])) * intermediate_der22 * DP_R[5ULL] * t25 *
    499999.99999999988 + t60 / (DP_R[0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) / (t63
    == 0.0 ? 1.0E-16 : t63) / 2.0 * 0.00099779981710000024 * 999999.99999999977)
                        * intermediate_der22 * 1002.2050343789342 + t60 / (DP_R
    [0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) / (t63 == 0.0 ? 1.0E-16 : t63) / 2.0 *
                        intermediate_der22 * 0.00099779981710000024 *
                        1.002205034378934E+9) * intermediate_der21;
  intermediate_der22 = t48 * 5.0000000000000013E-10;
  if (t23 * 1.0000000000000002E-6 <= 2000.0) {
    intermediate_der21 = 0.0;
  } else if (t23 * 1.0000000000000002E-6 <= 4000.0) {
    intermediate_der21 = intermediate_der22 * t42 * 6.0 - t42 * t42 *
      intermediate_der22 * 6.0;
  } else {
    intermediate_der21 = 0.0;
  }

  if (t23 * 1.0000000000000002E-6 <= 2000.0) {
    intermediate_der22 = t26 * 1.0000000000000001E-11;
  } else if (t23 * 1.0000000000000002E-6 <= 4000.0) {
    intermediate_der22 = (t26 * 1.0000000000000001E-11 + (t39 *
      1.0000000000000002E-17 - t41 * 1.0000000000000001E-11) *
                          intermediate_der21) + (intermediate_der19 *
      1.0000000000000002E-17 - t26 * 1.0000000000000001E-11) * t43;
  } else {
    intermediate_der22 = intermediate_der19 * 1.0000000000000002E-17;
  }

  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t4[t14] = DP_R[t14 + 60ULL];
  }

  t9[0ULL] = t36 * X_idx_3;
  t14 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)t4, (void *)t9, (void *)&t14);
  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t4[t14] = DP_R[t14 + 85ULL];
  }

  t9[0ULL] = t36 * X_idx_3;
  t14 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&b_efOut.mField0, (void *)
    &b_efOut.mField1, (void *)&b_efOut.mField2, (void *)t4, (void *)t9, (void *)
    &t14);
  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t4[t14] = DP_R[t14 + 68ULL];
  }

  for (t14 = 0ULL; t14 < 8ULL; t14++) {
    t7[t14] = DP_R[t14 + 93ULL];
  }

  t14 = 8ULL;
  tlu2_1d_linear_linear_derivatives((void *)&c_efOut, (void *)efOut.mField0,
    (void *)efOut.mField1, (void *)efOut.mField2, (void *)t4, (void *)&t14);
  t14 = 8ULL;
  tlu2_1d_linear_linear_derivatives((void *)&d_efOut, (void *)b_efOut.mField0,
    (void *)b_efOut.mField1, (void *)b_efOut.mField2, (void *)t7, (void *)&t14);
  out.mX[0] = -intermediate_der22;
  out.mX[1] = -t72;
  out.mX[2] = -(c_efOut[0] * t36 * t34);
  out.mX[3] = -(d_efOut[0] * t36 * intrm_sf_mf_27 * 1000.0);
  (void)sys;
  (void)t117;
  return 0;
}
