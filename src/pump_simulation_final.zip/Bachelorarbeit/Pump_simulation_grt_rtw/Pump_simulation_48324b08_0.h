/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */
/* Pump_simulation_48324b08_0.h - header for module Pump_simulation_48324b08_0 */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef PUMP_SIMULATION_48324B08_0_H
#define PUMP_SIMULATION_48324B08_0_H   1

  extern SwitchedLinearSystem *Pump_simulation_48324b08_0(PmAllocator *allocator
    );

#endif                                /* #ifndef PUMP_SIMULATION_48324B08_0_H */

#ifdef __cplusplus

}
#endif
