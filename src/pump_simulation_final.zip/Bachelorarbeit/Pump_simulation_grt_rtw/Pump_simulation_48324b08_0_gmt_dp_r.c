/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "Pump_simulation_48324b08_0_gmt_dp_r.h"
#include "Pump_simulation_48324b08_0_gmt_sys_struct.h"
#include "Pump_simulation_48324b08_0_gmt_externals.h"
#include "Pump_simulation_48324b08_0_gmt_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_gmt_dp_r(const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t25, GmtMethodOutput *t26)
{
  PmRealVector out;
  real_T parameter_update10;
  real_T parameter_update11;
  real_T parameter_update12[8];
  real_T parameter_update14[8];
  real_T parameter_update19[8];
  real_T parameter_update21[8];
  real_T t3[8];
  real_T t4[101];
  size_t t15;
  real_T P_R[43];
  ETTS0 efOut;
  ETTS0 b_efOut;
  P_R[0] = t25->mP_R.mX[0];
  P_R[1] = t25->mP_R.mX[1];
  P_R[2] = t25->mP_R.mX[2];
  P_R[3] = t25->mP_R.mX[3];
  P_R[4] = t25->mP_R.mX[4];
  P_R[5] = t25->mP_R.mX[5];
  P_R[6] = t25->mP_R.mX[6];
  P_R[7] = t25->mP_R.mX[7];
  P_R[8] = t25->mP_R.mX[8];
  P_R[9] = t25->mP_R.mX[9];
  P_R[10] = t25->mP_R.mX[10];
  P_R[11] = t25->mP_R.mX[11];
  P_R[12] = t25->mP_R.mX[12];
  P_R[13] = t25->mP_R.mX[13];
  P_R[14] = t25->mP_R.mX[14];
  P_R[15] = t25->mP_R.mX[15];
  P_R[16] = t25->mP_R.mX[16];
  P_R[17] = t25->mP_R.mX[17];
  P_R[18] = t25->mP_R.mX[18];
  P_R[19] = t25->mP_R.mX[19];
  P_R[20] = t25->mP_R.mX[20];
  P_R[21] = t25->mP_R.mX[21];
  P_R[22] = t25->mP_R.mX[22];
  P_R[23] = t25->mP_R.mX[23];
  P_R[24] = t25->mP_R.mX[24];
  P_R[25] = t25->mP_R.mX[25];
  P_R[26] = t25->mP_R.mX[26];
  P_R[27] = t25->mP_R.mX[27];
  P_R[28] = t25->mP_R.mX[28];
  P_R[29] = t25->mP_R.mX[29];
  P_R[30] = t25->mP_R.mX[30];
  P_R[31] = t25->mP_R.mX[31];
  P_R[32] = t25->mP_R.mX[32];
  P_R[33] = t25->mP_R.mX[33];
  P_R[34] = t25->mP_R.mX[34];
  P_R[35] = t25->mP_R.mX[35];
  P_R[36] = t25->mP_R.mX[36];
  P_R[37] = t25->mP_R.mX[37];
  P_R[38] = t25->mP_R.mX[38];
  P_R[39] = t25->mP_R.mX[39];
  P_R[40] = t25->mP_R.mX[40];
  P_R[41] = t25->mP_R.mX[41];
  P_R[42] = t25->mP_R.mX[42];
  out = t26->mDP_R;
  parameter_update10 = P_R[41ULL] - P_R[40ULL];
  parameter_update11 = P_R[37ULL] - P_R[36ULL];
  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    parameter_update12[t15] = P_R[t15 + 17ULL];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    parameter_update14[t15] = P_R[t15 + 25ULL];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    parameter_update19[t15] = P_R[t15 + 9ULL];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    parameter_update21[t15] = P_R[t15 + 1ULL];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t3[t15] = parameter_update12[t15] * 16.666666666666664;
  }

  t15 = 8ULL;
  tlu2_1d_linear_linear_process((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)t3, (void *)parameter_update19, (void *)&t15);
  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t3[t15] = parameter_update14[t15] * 16.666666666666664;
  }

  t15 = 8ULL;
  tlu2_1d_linear_linear_process((void *)&b_efOut.mField0, (void *)
    &b_efOut.mField1, (void *)t3, (void *)parameter_update21, (void *)&t15);
  t4[0ULL] = P_R[39ULL];
  t4[1ULL] = P_R[39ULL] * P_R[39ULL] * 3.1415926535897931 / 4.0;
  t4[2ULL] = P_R[40ULL];
  t4[3ULL] = P_R[41ULL];
  t4[4ULL] = P_R[42ULL];
  t4[5ULL] = P_R[42ULL] + 1.0;
  t4[6ULL] = P_R[35ULL];
  t4[7ULL] = P_R[35ULL] * P_R[35ULL] * 3.1415926535897931 / 4.0;
  t4[8ULL] = P_R[36ULL];
  t4[9ULL] = P_R[37ULL];
  t4[10ULL] = P_R[38ULL];
  t4[11ULL] = P_R[38ULL] + 1.0;
  t4[12ULL] = parameter_update10;
  t4[13ULL] = parameter_update10 * 9785.0735763637149;
  t4[14ULL] = parameter_update11;
  t4[15ULL] = 1.5E-5 / (P_R[35ULL] == 0.0 ? 1.0E-16 : P_R[35ULL]);
  t4[16ULL] = parameter_update11 * 9785.0735763637149;
  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 17ULL] = parameter_update12[t15];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 25ULL] = parameter_update12[t15] * 16.666666666666664;
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 33ULL] = parameter_update14[t15];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 41ULL] = parameter_update14[t15] * 16.666666666666664;
  }

  t4[49ULL] = P_R[0ULL];
  t4[50ULL] = P_R[34ULL];
  t4[51ULL] = P_R[33ULL];
  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 52ULL] = parameter_update19[t15];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 60ULL] = efOut.mField0[t15];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 68ULL] = efOut.mField1[t15];
  }

  t4[76ULL] = 1.5E-5 / (P_R[39ULL] == 0.0 ? 1.0E-16 : P_R[39ULL]);
  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 77ULL] = parameter_update21[t15];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 85ULL] = b_efOut.mField0[t15];
  }

  for (t15 = 0ULL; t15 < 8ULL; t15++) {
    t4[t15 + 93ULL] = b_efOut.mField1[t15];
  }

  out.mX[0] = t4[0];
  out.mX[1] = t4[1];
  out.mX[2] = t4[2];
  out.mX[3] = t4[3];
  out.mX[4] = t4[4];
  out.mX[5] = t4[5];
  out.mX[6] = t4[6];
  out.mX[7] = t4[7];
  out.mX[8] = t4[8];
  out.mX[9] = t4[9];
  out.mX[10] = t4[10];
  out.mX[11] = t4[11];
  out.mX[12] = t4[12];
  out.mX[13] = t4[13];
  out.mX[14] = t4[14];
  out.mX[15] = t4[15];
  out.mX[16] = t4[16];
  out.mX[17] = t4[17];
  out.mX[18] = t4[18];
  out.mX[19] = t4[19];
  out.mX[20] = t4[20];
  out.mX[21] = t4[21];
  out.mX[22] = t4[22];
  out.mX[23] = t4[23];
  out.mX[24] = t4[24];
  out.mX[25] = t4[25];
  out.mX[26] = t4[26];
  out.mX[27] = t4[27];
  out.mX[28] = t4[28];
  out.mX[29] = t4[29];
  out.mX[30] = t4[30];
  out.mX[31] = t4[31];
  out.mX[32] = t4[32];
  out.mX[33] = t4[33];
  out.mX[34] = t4[34];
  out.mX[35] = t4[35];
  out.mX[36] = t4[36];
  out.mX[37] = t4[37];
  out.mX[38] = t4[38];
  out.mX[39] = t4[39];
  out.mX[40] = t4[40];
  out.mX[41] = t4[41];
  out.mX[42] = t4[42];
  out.mX[43] = t4[43];
  out.mX[44] = t4[44];
  out.mX[45] = t4[45];
  out.mX[46] = t4[46];
  out.mX[47] = t4[47];
  out.mX[48] = t4[48];
  out.mX[49] = t4[49];
  out.mX[50] = t4[50];
  out.mX[51] = t4[51];
  out.mX[52] = t4[52];
  out.mX[53] = t4[53];
  out.mX[54] = t4[54];
  out.mX[55] = t4[55];
  out.mX[56] = t4[56];
  out.mX[57] = t4[57];
  out.mX[58] = t4[58];
  out.mX[59] = t4[59];
  out.mX[60] = t4[60];
  out.mX[61] = t4[61];
  out.mX[62] = t4[62];
  out.mX[63] = t4[63];
  out.mX[64] = t4[64];
  out.mX[65] = t4[65];
  out.mX[66] = t4[66];
  out.mX[67] = t4[67];
  out.mX[68] = t4[68];
  out.mX[69] = t4[69];
  out.mX[70] = t4[70];
  out.mX[71] = t4[71];
  out.mX[72] = t4[72];
  out.mX[73] = t4[73];
  out.mX[74] = t4[74];
  out.mX[75] = t4[75];
  out.mX[76] = t4[76];
  out.mX[77] = t4[77];
  out.mX[78] = t4[78];
  out.mX[79] = t4[79];
  out.mX[80] = t4[80];
  out.mX[81] = t4[81];
  out.mX[82] = t4[82];
  out.mX[83] = t4[83];
  out.mX[84] = t4[84];
  out.mX[85] = t4[85];
  out.mX[86] = t4[86];
  out.mX[87] = t4[87];
  out.mX[88] = t4[88];
  out.mX[89] = t4[89];
  out.mX[90] = t4[90];
  out.mX[91] = t4[91];
  out.mX[92] = t4[92];
  out.mX[93] = t4[93];
  out.mX[94] = t4[94];
  out.mX[95] = t4[95];
  out.mX[96] = t4[96];
  out.mX[97] = t4[97];
  out.mX[98] = t4[98];
  out.mX[99] = t4[99];
  out.mX[100] = t4[100];
  (void)sys;
  (void)t26;
  return 0;
}
