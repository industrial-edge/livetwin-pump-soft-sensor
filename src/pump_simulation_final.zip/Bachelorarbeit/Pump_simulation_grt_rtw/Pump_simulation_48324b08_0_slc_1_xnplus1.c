/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "Pump_simulation_48324b08_0_slc_1_xnplus1.h"
#include "Pump_simulation_48324b08_0_slc_1_sys_struct.h"
#include "Pump_simulation_48324b08_0_slc_1_externals.h"
#include "Pump_simulation_48324b08_0_slc_1_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_slc_1_xnplus1(const SwitchedLinearClump *sys,
  const NeDynamicSystemInput *t16, SlcMethodOutput *t17)
{
  PmRealVector out;
  real_T t3[8];
  real_T t4[1];
  size_t t7;
  real_T t9;
  real_T t13;
  real_T DP_R[19];
  ETTS0 efOut;
  real_T b_efOut[1];
  int32_T M_idx_0;
  real_T U_idx_0;
  real_T X_idx_1;
  M_idx_0 = t16->mM.mX[0];
  U_idx_0 = t16->mU.mX[0];
  X_idx_1 = t16->mX.mX[1];
  DP_R[0] = t16->mDP_R.mX[0];
  DP_R[1] = t16->mDP_R.mX[1];
  DP_R[2] = t16->mDP_R.mX[2];
  DP_R[3] = t16->mDP_R.mX[3];
  DP_R[4] = t16->mDP_R.mX[4];
  DP_R[5] = t16->mDP_R.mX[5];
  DP_R[6] = t16->mDP_R.mX[6];
  DP_R[7] = t16->mDP_R.mX[7];
  DP_R[8] = t16->mDP_R.mX[8];
  DP_R[9] = t16->mDP_R.mX[9];
  DP_R[10] = t16->mDP_R.mX[10];
  DP_R[11] = t16->mDP_R.mX[11];
  DP_R[12] = t16->mDP_R.mX[12];
  DP_R[13] = t16->mDP_R.mX[13];
  DP_R[14] = t16->mDP_R.mX[14];
  DP_R[15] = t16->mDP_R.mX[15];
  DP_R[16] = t16->mDP_R.mX[16];
  DP_R[17] = t16->mDP_R.mX[17];
  DP_R[18] = t16->mDP_R.mX[18];
  out = t17->mXNPLUS1;
  t9 = DP_R[1ULL] * DP_R[1ULL] * DP_R[1ULL] * 0.001148380617788882;
  t13 = U_idx_0 * U_idx_0 / (t9 == 0.0 ? 1.0E-16 : t9) * 997.7998171 / (DP_R
    [0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]);
  if (M_idx_0 != 0) {
    t9 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[18ULL] * DP_R[18ULL]);
  } else {
    t9 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[18ULL] * DP_R[18ULL]);
  }

  for (t7 = 0ULL; t7 < 8ULL; t7++) {
    t3[t7] = DP_R[t7 + 2ULL];
  }

  t4[0ULL] = DP_R[1ULL] * 0.10471975511965977 / (t9 == 0.0 ? 1.0E-16 : t9) *
    X_idx_1;
  t7 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)t3, (void *)t4, (void *)&t7);
  for (t7 = 0ULL; t7 < 8ULL; t7++) {
    t3[t7] = DP_R[t7 + 10ULL];
  }

  t7 = 8ULL;
  tlu2_1d_linear_linear_value((void *)&b_efOut, (void *)efOut.mField0, (void *)
    efOut.mField1, (void *)efOut.mField2, (void *)t3, (void *)&t7);
  out.mX[0] = b_efOut[0] * t13 * 1000.0 / -1.0;
  (void)sys;
  (void)t17;
  return 0;
}
