/*
 * Pump_simulation_capi.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "Pump_simulation".
 *
 * Model version              : 1.12
 * Simulink Coder version : 9.3 (R2020a) 18-Nov-2019
 * C++ source code generated on : Thu Feb 11 11:26:20 2021
 *
 * Target selection: grt.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Intel->x86-64 (Windows64)
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_Pump_simulation_capi_h
#define RTW_HEADER_Pump_simulation_capi_h
#include "Pump_simulation.h"

extern void Pump_simulation_InitializeDataMapInfo(RT_MODEL_Pump_simulation_T *
  const Pump_simulation_M, B_Pump_simulation_T *Pump_simulation_B,
  P_Pump_simulation_T *Pump_simulation_P, DW_Pump_simulation_T
  *Pump_simulation_DW, X_Pump_simulation_T *Pump_simulation_X);

#endif                                 /* RTW_HEADER_Pump_simulation_capi_h */

/* EOF: Pump_simulation_capi.h */
