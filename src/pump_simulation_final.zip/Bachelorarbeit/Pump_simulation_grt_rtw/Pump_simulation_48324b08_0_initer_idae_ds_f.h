/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */
/* Pump_simulation_48324b08_0_initer_idae_ds_f.h - header for method Pump_simulation_48324b08_0_initer_idae_ds_f */
#ifdef __cplusplus

extern "C" {

#endif

#ifndef PUMP_SIMULATION_48324B08_0_INITER_IDAE_DS_F_H
#define PUMP_SIMULATION_48324B08_0_INITER_IDAE_DS_F_H 1

  extern int32_T Pump_simulation_48324b08_0_initer_idae_ds_f(const
    NeDynamicSystem *sys, const NeDynamicSystemInput *in,NeDsMethodOutput *ou );

#endif               /* #ifndef PUMP_SIMULATION_48324B08_0_INITER_IDAE_DS_F_H */

#ifdef __cplusplus

}
#endif
