/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "Pump_simulation_48324b08_0_slc_0_j.h"
#include "Pump_simulation_48324b08_0_slc_0_sys_struct.h"
#include "Pump_simulation_48324b08_0_slc_0_externals.h"
#include "Pump_simulation_48324b08_0_slc_0_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_slc_0_j(const SwitchedLinearClump *sys, const
  NeDynamicSystemInput *t114, SlcMethodOutput *t115)
{
  PmRealVector out;
  real_T intermediate_der18;
  real_T t3[8];
  real_T t7[1];
  size_t t13;
  real_T t28;
  real_T t30;
  real_T t31;
  real_T t33;
  real_T t34;
  real_T t36;
  real_T t37;
  real_T t38;
  real_T t40;
  real_T t42;
  real_T t46;
  real_T t49;
  real_T t52;
  real_T t56;
  real_T t63;
  real_T t66;
  real_T t95;
  real_T t100;
  real_T t101;
  real_T t102;
  real_T t103;
  real_T t108;
  real_T t111;
  real_T DP_R[29];
  ETTS0 efOut;
  real_T b_efOut[1];
  real_T U_idx_0;
  real_T X_idx_2;
  int32_T M_idx_6;
  int32_T M_idx_13;
  int32_T M_idx_11;
  int32_T M_idx_12;
  int32_T M_idx_14;
  int32_T M_idx_15;
  int32_T M_idx_0;
  int32_T M_idx_1;
  int32_T M_idx_10;
  M_idx_0 = t114->mM.mX[0];
  M_idx_1 = t114->mM.mX[1];
  M_idx_6 = t114->mM.mX[6];
  M_idx_10 = t114->mM.mX[10];
  M_idx_11 = t114->mM.mX[11];
  M_idx_12 = t114->mM.mX[12];
  M_idx_13 = t114->mM.mX[13];
  M_idx_14 = t114->mM.mX[14];
  M_idx_15 = t114->mM.mX[15];
  U_idx_0 = t114->mU.mX[0];
  X_idx_2 = t114->mX.mX[2];
  DP_R[0] = t114->mDP_R.mX[0];
  DP_R[1] = t114->mDP_R.mX[1];
  DP_R[2] = t114->mDP_R.mX[2];
  DP_R[3] = t114->mDP_R.mX[3];
  DP_R[4] = t114->mDP_R.mX[4];
  DP_R[5] = t114->mDP_R.mX[5];
  DP_R[6] = t114->mDP_R.mX[6];
  DP_R[7] = t114->mDP_R.mX[7];
  DP_R[8] = t114->mDP_R.mX[8];
  DP_R[9] = t114->mDP_R.mX[9];
  DP_R[10] = t114->mDP_R.mX[10];
  DP_R[11] = t114->mDP_R.mX[11];
  DP_R[12] = t114->mDP_R.mX[12];
  DP_R[13] = t114->mDP_R.mX[13];
  DP_R[14] = t114->mDP_R.mX[14];
  DP_R[15] = t114->mDP_R.mX[15];
  DP_R[16] = t114->mDP_R.mX[16];
  DP_R[17] = t114->mDP_R.mX[17];
  DP_R[18] = t114->mDP_R.mX[18];
  DP_R[19] = t114->mDP_R.mX[19];
  DP_R[20] = t114->mDP_R.mX[20];
  DP_R[21] = t114->mDP_R.mX[21];
  DP_R[22] = t114->mDP_R.mX[22];
  DP_R[23] = t114->mDP_R.mX[23];
  DP_R[24] = t114->mDP_R.mX[24];
  DP_R[25] = t114->mDP_R.mX[25];
  DP_R[26] = t114->mDP_R.mX[26];
  DP_R[27] = t114->mDP_R.mX[27];
  DP_R[28] = t114->mDP_R.mX[28];
  out = t115->mJ;
  intermediate_der18 = X_idx_2 * 0.00099779981710000024;
  t100 = DP_R[5ULL] * 6.4361463199777107E-5;
  t30 = DP_R[4ULL] * DP_R[4ULL];
  t31 = t100 / (t30 == 0.0 ? 1.0E-16 : t30) / (DP_R[3ULL] == 0.0 ? 1.0E-16 :
    DP_R[3ULL]) / 2.0 * X_idx_2 * 997.7998171;
  t34 = DP_R[10ULL] * 0.10471975511965977;
  t33 = U_idx_0 / (t34 == 0.0 ? 1.0E-16 : t34) * (U_idx_0 / (t34 == 0.0 ?
    1.0E-16 : t34)) * 997.7998171 / (DP_R[9ULL] == 0.0 ? 1.0E-16 : DP_R[9ULL]);
  t38 = DP_R[2ULL] * 6.4361463199777107E-5;
  t101 = DP_R[1ULL] * DP_R[1ULL];
  t36 = t38 / (t101 == 0.0 ? 1.0E-16 : t101) / (DP_R[0ULL] == 0.0 ? 1.0E-16 :
    DP_R[0ULL]) / 2.0 * intermediate_der18 * 999999.99999999977;
  t37 = M_idx_6 != 0 ? 1.0 : -1.0;
  t40 = intermediate_der18 * DP_R[1ULL] * t37 * 1002.2050343789342 / (DP_R[0ULL]
    == 0.0 ? 1.0E-16 : DP_R[0ULL]) / 1.0056478624965173E-6;
  t42 = M_idx_13 != 0 ? 1.0 : -1.0;
  t111 = DP_R[4ULL] * X_idx_2 * t42 / (DP_R[3ULL] == 0.0 ? 1.0E-16 : DP_R[3ULL])
    / 1.0056478624965173E-6;
  t108 = (t111 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_11 != 0) {
    t46 = 0.0;
  } else if (M_idx_12 != 0) {
    t46 = t108 * t108 * 3.0 - t108 * t108 * t108 * 2.0;
  } else {
    t46 = 1.0;
  }

  if (M_idx_14 != 0) {
    t52 = 0.0;
  } else {
    t52 = pmf_log10(6.9 / (t111 == 0.0 ? 1.0E-16 : t111) * 999999.99999999988 +
                    pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t111 ==
      0.0 ? 1.0E-16 : t111) * 999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7,
      1.11)) * 3.24;
    t52 = 1.0 / (t52 == 0.0 ? 1.0E-16 : t52);
  }

  t95 = DP_R[5ULL] * t52;
  t56 = DP_R[3ULL] * DP_R[3ULL];
  if (M_idx_15 != 0) {
    t49 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[28ULL] * DP_R[28ULL]);
  } else {
    t49 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R[28ULL] * DP_R[28ULL]);
  }

  t28 = t34 / (t49 == 0.0 ? 1.0E-16 : t49);
  t49 = (t40 * 1.0000000000000002E-6 - 2000.0) / 2000.0;
  if (M_idx_0 != 0) {
    t34 = 0.0;
  } else if (M_idx_1 != 0) {
    t34 = t49 * t49 * 3.0 - t49 * t49 * t49 * 2.0;
  } else {
    t34 = 1.0;
  }

  if (M_idx_10 != 0) {
    t52 = 0.0;
  } else {
    t52 = pmf_log10(6.9 / (t40 == 0.0 ? 1.0E-16 : t40) * 999999.99999999988 +
                    pmf_pow(DP_R[27ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t40 ==
      0.0 ? 1.0E-16 : t40) * 999999.99999999988 + pmf_pow(DP_R[27ULL] / 3.7,
      1.11)) * 3.24;
    t52 = 1.0 / (t52 == 0.0 ? 1.0E-16 : t52);
  }

  t63 = DP_R[2ULL] * t52;
  t66 = DP_R[0ULL] * DP_R[0ULL];
  t100 = t100 / (t30 == 0.0 ? 1.0E-16 : t30) / (DP_R[3ULL] == 0.0 ? 1.0E-16 :
    DP_R[3ULL]) / 2.0 * 997.7998171;
  t30 = t38 / (t101 == 0.0 ? 1.0E-16 : t101) / (DP_R[0ULL] == 0.0 ? 1.0E-16 :
    DP_R[0ULL]) / 2.0 * 0.00099779981710000024 * 999999.99999999977;
  t38 = 1.0 / (DP_R[0ULL] == 0.0 ? 1.0E-16 : DP_R[0ULL]) * DP_R[1ULL] *
    0.00099779981710000024 * t37 * 9.9657650729845309E+8;
  t101 = 1.0 / (DP_R[3ULL] == 0.0 ? 1.0E-16 : DP_R[3ULL]) * DP_R[4ULL] * t42 *
    994383.8567085535;
  t102 = t101 * 5.0000000000000013E-10;
  if (M_idx_11 != 0) {
    t103 = 0.0;
  } else if (M_idx_12 != 0) {
    t103 = t102 * t108 * 6.0 - t108 * t108 * t102 * 6.0;
  } else {
    t103 = 0.0;
  }

  if (M_idx_14 != 0) {
    t108 = 0.0;
  } else {
    t102 = (6.9 / (t111 == 0.0 ? 1.0E-16 : t111) * 999999.99999999988 + pmf_pow
            (DP_R[7ULL] / 3.7, 1.11)) * 2.3025850929940459;
    t52 = pmf_log10(6.9 / (t111 == 0.0 ? 1.0E-16 : t111) * 999999.99999999988 +
                    pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t111 ==
      0.0 ? 1.0E-16 : t111) * 999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7,
      1.11)) * pmf_log10(6.9 / (t111 == 0.0 ? 1.0E-16 : t111) *
                         999999.99999999988 + pmf_pow(DP_R[7ULL] / 3.7, 1.11)) *
      pmf_log10(6.9 / (t111 == 0.0 ? 1.0E-16 : t111) * 999999.99999999988 +
                pmf_pow(DP_R[7ULL] / 3.7, 1.11)) * 10.497600000000002;
    U_idx_0 = t111 * t111;
    t108 = -1.0 / (t52 == 0.0 ? 1.0E-16 : t52) * (-6.9 / (U_idx_0 == 0.0 ?
      1.0E-16 : U_idx_0)) * (1.0 / (t102 == 0.0 ? 1.0E-16 : t102)) * pmf_log10
      (6.9 / (t111 == 0.0 ? 1.0E-16 : t111) * 999999.99999999988 + pmf_pow(DP_R
        [7ULL] / 3.7, 1.11)) * t101 * 6.4799999999999991E+6;
  }

  t111 = ((1.0 / (t56 == 0.0 ? 1.0E-16 : t56) * (1.0 / (DP_R[4ULL] == 0.0 ?
             1.0E-16 : DP_R[4ULL])) * X_idx_2 * DP_R[5ULL] * t108 * 498.89990855
           + t95 / (DP_R[4ULL] == 0.0 ? 1.0E-16 : DP_R[4ULL]) / (t56 == 0.0 ?
            1.0E-16 : t56) / 2.0 * 997.7998171) * X_idx_2 + t95 / (DP_R[4ULL] ==
           0.0 ? 1.0E-16 : DP_R[4ULL]) / (t56 == 0.0 ? 1.0E-16 : t56) / 2.0 *
          X_idx_2 * 997.7998171) * t42;
  if (M_idx_11 != 0) {
    t52 = t100 * 1.0000000000000001E-11;
  } else if (M_idx_12 != 0) {
    t52 = (t100 * 1.0000000000000001E-11 + (t95 / (DP_R[4ULL] == 0.0 ? 1.0E-16 :
             DP_R[4ULL]) / (t56 == 0.0 ? 1.0E-16 : t56) / 2.0 * X_idx_2 *
            X_idx_2 * t42 * 997.7998171 * 1.0000000000000002E-17 - t31 *
            1.0000000000000001E-11) * t103) + (t111 * 1.0000000000000002E-17 -
      t100 * 1.0000000000000001E-11) * t46;
  } else {
    t52 = t111 * 1.0000000000000002E-17;
  }

  t31 = t38 * 5.0000000000000013E-10;
  if (M_idx_0 != 0) {
    t42 = 0.0;
  } else if (M_idx_1 != 0) {
    t42 = t31 * t49 * 6.0 - t49 * t49 * t31 * 6.0;
  } else {
    t42 = 0.0;
  }

  if (M_idx_10 != 0) {
    t31 = 0.0;
  } else {
    t111 = (6.9 / (t40 == 0.0 ? 1.0E-16 : t40) * 999999.99999999988 + pmf_pow
            (DP_R[27ULL] / 3.7, 1.11)) * 2.3025850929940459;
    t101 = pmf_log10(6.9 / (t40 == 0.0 ? 1.0E-16 : t40) * 999999.99999999988 +
                     pmf_pow(DP_R[27ULL] / 3.7, 1.11)) * pmf_log10(6.9 / (t40 ==
      0.0 ? 1.0E-16 : t40) * 999999.99999999988 + pmf_pow(DP_R[27ULL] / 3.7,
      1.11)) * pmf_log10(6.9 / (t40 == 0.0 ? 1.0E-16 : t40) * 999999.99999999988
                         + pmf_pow(DP_R[27ULL] / 3.7, 1.11)) * pmf_log10(6.9 /
      (t40 == 0.0 ? 1.0E-16 : t40) * 999999.99999999988 + pmf_pow(DP_R[27ULL] /
      3.7, 1.11)) * 10.497600000000002;
    t102 = t40 * t40;
    t31 = -1.0 / (t101 == 0.0 ? 1.0E-16 : t101) * (-6.9 / (t102 == 0.0 ? 1.0E-16
      : t102)) * (1.0 / (t111 == 0.0 ? 1.0E-16 : t111)) * pmf_log10(6.9 / (t40 ==
      0.0 ? 1.0E-16 : t40) * 999999.99999999988 + pmf_pow(DP_R[27ULL] / 3.7,
      1.11)) * t38 * 6.4799999999999991E+6;
  }

  t40 = ((1.0 / (t66 == 0.0 ? 1.0E-16 : t66) * (1.0 / (DP_R[1ULL] == 0.0 ?
            1.0E-16 : DP_R[1ULL])) * intermediate_der18 * DP_R[2ULL] * t31 *
          499999.99999999988 + t63 / (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) /
          (t66 == 0.0 ? 1.0E-16 : t66) / 2.0 * 0.00099779981710000024 *
          999999.99999999977) * intermediate_der18 * 1002.2050343789342 + t63 /
         (DP_R[1ULL] == 0.0 ? 1.0E-16 : DP_R[1ULL]) / (t66 == 0.0 ? 1.0E-16 :
          t66) / 2.0 * intermediate_der18 * 0.00099779981710000024 *
         1.002205034378934E+9) * t37;
  if (M_idx_0 != 0) {
    intermediate_der18 = t30 * 1.0000000000000001E-11;
  } else if (M_idx_1 != 0) {
    intermediate_der18 = (t30 * 1.0000000000000001E-11 + (t63 / (DP_R[1ULL] ==
      0.0 ? 1.0E-16 : DP_R[1ULL]) / (t66 == 0.0 ? 1.0E-16 : t66) / 2.0 *
      intermediate_der18 * intermediate_der18 * t37 * 1.002205034378934E+9 *
      1.0000000000000002E-17 - t36 * 1.0000000000000001E-11) * t42) + (t40 *
      1.0000000000000002E-17 - t30 * 1.0000000000000001E-11) * t34;
  } else {
    intermediate_der18 = t40 * 1.0000000000000002E-17;
  }

  for (t13 = 0ULL; t13 < 8ULL; t13++) {
    t3[t13] = DP_R[t13 + 11ULL];
  }

  t7[0ULL] = t28 * X_idx_2;
  t13 = 8ULL;
  tlu2_linear_linear_prelookup((void *)&efOut.mField0, (void *)&efOut.mField1,
    (void *)&efOut.mField2, (void *)t3, (void *)t7, (void *)&t13);
  for (t13 = 0ULL; t13 < 8ULL; t13++) {
    t3[t13] = DP_R[t13 + 19ULL];
  }

  t13 = 8ULL;
  tlu2_1d_linear_linear_derivatives((void *)&b_efOut, (void *)efOut.mField0,
    (void *)efOut.mField1, (void *)efOut.mField2, (void *)t3, (void *)&t13);
  out.mX[0] = 1.0;
  out.mX[1] = -1.0;
  out.mX[2] = 1.0;
  out.mX[3] = 1.0;
  out.mX[4] = -t52;
  out.mX[5] = -(b_efOut[0] * t28 * t33);
  out.mX[6] = -intermediate_der18;
  (void)sys;
  (void)t115;
  return 0;
}
