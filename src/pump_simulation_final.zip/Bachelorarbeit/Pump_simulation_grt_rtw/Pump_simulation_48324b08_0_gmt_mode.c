/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "Pump_simulation_48324b08_0_gmt_mode.h"
#include "Pump_simulation_48324b08_0_gmt_sys_struct.h"
#include "Pump_simulation_48324b08_0_gmt_externals.h"
#include "Pump_simulation_48324b08_0_gmt_external_struct.h"
#include "ssc_ml_fun.h"

int32_T Pump_simulation_48324b08_0_gmt_mode(const GlobalMethodTable *sys, const
  NeDynamicSystemInput *t1, GmtMethodOutput *t2)
{
  PmIntVector out;
  real_T intrm_sf_mf_24;
  real_T U_idx_0;
  real_T DP_R_idx_49;
  real_T DP_R_idx_50;
  real_T DP_R_idx_51;
  U_idx_0 = t1->mU.mX[0];
  DP_R_idx_49 = t1->mDP_R.mX[49];
  DP_R_idx_50 = t1->mDP_R.mX[50];
  DP_R_idx_51 = t1->mDP_R.mX[51];
  out = t2->mMODE;
  if (U_idx_0 >= 0.0) {
    intrm_sf_mf_24 = pmf_sqrt(U_idx_0 * U_idx_0 + DP_R_idx_49 * DP_R_idx_49);
  } else {
    intrm_sf_mf_24 = -pmf_sqrt(U_idx_0 * U_idx_0 + DP_R_idx_49 * DP_R_idx_49);
  }

  out.mX[0] = (int32_T)((!(U_idx_0 >= 0.0)) || (U_idx_0 * U_idx_0 + DP_R_idx_49 *
    DP_R_idx_49 >= 0.0));
  out.mX[1] = (int32_T)((U_idx_0 >= 0.0) || (U_idx_0 * U_idx_0 + DP_R_idx_49 *
    DP_R_idx_49 >= 0.0));
  out.mX[2] = (int32_T)(intrm_sf_mf_24 != 0.0);
  out.mX[3] = (int32_T)((!(DP_R_idx_50 * 0.10471975511965977 != 0.0)) ||
                        (DP_R_idx_51 != 0.0));
  out.mX[4] = (int32_T)(DP_R_idx_50 * DP_R_idx_50 * DP_R_idx_50 *
                        0.001148380617788882 != 0.0);
  out.mX[5] = (int32_T)(U_idx_0 >= 0.0);
  out.mX[6] = (int32_T)((!(DP_R_idx_50 * DP_R_idx_50 * DP_R_idx_50 *
    0.001148380617788882 != 0.0)) || (DP_R_idx_51 != 0.0));
  (void)sys;
  (void)t2;
  return 0;
}
