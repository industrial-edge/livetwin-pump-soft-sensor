/* Simscape target specific file.
 * This file is generated for the Simscape network associated with the solver block 'Pump_simulation/Solver Configuration'.
 */

#include "nesl_rtw_swl.h"
#include "ssc_ml_fun.h"
#include "Pump_simulation_48324b08_0_dc_external_struct.h"
#include "Pump_simulation_48324b08_0_dc_externals.h"

static int32_T dc_m_p(const DifferentialClump *ds, const NeDynamicSystemInput
                      *in, DcMethodOutput *out);
static int32_T dc_m(const DifferentialClump *ds, const NeDynamicSystemInput *in,
                    DcMethodOutput *out);
static int32_T dc_f(const DifferentialClump *ds, const NeDynamicSystemInput *in,
                    DcMethodOutput *out);
DifferentialClump *Pump_simulation_48324b08_0_dc(PmAllocator *allocator)
{
  static PmIntVector state_indices = { 0U, NULL };

  static PmIntVector m_ref_indices = { 0U, NULL };

  static PmIntVector q_ref_indices = { 0U, NULL };

  static DifferentialClump dc;
  (void) allocator;
  dc.mMethods[DC_METHOD_M_P] = dc_m_p;
  dc.mMethods[DC_METHOD_M] = dc_m;
  dc.mMethods[DC_METHOD_F] = dc_f;
  dc.mMNnz = 0U;
  dc.mStateIndices = &state_indices;
  dc.mMRefIndices = &m_ref_indices;
  dc.mQRefIndices = &q_ref_indices;
  dc.mModeCardinality = SWL_FINITE;
  return &dc;
}

static int32_T dc_f (const DifferentialClump *sys, const NeDynamicSystemInput
                     *t1, DcMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T dc_m (const DifferentialClump *sys, const NeDynamicSystemInput
                     *t1, DcMethodOutput *t2)
{
  (void)t1;
  (void)sys;
  (void)t2;
  return 0;
}

static int32_T dc_m_p (const DifferentialClump *sys, const NeDynamicSystemInput *
  t1, DcMethodOutput *t2)
{
  PmSparsityPattern out;
  (void)t1;
  out = t2->mM_P;
  out.mNumCol = 0ULL;
  out.mNumRow = 0ULL;
  out.mJc[0] = 0;
  (void)sys;
  (void)t2;
  return 0;
}
