#include "pm_std.h"
struct ssc_sli_kesYKdRukKtCYLfoQ0YRJ5{struct{char const*
ssc_sli_V7qkys9O80ShjaUIHbAAei;}ssc_sli_kPcTn2ohlNOm_1o8g8PPHq;struct{char
const*ssc_sli_VzaQ5Qbex9hMb9_Q_2EG0u;char const*ssc_sli__zJUBcxUbYh8cXXGBoVSdx
;char const*ssc_sli_VNbGJOTUV8SIVix4BdFITg;char const*
ssc_sli_F_m9IcERGhObcmspvM5anC;}ssc_sli_FJXsp6glr_t7_DiMnYF_8o;};extern struct
ssc_sli_kesYKdRukKtCYLfoQ0YRJ5 ssc_sli_FsCaFbZcmoGug9Rufaefht;struct
ssc_sli_kesYKdRukKtCYLfoQ0YRJ5 ssc_sli_FsCaFbZcmoGug9Rufaefht={{
"Linearization is not supported in local solver mode. Use results with caution."
,},{
"Partitioning local solver failed to advance at time %ss. Use a different local solver or turn the local solver option off."
,
"Partitioning local solver failed to compute initial conditions. Use a different local solver or turn the local solver option off."
,
"Simscape succeeded in finding consistent states with which to start the simulation, but the states found may deviate from requested initial conditions."
,"Insufficient partitioning memory budget.",},};
