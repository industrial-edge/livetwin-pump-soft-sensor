#ifndef __ne_initer_dae_h__
#define __ne_initer_dae_h__
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
SscIniter*sec_create_initer(NeDae*dae,boolean_T isFreqTime);
#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* __ne_initer_dae_h__ */
