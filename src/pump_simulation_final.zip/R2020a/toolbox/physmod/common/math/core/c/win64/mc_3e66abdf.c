#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "limits.h"
#include "math.h"
#include "stdio.h"
typedef struct mc_kJu3kbp1UqpibDtb06hKK_{int32_T mc_FIxFweA3fcKFfuFXAKfA47;
int32_T mc_VLHhnPUiNQpve5VIL9P3O9;int32_T n;int32_T*pm__lqjegyKuwStj56WZLiC_e;
int32_T*mc_kwrB3ZoKf7OufTHWaHJV7a;double*x;int32_T mc___ECRgjqShlp_PytRplerL;}
mc_F5Olyc6xUoG7ZyDq78exBD;mc_F5Olyc6xUoG7ZyDq78exBD*mc_F_KsXRscHI0GbqNNEbk0p9(
const mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0,double mc_kcda_aHAM4WIXuM_xBDdLt,double
mc_kCPCzQ_4FF88XTgtMjWqKy);int32_T mc_FRcDfQc8skGuVLZfeGfRsQ(int32_T
mc_FruBC65sPgSaZ5e_Y8cbTC,const mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kPZtfcLRq8hvd17AwbGSfy(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK);int32_T
mc_VufLWRyy__x0aHcAK11u_9(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VMB1wjlajc42dihJmzkfVL(mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK,
int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double x);
int32_T mc_kyNdNb1Od1pmc5h9_bRwz3(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
double*x,double*mc_FzyLWRgau0pMYq2XSI3ETL);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kKDpTzN8jw8R_La01FPHqo(FILE*mc_Fe6copTTRcKEayCm87ABO_);int32_T
mc_FBcYs04mnxCNjei3Py1gDA(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b,double mc_FfDTppU8N_tOWuLK37x_08);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_F1T9nfE5YBd9_eUgmYQiFQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0);double mc__mMjuh4GBSd2gPZyGSIEB7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc__Wuhz03is3hpg54E4_8dDo(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kPdbGJs0Eb_x_Hxa5hZJEc);int32_T
mc_kjcu6drPCUOjbP4z73xob_(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kzs_RE98zypjVHi58lxG6O(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);void*mc_VInfIQCul4ShdLlbU4F0WB(int32_T n,size_t size
);void*mc__Mim_3QMMSxfi9M5sbbxcM(void*pm__lqjegyKuwStj56WZLiC_e);void*
mc_k0mbD5QrRepqjLd_9sSyDz(void*pm__lqjegyKuwStj56WZLiC_e,int32_T n,size_t size
,int32_T*mc__suOgr_4PeCIZi_uhoSVwf);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_VFJZ9bgvffCPg9PZXPkAVk(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n,int32_T
mc_FIxFweA3fcKFfuFXAKfA47,int32_T mc_kVkvrfpzuVduaPTr5FLF8K,int32_T
mc_Vk3BcXZzVaxpfi0XcV5sHr);mc_F5Olyc6xUoG7ZyDq78exBD*mc__BJ1NEDJTgOMhaJKDrM6pN
(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc_VptvBjskDA83heaLThR8oY(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_FIxFweA3fcKFfuFXAKfA47);void*
mc_ktrY1jmEuvhTfeGflVz93o(int32_T n,size_t size);int32_T
mc_Vw_wVSv6gGKFY1Dalcu6zm(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kPdbGJs0Eb_x_Hxa5hZJEc);typedef struct mc__adJqrskeJhDYmBVMGWunh{int32_T*
mc_FjDIs2zMLtx5We_IND4g6I;int32_T*mc__AExROh1PVWNeP7hmMWuJv;int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp;int32_T*mc_FXT4jPWj6stSWaiL5dan3b;int32_T*
mc_F_jeaQAcXwGbVXb0t9dFxz;int32_T mc_k3zUxpU0ydGajPq7EF4qn3;double
mc_ViTJrDHWLs8OjimuuiIsPe;double mc__GPciDcZ6Z0EViGxgxdf9y;}
mc_VWUvciwDK_dziLpafRxush;typedef struct mc_kp2eGzAtU2WUXP2RD6EKGO{
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo;mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn;int32_T*mc_FjDIs2zMLtx5We_IND4g6I;double*
mc_Vqiy96WqvuhCaXm5e_vvT0;}mc_kPBB5xuFz74_aaM4N6U4Jv;typedef struct
mc__goErATdCI0HWaZaNs9Xzt{int32_T*pm__lqjegyKuwStj56WZLiC_e;int32_T*
mc__AExROh1PVWNeP7hmMWuJv;int32_T*mc_kUQBO1dSP8_IVqRAUx4R8G;int32_T*
mc_FQferGZUKft3_i5GvYy4Oy;int32_T mc_kLMRRiSdJr4aaLEtYiWmgE;int32_T
mc__ys6fNnaK541fDBqN87Aa_[5];int32_T mc_Fet2g81LNVG6_mJHNhUAfo[5];}
mc_koBw_auTeOpFWTLu_1_hd3;int32_T*mc_FAnXK3hkeY_FimobZpSWy4(int32_T
mc_FruBC65sPgSaZ5e_Y8cbTC,const mc_F5Olyc6xUoG7ZyDq78exBD*A);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc_kF0bdRSgaVCZhHmbCIFdvh(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_koBw_auTeOpFWTLu_1_hd3*mc__JYcNbbJ8GxnaT0gipcMUY
(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_k6QxQSbjWyGhcXikh7jTLf);int32_T
mc_FEBJlPSzZh_ZiqgXtpZSYe(mc_F5Olyc6xUoG7ZyDq78exBD*A,double
mc_FfDTppU8N_tOWuLK37x_08);int32_T mc_VywKLPGT27tscy1s60Ehlb(
mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc_ViJBWCuvxwlcXP5hTDAmft(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kJeUz19e49pVaDwcttsZep,int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a,double mc_kCPCzQ_4FF88XTgtMjWqKy,double*x);int32_T
mc_Vux1rLMHdIOwYHo_GgP0nf(const int32_T*pm__lqjegyKuwStj56WZLiC_e,const double
*b,double*x,int32_T n);int32_T mc_V3SIv4FNXnS__9UCAN4nes(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);int32_T
mc__U2f_z8iKPWQZTkLMApmoB(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc__OANyqXuH__Wi5n3l9hrJe(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT,double
mc_FfDTppU8N_tOWuLK37x_08);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VD2E_WGEctCGXH2bprw8Sw
(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT,int32_T*mc__q70gXw8N_xsWy9UoFEkTZ);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k9MmNIu2n4W9jaO59BYYYQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*pm__lqjegyKuwStj56WZLiC_e,const
int32_T*mc__AExROh1PVWNeP7hmMWuJv,int32_T mc_kVkvrfpzuVduaPTr5FLF8K);int32_T*
mc__wD389_14ZOPfyx5EQ5Eez(const int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T n);
int32_T mc_VQ7L8M0ejvGI_H70X2UUEW(const int32_T*pm__lqjegyKuwStj56WZLiC_e,
const double*b,double*x,int32_T n);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_FnFQE__lyw88fDjvIJlbiy(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_VWUvciwDK_dziLpafRxush
*mc_VHjWZG2MGPlHg9FEzWcJP5(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A);mc_VWUvciwDK_dziLpafRxush*
mc__HBpzStane0GaaQtDu_y9F(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_VWCrbzOuAe4hay4E_Unnfg);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V0SSOL16_J8_aXLgyS19I7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);int32_T mc_VLrR9_1UGwSOj5Fn6W7Qqm(
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,int32_T
mc__Gce0mZquR4HgLX8bLfI0G,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp);int32_T
mc_kX6eNI2bFZ__cyLxZQzP6Z(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);int32_T mc_FRCJeuT32S4AW5Dz6aeK7v(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);
mc_VWUvciwDK_dziLpafRxush*mc_Fe3WdhVNm1lm_TputcgM_w(mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VZ5qqYWDqx_NaqOx3T8EeD
(mc_kPBB5xuFz74_aaM4N6U4Jv*mc_F3nVSXkoDK8VeeL5OmY0_B);
mc_koBw_auTeOpFWTLu_1_hd3*mc_kqyKn15o9uW8cumoBbxjEC(mc_koBw_auTeOpFWTLu_1_hd3*
mc_kyfq6L_eQbdYcPuOovpRDW);int32_T*mc_Vq30ZRWDg0Ope1BH5Wlxn6(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,const
int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T mc_F4FqMtzrIr0Ih9YO_bpGqr);double
mc_FVvAdrNPbiK3ciVovphJqC(int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T*
mc_FFZbGh27ya8eem_J_hUtAZ,int32_T n);int32_T mc_VqGwhdpnmyGkc5egfuzI9R(int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
int32_T mc_V_3pIMGNi1pQiyeoIJloym,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,int32_T*
mc__nUrXnK_PlSWXDXfav4gTu,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I);int32_T
mc__PAs7jPQB3p6jamHMS77BU(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_V2__YrimeI4E_yWnhKofpy,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,int32_T*
mc_FQferGZUKft3_i5GvYy4Oy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf);int32_T*
mc_kvTl6JgGLlpghLCj7SJ8Zb(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_F4FqMtzrIr0Ih9YO_bpGqr);int32_T mc__78cLFJw_ySFbTb4k127zA(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T(*mc__afZS_O3BMKpbuqov2Sqn2)(int32_T,
int32_T,double,void*),void*pm__sjTRWOMR4WzZisVeB2fYm);double
mc_FCxXZX7qax4Cf1qhlQMJ_K(double*x,double*mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T n)
;int32_T mc_VjKkbv4A0k47XifnshEiFz(int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,const int32_T*mc__gfup5UQrKdtaLq0JwxBv8,int32_T*
mc_F_OdG3IuH0OSgXl2PAC3Wt,int32_T*mc_FYLTf08Tnt0_hXkhRr2i3V,int32_T*
mc_FaaXUqBjXi_Cc58Cr7D5Pw,int32_T*mc_kCfp_4sWHvtwdmGWqI8AP3);int32_T*
mc__KcZrPHSqmd_Winpkn_zbn(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_k6QxQSbjWyGhcXikh7jTLf);int32_T*mc_VSXwwVMHmJpqfu39VY7afd(const int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp,int32_T n);int32_T*mc_kkUWSotb_oO3YDxqYUxvcp(int32_T
n,int32_T mc_k6QxQSbjWyGhcXikh7jTLf);int32_T mc_VJp2YHG9mB_gfHKfpAYT7q(
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,const int32_T*
mc_FjDIs2zMLtx5We_IND4g6I);int32_T mc__bZ1EHlIu8t8WL63CWhZ5j(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double
mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf,double*x,int32_T
mc__CLRBwg4eOSEiqHPYKDedF,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
int32_T mc___ECRgjqShlp_PytRplerL);mc_koBw_auTeOpFWTLu_1_hd3*
mc__17ror7eCZl9eiXoZ3px_g(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VI_gkAfbWYGleX3FfR8roq(mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
const mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,double*x,const
int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T mc___aedK39Pax6Ziebprhh0i);int32_T
mc_Fx2UoNYY4W0WY5iaMITghy(int32_T mc_kyp6uAyJE40UVuAQNEYzS1,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc_FcKez189ghKAYyDjWA9v5n,const int32_T*
mc_FTf2iFFdsgK3hewKsMgEx4,int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T*
mc_F65aUsM8ggpTgiucZs1fmm);mc_koBw_auTeOpFWTLu_1_hd3*mc_VfRC_16CnDtIYTHey4Izis
(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n);mc_koBw_auTeOpFWTLu_1_hd3*
mc_Fm6BWhHX7o4Vai4IMTAE87(mc_koBw_auTeOpFWTLu_1_hd3*mc_kyfq6L_eQbdYcPuOovpRDW,
mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,void*
mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kYUYSnR_wtpicaLJHkpwi_(mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T
mc__suOgr_4PeCIZi_uhoSVwf);int32_T*mc_Ff7NuTFKk3OCYDKMqomZ1z(int32_T*
pm__lqjegyKuwStj56WZLiC_e,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc___7vbyf5jjtDZHYPmA3rvK(mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_F3nVSXkoDK8VeeL5OmY0_B,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
#include "pm_std.h"
#include "pm_std.h"
static int32_T mc_VqW0OD8rWh_SfeqdUL9KwY(int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,
int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double mc_FKnJ9_uGmQ_yYPw_yTe4ZK,void*
mc_Vcj7C4VFRotzbatWYwoUuw){int32_T mc_V2__YrimeI4E_yWnhKofpy= *((int32_T*)
mc_Vcj7C4VFRotzbatWYwoUuw);return((mc_kwrB3ZoKf7OufTHWaHJV7a<
mc_V2__YrimeI4E_yWnhKofpy)&&(mc_kyp6uAyJE40UVuAQNEYzS1<
mc_V2__YrimeI4E_yWnhKofpy));}static void mc__IEpAUOKLxOiaazw30lc_k(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_V2__YrimeI4E_yWnhKofpy){int32_T
pm__lqjegyKuwStj56WZLiC_e;for(pm__lqjegyKuwStj56WZLiC_e=
mc_V2__YrimeI4E_yWnhKofpy;pm__lqjegyKuwStj56WZLiC_e<A->n;
pm__lqjegyKuwStj56WZLiC_e++)A->pm__lqjegyKuwStj56WZLiC_e[
pm__lqjegyKuwStj56WZLiC_e+1]=A->pm__lqjegyKuwStj56WZLiC_e[
mc_V2__YrimeI4E_yWnhKofpy];mc__78cLFJw_ySFbTb4k127zA(A,
mc_VqW0OD8rWh_SfeqdUL9KwY,&mc_V2__YrimeI4E_yWnhKofpy);A->
mc_VLHhnPUiNQpve5VIL9P3O9=mc_V2__YrimeI4E_yWnhKofpy;A->n=
mc_V2__YrimeI4E_yWnhKofpy;}mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VD2E_WGEctCGXH2bprw8Sw
(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT,int32_T*mc__q70gXw8N_xsWy9UoFEkTZ){
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,*mc_Vi4Cp0qK964NYTFMGr9Ttn
;mc_kPBB5xuFz74_aaM4N6U4Jv*mc_F3nVSXkoDK8VeeL5OmY0_B;double
mc__vHc3CO63it1hH_KVDeIvw,*mc_Vur7xPb_EopdjPeDysnmuX,*
mc_VBbMe0Due8CycHQkFwkY8J,*x,a,mc__1eAP9V6_J_NYm_1gTIm7A;int32_T*
mc_VFzsW6ct3344eDmnHqEyhX,*mc_FpvHU1Cq0wdCaPkaALZuiC,*
mc__qmvfoLZQs_xferzoNsy5J,*mc_VtnVwNiURghbe5altoWOGF,*
mc_FjDIs2zMLtx5We_IND4g6I,*mc__01SK3u3lG0GaLCTTSoVGO,*
mc__AExROh1PVWNeP7hmMWuJv,n,mc_kfwJFtVmoahLien4AjdVVp,
mc_V2__YrimeI4E_yWnhKofpy,mc_V_3pIMGNi1pQiyeoIJloym,pm__lqjegyKuwStj56WZLiC_e,
mc_kwrB3ZoKf7OufTHWaHJV7a,pm_Fr_bHKkQKFWbfi50VWd5Pw,mc_ViTJrDHWLs8OjimuuiIsPe,
mc__GPciDcZ6Z0EViGxgxdf9y;int32_T mc_VLHhnPUiNQpve5VIL9P3O9,
mc_kUQBO1dSP8_IVqRAUx4R8G,mc_FUr9DqvDGth7bDAws0mB5p;if(!(A&&(A->
mc___ECRgjqShlp_PytRplerL== -1))||!mc__Q_i1Z0_CMGpfPqpuLrnMT)return(NULL);n=A
->n;mc_VLHhnPUiNQpve5VIL9P3O9=A->mc_VLHhnPUiNQpve5VIL9P3O9;
mc_kUQBO1dSP8_IVqRAUx4R8G=((n)<(mc_VLHhnPUiNQpve5VIL9P3O9)?(n):(
mc_VLHhnPUiNQpve5VIL9P3O9));mc__AExROh1PVWNeP7hmMWuJv=
mc__Q_i1Z0_CMGpfPqpuLrnMT->mc__AExROh1PVWNeP7hmMWuJv;mc_ViTJrDHWLs8OjimuuiIsPe
=(int32_T)(mc__Q_i1Z0_CMGpfPqpuLrnMT->mc_ViTJrDHWLs8OjimuuiIsPe);
mc__GPciDcZ6Z0EViGxgxdf9y=(int32_T)(mc__Q_i1Z0_CMGpfPqpuLrnMT->
mc__GPciDcZ6Z0EViGxgxdf9y);x=mc_ktrY1jmEuvhTfeGflVz93o(
mc_VLHhnPUiNQpve5VIL9P3O9,sizeof(double));mc__01SK3u3lG0GaLCTTSoVGO=
mc_ktrY1jmEuvhTfeGflVz93o(2*mc_VLHhnPUiNQpve5VIL9P3O9,sizeof(int32_T));
mc_F3nVSXkoDK8VeeL5OmY0_B=mc_VInfIQCul4ShdLlbU4F0WB(1,sizeof(
mc_kPBB5xuFz74_aaM4N6U4Jv));if(!x||!mc__01SK3u3lG0GaLCTTSoVGO||!
mc_F3nVSXkoDK8VeeL5OmY0_B)return(mc___7vbyf5jjtDZHYPmA3rvK(
mc_F3nVSXkoDK8VeeL5OmY0_B,NULL,mc__01SK3u3lG0GaLCTTSoVGO,x,0));
mc_F3nVSXkoDK8VeeL5OmY0_B->mc__ut5UfJwzNlZ_XZC_yEgKo=mc__ut5UfJwzNlZ_XZC_yEgKo
=mc_VFJZ9bgvffCPg9PZXPkAVk(mc_VLHhnPUiNQpve5VIL9P3O9,mc_VLHhnPUiNQpve5VIL9P3O9
,mc_ViTJrDHWLs8OjimuuiIsPe,1,0);mc_F3nVSXkoDK8VeeL5OmY0_B->
mc_Vi4Cp0qK964NYTFMGr9Ttn=mc_Vi4Cp0qK964NYTFMGr9Ttn=mc_VFJZ9bgvffCPg9PZXPkAVk(
mc_VLHhnPUiNQpve5VIL9P3O9,mc_VLHhnPUiNQpve5VIL9P3O9,mc__GPciDcZ6Z0EViGxgxdf9y,
1,0);mc_F3nVSXkoDK8VeeL5OmY0_B->mc_FjDIs2zMLtx5We_IND4g6I=
mc_FjDIs2zMLtx5We_IND4g6I=mc_ktrY1jmEuvhTfeGflVz93o(mc_VLHhnPUiNQpve5VIL9P3O9,
sizeof(int32_T));if(!mc__ut5UfJwzNlZ_XZC_yEgKo||!mc_Vi4Cp0qK964NYTFMGr9Ttn||!
mc_FjDIs2zMLtx5We_IND4g6I)return(mc___7vbyf5jjtDZHYPmA3rvK(
mc_F3nVSXkoDK8VeeL5OmY0_B,NULL,mc__01SK3u3lG0GaLCTTSoVGO,x,0));
mc_VFzsW6ct3344eDmnHqEyhX=mc__ut5UfJwzNlZ_XZC_yEgKo->pm__lqjegyKuwStj56WZLiC_e
;mc__qmvfoLZQs_xferzoNsy5J=mc_Vi4Cp0qK964NYTFMGr9Ttn->
pm__lqjegyKuwStj56WZLiC_e;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a
++)x[mc_kwrB3ZoKf7OufTHWaHJV7a]=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<mc_VLHhnPUiNQpve5VIL9P3O9;mc_kwrB3ZoKf7OufTHWaHJV7a
++)mc_FjDIs2zMLtx5We_IND4g6I[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;for(
mc_V2__YrimeI4E_yWnhKofpy=0;mc_V2__YrimeI4E_yWnhKofpy<=
mc_VLHhnPUiNQpve5VIL9P3O9;mc_V2__YrimeI4E_yWnhKofpy++)
mc_VFzsW6ct3344eDmnHqEyhX[mc_V2__YrimeI4E_yWnhKofpy]=0;
mc_ViTJrDHWLs8OjimuuiIsPe=mc__GPciDcZ6Z0EViGxgxdf9y=0;
mc_V2__YrimeI4E_yWnhKofpy=0;mc_FUr9DqvDGth7bDAws0mB5p=0;while(true){if((
mc_V2__YrimeI4E_yWnhKofpy==mc_kUQBO1dSP8_IVqRAUx4R8G)||(
mc_FUr9DqvDGth7bDAws0mB5p==n)){break;}mc_VFzsW6ct3344eDmnHqEyhX[
mc_V2__YrimeI4E_yWnhKofpy]=mc_ViTJrDHWLs8OjimuuiIsPe;mc__qmvfoLZQs_xferzoNsy5J
[mc_V2__YrimeI4E_yWnhKofpy]=mc__GPciDcZ6Z0EViGxgxdf9y;if((
mc_ViTJrDHWLs8OjimuuiIsPe+mc_VLHhnPUiNQpve5VIL9P3O9>mc__ut5UfJwzNlZ_XZC_yEgKo
->mc_FIxFweA3fcKFfuFXAKfA47&&!mc_VptvBjskDA83heaLThR8oY(
mc__ut5UfJwzNlZ_XZC_yEgKo,2*mc__ut5UfJwzNlZ_XZC_yEgKo->
mc_FIxFweA3fcKFfuFXAKfA47+mc_VLHhnPUiNQpve5VIL9P3O9))||(
mc__GPciDcZ6Z0EViGxgxdf9y+mc_VLHhnPUiNQpve5VIL9P3O9>mc_Vi4Cp0qK964NYTFMGr9Ttn
->mc_FIxFweA3fcKFfuFXAKfA47&&!mc_VptvBjskDA83heaLThR8oY(
mc_Vi4Cp0qK964NYTFMGr9Ttn,2*mc_Vi4Cp0qK964NYTFMGr9Ttn->
mc_FIxFweA3fcKFfuFXAKfA47+mc_VLHhnPUiNQpve5VIL9P3O9))){return(
mc___7vbyf5jjtDZHYPmA3rvK(mc_F3nVSXkoDK8VeeL5OmY0_B,NULL,
mc__01SK3u3lG0GaLCTTSoVGO,x,0));}mc_FpvHU1Cq0wdCaPkaALZuiC=
mc__ut5UfJwzNlZ_XZC_yEgKo->mc_kwrB3ZoKf7OufTHWaHJV7a;mc_Vur7xPb_EopdjPeDysnmuX
=mc__ut5UfJwzNlZ_XZC_yEgKo->x;mc_VtnVwNiURghbe5altoWOGF=
mc_Vi4Cp0qK964NYTFMGr9Ttn->mc_kwrB3ZoKf7OufTHWaHJV7a;mc_VBbMe0Due8CycHQkFwkY8J
=mc_Vi4Cp0qK964NYTFMGr9Ttn->x;(void)0;;pm_Fr_bHKkQKFWbfi50VWd5Pw=
mc__AExROh1PVWNeP7hmMWuJv[mc_FUr9DqvDGth7bDAws0mB5p];mc_V_3pIMGNi1pQiyeoIJloym
=mc_VI_gkAfbWYGleX3FfR8roq(mc__ut5UfJwzNlZ_XZC_yEgKo,A,
pm_Fr_bHKkQKFWbfi50VWd5Pw,mc__01SK3u3lG0GaLCTTSoVGO,x,
mc_FjDIs2zMLtx5We_IND4g6I,1);a=0.0;for(pm__lqjegyKuwStj56WZLiC_e=
mc_V_3pIMGNi1pQiyeoIJloym;pm__lqjegyKuwStj56WZLiC_e<mc_VLHhnPUiNQpve5VIL9P3O9;
pm__lqjegyKuwStj56WZLiC_e++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__01SK3u3lG0GaLCTTSoVGO[pm__lqjegyKuwStj56WZLiC_e];if(
mc_FjDIs2zMLtx5We_IND4g6I[mc_kwrB3ZoKf7OufTHWaHJV7a]<0){a=x[
mc_kwrB3ZoKf7OufTHWaHJV7a];if(fabs(a)>0.0)break;}}if(fabs(a)>0.0){if(
mc_V2__YrimeI4E_yWnhKofpy!=mc_FUr9DqvDGth7bDAws0mB5p){
mc__AExROh1PVWNeP7hmMWuJv[mc_FUr9DqvDGth7bDAws0mB5p]=mc__AExROh1PVWNeP7hmMWuJv
[mc_V2__YrimeI4E_yWnhKofpy];mc__AExROh1PVWNeP7hmMWuJv[
mc_V2__YrimeI4E_yWnhKofpy]=pm_Fr_bHKkQKFWbfi50VWd5Pw;}}else{
mc_FUr9DqvDGth7bDAws0mB5p++;continue;}mc_kfwJFtVmoahLien4AjdVVp= -1;a= -1;for(
pm__lqjegyKuwStj56WZLiC_e=mc_V_3pIMGNi1pQiyeoIJloym;pm__lqjegyKuwStj56WZLiC_e<
mc_VLHhnPUiNQpve5VIL9P3O9;pm__lqjegyKuwStj56WZLiC_e++){
mc_kwrB3ZoKf7OufTHWaHJV7a=mc__01SK3u3lG0GaLCTTSoVGO[pm__lqjegyKuwStj56WZLiC_e]
;if(mc_FjDIs2zMLtx5We_IND4g6I[mc_kwrB3ZoKf7OufTHWaHJV7a]<0){if((
mc__1eAP9V6_J_NYm_1gTIm7A=fabs(x[mc_kwrB3ZoKf7OufTHWaHJV7a]))>a){a=
mc__1eAP9V6_J_NYm_1gTIm7A;mc_kfwJFtVmoahLien4AjdVVp=mc_kwrB3ZoKf7OufTHWaHJV7a;
}}else{mc_VtnVwNiURghbe5altoWOGF[mc__GPciDcZ6Z0EViGxgxdf9y]=
mc_FjDIs2zMLtx5We_IND4g6I[mc_kwrB3ZoKf7OufTHWaHJV7a];mc_VBbMe0Due8CycHQkFwkY8J
[mc__GPciDcZ6Z0EViGxgxdf9y++]=x[mc_kwrB3ZoKf7OufTHWaHJV7a];}}
mc__vHc3CO63it1hH_KVDeIvw=x[mc_kfwJFtVmoahLien4AjdVVp];
mc_VtnVwNiURghbe5altoWOGF[mc__GPciDcZ6Z0EViGxgxdf9y]=mc_V2__YrimeI4E_yWnhKofpy
;mc_VBbMe0Due8CycHQkFwkY8J[mc__GPciDcZ6Z0EViGxgxdf9y++]=
mc__vHc3CO63it1hH_KVDeIvw;mc_FjDIs2zMLtx5We_IND4g6I[mc_kfwJFtVmoahLien4AjdVVp]
=mc_V2__YrimeI4E_yWnhKofpy;mc_FpvHU1Cq0wdCaPkaALZuiC[mc_ViTJrDHWLs8OjimuuiIsPe
]=mc_kfwJFtVmoahLien4AjdVVp;mc_Vur7xPb_EopdjPeDysnmuX[
mc_ViTJrDHWLs8OjimuuiIsPe++]=1;for(pm__lqjegyKuwStj56WZLiC_e=
mc_V_3pIMGNi1pQiyeoIJloym;pm__lqjegyKuwStj56WZLiC_e<mc_VLHhnPUiNQpve5VIL9P3O9;
pm__lqjegyKuwStj56WZLiC_e++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc__01SK3u3lG0GaLCTTSoVGO[pm__lqjegyKuwStj56WZLiC_e];if(
mc_FjDIs2zMLtx5We_IND4g6I[mc_kwrB3ZoKf7OufTHWaHJV7a]<0){
mc_FpvHU1Cq0wdCaPkaALZuiC[mc_ViTJrDHWLs8OjimuuiIsPe]=mc_kwrB3ZoKf7OufTHWaHJV7a
;mc_Vur7xPb_EopdjPeDysnmuX[mc_ViTJrDHWLs8OjimuuiIsPe++]=x[
mc_kwrB3ZoKf7OufTHWaHJV7a]/mc__vHc3CO63it1hH_KVDeIvw;}x[
mc_kwrB3ZoKf7OufTHWaHJV7a]=0;}mc_V2__YrimeI4E_yWnhKofpy++;
mc_FUr9DqvDGth7bDAws0mB5p++;}mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_V2__YrimeI4E_yWnhKofpy;for(pm__lqjegyKuwStj56WZLiC_e=0;
pm__lqjegyKuwStj56WZLiC_e<mc_VLHhnPUiNQpve5VIL9P3O9;pm__lqjegyKuwStj56WZLiC_e
++){if(mc_FjDIs2zMLtx5We_IND4g6I[pm__lqjegyKuwStj56WZLiC_e]== -1){
mc_FjDIs2zMLtx5We_IND4g6I[pm__lqjegyKuwStj56WZLiC_e]=mc_kwrB3ZoKf7OufTHWaHJV7a
++;}}*mc__q70gXw8N_xsWy9UoFEkTZ=mc_V2__YrimeI4E_yWnhKofpy;
mc_VFzsW6ct3344eDmnHqEyhX[mc_V2__YrimeI4E_yWnhKofpy]=mc_ViTJrDHWLs8OjimuuiIsPe
;mc__qmvfoLZQs_xferzoNsy5J[mc_V2__YrimeI4E_yWnhKofpy]=
mc__GPciDcZ6Z0EViGxgxdf9y;mc_FpvHU1Cq0wdCaPkaALZuiC=mc__ut5UfJwzNlZ_XZC_yEgKo
->mc_kwrB3ZoKf7OufTHWaHJV7a;for(pm__lqjegyKuwStj56WZLiC_e=0;
pm__lqjegyKuwStj56WZLiC_e<mc_ViTJrDHWLs8OjimuuiIsPe;pm__lqjegyKuwStj56WZLiC_e
++)mc_FpvHU1Cq0wdCaPkaALZuiC[pm__lqjegyKuwStj56WZLiC_e]=
mc_FjDIs2zMLtx5We_IND4g6I[mc_FpvHU1Cq0wdCaPkaALZuiC[pm__lqjegyKuwStj56WZLiC_e]
];mc__IEpAUOKLxOiaazw30lc_k(mc__ut5UfJwzNlZ_XZC_yEgKo,
mc_V2__YrimeI4E_yWnhKofpy);mc__IEpAUOKLxOiaazw30lc_k(mc_Vi4Cp0qK964NYTFMGr9Ttn
,mc_V2__YrimeI4E_yWnhKofpy);return(mc___7vbyf5jjtDZHYPmA3rvK(
mc_F3nVSXkoDK8VeeL5OmY0_B,NULL,mc__01SK3u3lG0GaLCTTSoVGO,x,1));}
