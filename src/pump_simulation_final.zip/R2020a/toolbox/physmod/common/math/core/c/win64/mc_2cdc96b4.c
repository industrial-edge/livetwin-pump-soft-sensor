#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
#include "limits.h"
#include "math.h"
#include "stdio.h"
typedef struct mc_kJu3kbp1UqpibDtb06hKK_{int32_T mc_FIxFweA3fcKFfuFXAKfA47;
int32_T mc_VLHhnPUiNQpve5VIL9P3O9;int32_T n;int32_T*pm__lqjegyKuwStj56WZLiC_e;
int32_T*mc_kwrB3ZoKf7OufTHWaHJV7a;double*x;int32_T mc___ECRgjqShlp_PytRplerL;}
mc_F5Olyc6xUoG7ZyDq78exBD;mc_F5Olyc6xUoG7ZyDq78exBD*mc_F_KsXRscHI0GbqNNEbk0p9(
const mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0,double mc_kcda_aHAM4WIXuM_xBDdLt,double
mc_kCPCzQ_4FF88XTgtMjWqKy);int32_T mc_FRcDfQc8skGuVLZfeGfRsQ(int32_T
mc_FruBC65sPgSaZ5e_Y8cbTC,const mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kPZtfcLRq8hvd17AwbGSfy(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK);int32_T
mc_VufLWRyy__x0aHcAK11u_9(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VMB1wjlajc42dihJmzkfVL(mc_F5Olyc6xUoG7ZyDq78exBD*mc_V91rYIvDBkGRba7MvGcPUK,
int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double x);
int32_T mc_kyNdNb1Od1pmc5h9_bRwz3(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
double*x,double*mc_FzyLWRgau0pMYq2XSI3ETL);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kKDpTzN8jw8R_La01FPHqo(FILE*mc_Fe6copTTRcKEayCm87ABO_);int32_T
mc_FBcYs04mnxCNjei3Py1gDA(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b,double mc_FfDTppU8N_tOWuLK37x_08);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_F1T9nfE5YBd9_eUgmYQiFQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vqiy96WqvuhCaXm5e_vvT0);double mc__mMjuh4GBSd2gPZyGSIEB7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc__Wuhz03is3hpg54E4_8dDo(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kPdbGJs0Eb_x_Hxa5hZJEc);int32_T
mc_kjcu6drPCUOjbP4z73xob_(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,double*b);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_kzs_RE98zypjVHi58lxG6O(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);void*mc_VInfIQCul4ShdLlbU4F0WB(int32_T n,size_t size
);void*mc__Mim_3QMMSxfi9M5sbbxcM(void*pm__lqjegyKuwStj56WZLiC_e);void*
mc_k0mbD5QrRepqjLd_9sSyDz(void*pm__lqjegyKuwStj56WZLiC_e,int32_T n,size_t size
,int32_T*mc__suOgr_4PeCIZi_uhoSVwf);mc_F5Olyc6xUoG7ZyDq78exBD*
mc_VFJZ9bgvffCPg9PZXPkAVk(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n,int32_T
mc_FIxFweA3fcKFfuFXAKfA47,int32_T mc_kVkvrfpzuVduaPTr5FLF8K,int32_T
mc_Vk3BcXZzVaxpfi0XcV5sHr);mc_F5Olyc6xUoG7ZyDq78exBD*mc__BJ1NEDJTgOMhaJKDrM6pN
(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc_VptvBjskDA83heaLThR8oY(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_FIxFweA3fcKFfuFXAKfA47);void*
mc_ktrY1jmEuvhTfeGflVz93o(int32_T n,size_t size);int32_T
mc_Vw_wVSv6gGKFY1Dalcu6zm(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_kPdbGJs0Eb_x_Hxa5hZJEc);typedef struct mc__adJqrskeJhDYmBVMGWunh{int32_T*
mc_FjDIs2zMLtx5We_IND4g6I;int32_T*mc__AExROh1PVWNeP7hmMWuJv;int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp;int32_T*mc_FXT4jPWj6stSWaiL5dan3b;int32_T*
mc_F_jeaQAcXwGbVXb0t9dFxz;int32_T mc_k3zUxpU0ydGajPq7EF4qn3;double
mc_ViTJrDHWLs8OjimuuiIsPe;double mc__GPciDcZ6Z0EViGxgxdf9y;}
mc_VWUvciwDK_dziLpafRxush;typedef struct mc_kp2eGzAtU2WUXP2RD6EKGO{
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo;mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn;int32_T*mc_FjDIs2zMLtx5We_IND4g6I;double*
mc_Vqiy96WqvuhCaXm5e_vvT0;}mc_kPBB5xuFz74_aaM4N6U4Jv;typedef struct
mc__goErATdCI0HWaZaNs9Xzt{int32_T*pm__lqjegyKuwStj56WZLiC_e;int32_T*
mc__AExROh1PVWNeP7hmMWuJv;int32_T*mc_kUQBO1dSP8_IVqRAUx4R8G;int32_T*
mc_FQferGZUKft3_i5GvYy4Oy;int32_T mc_kLMRRiSdJr4aaLEtYiWmgE;int32_T
mc__ys6fNnaK541fDBqN87Aa_[5];int32_T mc_Fet2g81LNVG6_mJHNhUAfo[5];}
mc_koBw_auTeOpFWTLu_1_hd3;int32_T*mc_FAnXK3hkeY_FimobZpSWy4(int32_T
mc_FruBC65sPgSaZ5e_Y8cbTC,const mc_F5Olyc6xUoG7ZyDq78exBD*A);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc_kF0bdRSgaVCZhHmbCIFdvh(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_koBw_auTeOpFWTLu_1_hd3*mc__JYcNbbJ8GxnaT0gipcMUY
(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_k6QxQSbjWyGhcXikh7jTLf);int32_T
mc_FEBJlPSzZh_ZiqgXtpZSYe(mc_F5Olyc6xUoG7ZyDq78exBD*A,double
mc_FfDTppU8N_tOWuLK37x_08);int32_T mc_VywKLPGT27tscy1s60Ehlb(
mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T mc_ViJBWCuvxwlcXP5hTDAmft(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kJeUz19e49pVaDwcttsZep,int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a,double mc_kCPCzQ_4FF88XTgtMjWqKy,double*x);int32_T
mc_Vux1rLMHdIOwYHo_GgP0nf(const int32_T*pm__lqjegyKuwStj56WZLiC_e,const double
*b,double*x,int32_T n);int32_T mc_V3SIv4FNXnS__9UCAN4nes(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);int32_T
mc__U2f_z8iKPWQZTkLMApmoB(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc__ut5UfJwzNlZ_XZC_yEgKo,double*x);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc__OANyqXuH__Wi5n3l9hrJe(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT,double
mc_FfDTppU8N_tOWuLK37x_08);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VD2E_WGEctCGXH2bprw8Sw
(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT,int32_T*mc__q70gXw8N_xsWy9UoFEkTZ);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k9MmNIu2n4W9jaO59BYYYQ(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*pm__lqjegyKuwStj56WZLiC_e,const
int32_T*mc__AExROh1PVWNeP7hmMWuJv,int32_T mc_kVkvrfpzuVduaPTr5FLF8K);int32_T*
mc__wD389_14ZOPfyx5EQ5Eez(const int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T n);
int32_T mc_VQ7L8M0ejvGI_H70X2UUEW(const int32_T*pm__lqjegyKuwStj56WZLiC_e,
const double*b,double*x,int32_T n);mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_FnFQE__lyw88fDjvIJlbiy(const mc_F5Olyc6xUoG7ZyDq78exBD*A,const
mc_VWUvciwDK_dziLpafRxush*mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_VWUvciwDK_dziLpafRxush
*mc_VHjWZG2MGPlHg9FEzWcJP5(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A);mc_VWUvciwDK_dziLpafRxush*
mc__HBpzStane0GaaQtDu_y9F(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_VWCrbzOuAe4hay4E_Unnfg);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_V0SSOL16_J8_aXLgyS19I7(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T
mc_kVkvrfpzuVduaPTr5FLF8K);int32_T mc_VLrR9_1UGwSOj5Fn6W7Qqm(
mc_F5Olyc6xUoG7ZyDq78exBD*mc__ut5UfJwzNlZ_XZC_yEgKo,int32_T
mc__Gce0mZquR4HgLX8bLfI0G,const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp);int32_T
mc_kX6eNI2bFZ__cyLxZQzP6Z(const mc_F5Olyc6xUoG7ZyDq78exBD*
mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);int32_T mc_FRCJeuT32S4AW5Dz6aeK7v(const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vi4Cp0qK964NYTFMGr9Ttn,double*x);
mc_VWUvciwDK_dziLpafRxush*mc_Fe3WdhVNm1lm_TputcgM_w(mc_VWUvciwDK_dziLpafRxush*
mc__Q_i1Z0_CMGpfPqpuLrnMT);mc_kPBB5xuFz74_aaM4N6U4Jv*mc_VZ5qqYWDqx_NaqOx3T8EeD
(mc_kPBB5xuFz74_aaM4N6U4Jv*mc_F3nVSXkoDK8VeeL5OmY0_B);
mc_koBw_auTeOpFWTLu_1_hd3*mc_kqyKn15o9uW8cumoBbxjEC(mc_koBw_auTeOpFWTLu_1_hd3*
mc_kyfq6L_eQbdYcPuOovpRDW);int32_T*mc_Vq30ZRWDg0Ope1BH5Wlxn6(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,const
int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T mc_F4FqMtzrIr0Ih9YO_bpGqr);double
mc_FVvAdrNPbiK3ciVovphJqC(int32_T*pm__lqjegyKuwStj56WZLiC_e,int32_T*
mc_FFZbGh27ya8eem_J_hUtAZ,int32_T n);int32_T mc_VqGwhdpnmyGkc5egfuzI9R(int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
int32_T mc_V_3pIMGNi1pQiyeoIJloym,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,int32_T*
mc__nUrXnK_PlSWXDXfav4gTu,const int32_T*mc_FjDIs2zMLtx5We_IND4g6I);int32_T
mc__PAs7jPQB3p6jamHMS77BU(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_V2__YrimeI4E_yWnhKofpy,const int32_T*mc_k6HeriBJpGdZiPlDO4UZXp,int32_T*
mc_FQferGZUKft3_i5GvYy4Oy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf);int32_T*
mc_kvTl6JgGLlpghLCj7SJ8Zb(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_F4FqMtzrIr0Ih9YO_bpGqr);int32_T mc__78cLFJw_ySFbTb4k127zA(
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T(*mc__afZS_O3BMKpbuqov2Sqn2)(int32_T,
int32_T,double,void*),void*pm__sjTRWOMR4WzZisVeB2fYm);double
mc_FCxXZX7qax4Cf1qhlQMJ_K(double*x,double*mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T n)
;int32_T mc_VjKkbv4A0k47XifnshEiFz(int32_T mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T
mc_kyp6uAyJE40UVuAQNEYzS1,const int32_T*mc__gfup5UQrKdtaLq0JwxBv8,int32_T*
mc_F_OdG3IuH0OSgXl2PAC3Wt,int32_T*mc_FYLTf08Tnt0_hXkhRr2i3V,int32_T*
mc_FaaXUqBjXi_Cc58Cr7D5Pw,int32_T*mc_kCfp_4sWHvtwdmGWqI8AP3);int32_T*
mc__KcZrPHSqmd_Winpkn_zbn(const mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T
mc_k6QxQSbjWyGhcXikh7jTLf);int32_T*mc_VSXwwVMHmJpqfu39VY7afd(const int32_T*
mc_k6HeriBJpGdZiPlDO4UZXp,int32_T n);int32_T*mc_kkUWSotb_oO3YDxqYUxvcp(int32_T
n,int32_T mc_k6QxQSbjWyGhcXikh7jTLf);int32_T mc_VJp2YHG9mB_gfHKfpAYT7q(
mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,const
mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,const int32_T*
mc_FjDIs2zMLtx5We_IND4g6I);int32_T mc__bZ1EHlIu8t8WL63CWhZ5j(const
mc_F5Olyc6xUoG7ZyDq78exBD*A,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double
mc_kCPCzQ_4FF88XTgtMjWqKy,int32_T*mc_V1pxxydYEnWVVi3QKesjvf,double*x,int32_T
mc__CLRBwg4eOSEiqHPYKDedF,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
int32_T mc___ECRgjqShlp_PytRplerL);mc_koBw_auTeOpFWTLu_1_hd3*
mc__17ror7eCZl9eiXoZ3px_g(mc_F5Olyc6xUoG7ZyDq78exBD*A);int32_T
mc_VI_gkAfbWYGleX3FfR8roq(mc_F5Olyc6xUoG7ZyDq78exBD*mc_k0u3N7AKLBdaj5KgM8mztL,
const mc_F5Olyc6xUoG7ZyDq78exBD*mc_Vqiy96WqvuhCaXm5e_vvT0,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc__01SK3u3lG0GaLCTTSoVGO,double*x,const
int32_T*mc_FjDIs2zMLtx5We_IND4g6I,int32_T mc___aedK39Pax6Ziebprhh0i);int32_T
mc_Fx2UoNYY4W0WY5iaMITghy(int32_T mc_kyp6uAyJE40UVuAQNEYzS1,int32_T
mc_V2__YrimeI4E_yWnhKofpy,int32_T*mc_FcKez189ghKAYyDjWA9v5n,const int32_T*
mc_FTf2iFFdsgK3hewKsMgEx4,int32_T*mc_VlzlbuXTjytugLyuufocD_,int32_T*
mc_F65aUsM8ggpTgiucZs1fmm);mc_koBw_auTeOpFWTLu_1_hd3*mc_VfRC_16CnDtIYTHey4Izis
(int32_T mc_VLHhnPUiNQpve5VIL9P3O9,int32_T n);mc_koBw_auTeOpFWTLu_1_hd3*
mc_Fm6BWhHX7o4Vai4IMTAE87(mc_koBw_auTeOpFWTLu_1_hd3*mc_kyfq6L_eQbdYcPuOovpRDW,
mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,void*
mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_F5Olyc6xUoG7ZyDq78exBD*mc_kYUYSnR_wtpicaLJHkpwi_(mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T
mc__suOgr_4PeCIZi_uhoSVwf);int32_T*mc_Ff7NuTFKk3OCYDKMqomZ1z(int32_T*
pm__lqjegyKuwStj56WZLiC_e,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
mc_kPBB5xuFz74_aaM4N6U4Jv*mc___7vbyf5jjtDZHYPmA3rvK(mc_kPBB5xuFz74_aaM4N6U4Jv*
mc_F3nVSXkoDK8VeeL5OmY0_B,mc_F5Olyc6xUoG7ZyDq78exBD*mc_FStFcQlyAJ_dVy4kGZXBPQ,
void*mc_V1pxxydYEnWVVi3QKesjvf,void*x,int32_T mc__suOgr_4PeCIZi_uhoSVwf);
size_t mc_VgM3Lx3pYgtLW13T1_txvP(const PmBoolVector*mc_VgJW5ZqpwPpuY1inYtaofQ)
;void mc_F4xMxEJX_DlUYXuaiDuSWS(const PmIntVector*mc_kyVj_uOQd__gg9_ljlZ_IY,
const PmRealVector*x,const PmRealVector*mc_FfDTppU8N_tOWuLK37x_08);void
mc_kQso3OAQDyxZaX0RF40IyE(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmIntVector*
mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_FCOSZaHMkXC6hyEys7zO54(const PmIntVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmIntVector*mc_F2Ry_cv60wK5bmHWC_sU4g);void mc_V5jydIk5QzCRZTOycShqTL(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FvLmE29WKCKJfaZMHwg3g9(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const int32_T mc_kh0AzKGHcX8tfeDoNul_TU,
const int32_T mc__Oliq0seKPWShTNRpvAarb);void mc__pmVtsSuXZls_1NfvVprZ7(const
PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const PmIntVector*
pm__YmIqNX3g5Sub1vKK1hZQF,const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH);void
mc_FR5FdJeEvDGGcyEVkxeE_x(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF,boolean_T mc_FL_3a__K44dYi9fe74WHqt);
void mc_FK6EqkTbVFGMZ5QwXcurHx(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*mc_k8AO2tT20x0_cyxVp0ak3P);void mc_FioOBDJiFMpkWaAcUdBb1E(
const PmIntVector*mc_F6RwpxHXSXp7gDlfFRloPz,int32_T mc_kg4CyRgbu6OdeewZOel7Qx)
;void mc_kB1aHs1BVHG5YHNpmLLvkW(const PmBoolVector*mc_FrF2gTbWxox8geiSROFaFn,
const PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__vpsWwfj3fx1YDJlP_lHTd);void mc_V2P87Xoe0TGNeXNcn27vUJ(const PmBoolVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmBoolVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_VqP4HesDIf47bDn5teE2H2(const PmRealVector*
mc_VRbT1WwZjwW6f5YGBCFuaD,size_t mc_FnrjFNs9eQp9V5vCxPaoKw,const PmRealVector*
mc__d7LC10lP38OY1VXN_tFqb,size_t mc_FRuIUemzxbdhfqkjXhoyK7,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc_k0zonBZJC2K6baT1NXX1Qo(PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);size_t
mc_FLTxr_Wc1PKSeTxwfrcl5B(const PmBoolVector*mc__MqKyOds56_XeH9Iv3CTIL);void
mc_FX5UXdAa2flS_1wrwznTLh(const PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,const
PmBoolVector*mc_VwOeyeOYCKdcVTySJQVoLE);size_t mc__RsEbvPhcXp6iqwYpH_OQY(const
PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);size_t mc__fQVSVSgEBG6fuximVFlkw(const
PmRealVector*mc_FawmFe5oOEC_cmkvZc1Kaa);size_t mc_FyLahU0kjICfba8O7mWi8Z(const
PmBoolVector*mc_FawmFe5oOEC_cmkvZc1Kaa);boolean_T mc___gjB_jZtTxReaWZSEiFdh(
const PmIntVector*mc_F6sy5cXK8JOKeiFBw6znSV);boolean_T
mc_kNrn2e3NmaGNbmzmXpvCR0(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,int32_T
mc_kg4CyRgbu6OdeewZOel7Qx);boolean_T mc_kk65_VI6zC0mWHqRziXpjX(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_FGkd8Riw6p4eaDCAbwBVPv(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FzkrLuS4xMOvaTv5dUw3j7(const
PmRealVector*x,real_T mc_VgJW5ZqpwPpuY1inYtaofQ);void mc_ks_PW4I7dwWbhXAWhHTUCI
(const PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc__w_RD4J1MZlqcL7as8FLdk(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V3CZVT50_V_xeia9SYYptc(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,real_T a,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_VIFqLU9Z6UtwXDWPnvd_zg(const PmRealVector*x
,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_FBDi_PCg670TjHgJTNPcHr);void mc_VWnvos7Q548uVH7p0208jN(const PmRealVector*x
,const real_T a,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_V7hiVZfxKK0Uj9rPai4LYw(const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
real_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VM9M6KxYTfKL_q4yuXmOnI(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const real_T mc_kcda_aHAM4WIXuM_xBDdLt)
;void mc_k4v_yYmXHgO1cqVdr5a500(const PmIntVector*pm__hARyx1bZBxVj1boVQqdtV,
const PmIntVector*pm__YmIqNX3g5Sub1vKK1hZQF);void mc_V2CDnBdRcOpuh1IyvRJzfi(
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*
pm__YmIqNX3g5Sub1vKK1hZQF);void mc_FNVEyWT4js4ebmsePvfFh2(const PmRealVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc__dsFCQJjA6p_j1tGhi2wWe(const PmRealVector*mc_VcZASgthsTt6dul8DlRWaw,real_T
mc_kcda_aHAM4WIXuM_xBDdLt);void mc_kUD9LJQRjT0FayfqpQrhnP(const PmBoolVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc__aNO1s5qwzt6fXwft5YgCz(const PmRealVector*
mc_VcZASgthsTt6dul8DlRWaw);void mc_VTlukZ0iimdzge7aTGg7rl(const PmIntVector*
mc_VcZASgthsTt6dul8DlRWaw,int32_T mc_kg4CyRgbu6OdeewZOel7Qx);void
mc_VDWYuA0FfQClgukbQcp3js(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc_k9wkPuvMCi4DY1yebDQPHf(const PmIntVector*mc_VcZASgthsTt6dul8DlRWaw);void
mc__Nb_EyyxYi4ddPcS0H7Bot(const PmBoolVector*mc_kd_kJxzsgTx9W19pl4H_AH,const
PmIntVector*mc__vpsWwfj3fx1YDJlP_lHTd,boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);
void mc_k1sxUtEClkOZVuHMQ91JqD(const PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw,
boolean_T mc_kcda_aHAM4WIXuM_xBDdLt);void mc_VWloU5QD6gpaXeK8lmytFA(const
PmBoolVector*mc_VcZASgthsTt6dul8DlRWaw);void mc_VQ1YWbKmkVC6YajZAyvmNH(const
PmBoolVector*x,size_t mc_kwrB3ZoKf7OufTHWaHJV7a,size_t
mc__lO81KuDBk41W9Wd2wAkb0);void mc__uq8ZXcr_B_zgDxjibJDSi(const PmBoolVector*
pm__hARyx1bZBxVj1boVQqdtV,const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);void
mc_FnkaeEp6tpWlhHVVTP_g3C(const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF);real_T mc_F1fvRD4xlFhBdyqJtcgdmn(const
PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);real_T mc_kMPF5fccZd_3jHFMhUSro6(const
PmRealVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_kvxcenZbLm4dfenXL8jQAx(
const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);int32_T mc_Vgo5SAIS_80_VXwmU7JogX
(const PmIntVector*pm_FiALy5LWvv87e9O_pJGWPC);void mc__25pQTf4VutiXiGTGQmvSU(
PmIntVector*mc__nP_wNlJUxWHWLytmZ4pL0,const PmIntVector*
mc_F6sy5cXK8JOKeiFBw6znSV);void mc__LECH_YE38C6YH4eYxxbSd(PmRealVector*
mc_VWoEnwEgWFpobmwHA1Qln5,const PmRealVector*mc_V_rxJBbuhqtwViRHFKhdGC,const
PmSparsityPattern*mc__Df1hQFzAY4fiLCvP0PV12);void mc_VMRKMuNLnDxXjaBiy1RcMD(
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_kM_Y9u9U2F_Cf9sWAtmMMu(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc__Xq_g76c6Y_K_PpYNKcquN(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const
PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const real_T*x);void mc_kXj99iXjC1CoZLWwPRH879(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*mc_FybTf2SinthyWqOxvPdJ5h,size_t mc_VVRAoFgW2Hphcy7H6H9Oh0)
;void mc__75oXIAh8pt6cyvuqOckyG(const PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,
const PmRealVector*mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV,const
PmRealVector*mc_VxvrZHk3QVKlWycYYdZEat);void mc_kLGj2IdnGDG_YeEKAnMkUr(const
PmRealVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmRealVector*
mc_FCZxG6Iux_GKX1lkqasXdQ,const PmSparsityPattern*mc_VknkCg_msB8Ga9ymQtGggf,
const PmRealVector*pm__hARyx1bZBxVj1boVQqdtV);void mc_FJN_drUOKh_igHJXVH7xls(
const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL,const PmRealVector*
mc_V8ujEMKrDU8Q_mvu4yja1b,const PmSparsityPattern*mc_V_ku0ZO8TOxhc9438tlsBI,
size_t mc_kyp6uAyJE40UVuAQNEYzS1,real_T mc_kcda_aHAM4WIXuM_xBDdLt);void
mc__WqQP6u7DtdYVDzUK5y971(const PmRealVector*mc_FBDi_PCg670TjHgJTNPcHr,const
PmRealVector*x,const PmRealVector*mc_FzyLWRgau0pMYq2XSI3ETL);void
mc_kc89O49Oe18lWqn1Nr_t61(const PmRealVector*mc_FrF2gTbWxox8geiSROFaFn,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE,const PmIntVector*
mc__sdtG1OgJQtqcikFA20Doo);void mc_F4wnJSMmz0WHaHs2tnfI5y(const PmRealVector*
mc_FrF2gTbWxox8geiSROFaFn,const PmIntVector*mc__sdtG1OgJQtqcikFA20Doo,const
PmRealVector*mc_VwOeyeOYCKdcVTySJQVoLE);void mc_VjzTgsx19j0KfHv6VXr4Mp(const
PmRealVector*a,const PmIntVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*
b);void mc_V_Fp06wJOBhXZyLbA5xU0r(const PmRealVector*a,const PmRealVector*b,
const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a);void mc_FuY0t5xEb5_QhDQFQ_TXtc(
const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_kkPot0UJiN_EX94QlR_mCs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,real_T x);void mc_kMo1w3ReRZGIdH5_MNwumc
(const PmRealVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmRealVector*b);void mc_VYxtXnMKT6hpb1FMldBDLs(const PmRealVector*a,const
PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const PmRealVector*b);void
mc_k2E2oWXDqshMeuCQWrbaKT(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_FBaB5196Xx0ohX_IWM5ypL(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T x);
void mc_F1CG0fHJYfd_ealLMx7Z7U(const PmIntVector*a,const PmBoolVector*
mc_kwrB3ZoKf7OufTHWaHJV7a,const PmIntVector*b);void mc_krXbD205SBpghif1h1n_ei(
const PmIntVector*a,const PmBoolVector*mc_kwrB3ZoKf7OufTHWaHJV7a,const
PmIntVector*b);void mc__0IkRn0eQ9Wc_u8mCNbQDh(const PmIntVector*
mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);
void mc__pbFNjwg_bCPdPFSjC2Wdv(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,
const PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void
mc_VpjBXBa8TTCl_uBXYMLfxC(const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const
PmSparsityPattern*mc_FBOWjCOBM8SyhqFe64oqrx);void mc__pFtu1g17h8ZaaZK4PpTkb(
const PmBoolVector*mc_VUELvXWGXPlKf1brR9MRC3,const PmSparsityPattern*
mc_FBOWjCOBM8SyhqFe64oqrx);void mc_kMScbNM1RKOTaD4QwTME8Y(const PmBoolVector*
mc__1Zf2IciMRCub1vvbEr1C4,const PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,
const PmRealVector*mc_VlnhKi82gfCLgumIqeduOq);void mc_Fbsqat6MlL0bjPHlNxax8t(
const PmBoolVector*pm__YmIqNX3g5Sub1vKK1hZQF,const PmSparsityPattern*
mc_VknkCg_msB8Ga9ymQtGggf,const PmBoolVector*pm__hARyx1bZBxVj1boVQqdtV);void
mc_FSAdXYnRP9pkfmWBYlMkJJ(const PmRealVector*mc_kVkvrfpzuVduaPTr5FLF8K,const
PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,const PmBoolVector*
mc_F8fT7naL9bOcimTADCVzTC);void mc__NertSre4cWh_mN2RJ5UPq(const PmRealVector*
mc_kVkvrfpzuVduaPTr5FLF8K,const PmSparsityPattern*mc__srK5LmyWw42ZyPnbOWDWJ,
const PmBoolVector*pm_VCVhWy_VaDhraHrlfFWxBa);PmRealVector
mc_VPFwoVShg1G3XTwou1_jbC(const PmRealVector*mc_VgJW5ZqpwPpuY1inYtaofQ,size_t
mc_Fyss_XM3F_C4dm6IKoDw4G,size_t mc_Vs6xonQX17Krc5vXv8T_zq);static int32_T
mc_FEzcko_YIU0YX5mxnQRJ0p(int32_T mc__CLRBwg4eOSEiqHPYKDedF,int32_T
mc_FdsAaRljWQtgielVhV0hE6,int32_T*mc_V1pxxydYEnWVVi3QKesjvf,int32_T n){int32_T
mc_V2__YrimeI4E_yWnhKofpy;if(mc__CLRBwg4eOSEiqHPYKDedF<2||(
mc__CLRBwg4eOSEiqHPYKDedF+mc_FdsAaRljWQtgielVhV0hE6<0)){for(
mc_V2__YrimeI4E_yWnhKofpy=0;mc_V2__YrimeI4E_yWnhKofpy<n;
mc_V2__YrimeI4E_yWnhKofpy++)if(mc_V1pxxydYEnWVVi3QKesjvf[
mc_V2__YrimeI4E_yWnhKofpy]!=0)mc_V1pxxydYEnWVVi3QKesjvf[
mc_V2__YrimeI4E_yWnhKofpy]=1;mc__CLRBwg4eOSEiqHPYKDedF=2;}return(
mc__CLRBwg4eOSEiqHPYKDedF);}static int32_T mc_Vx9gfgV3sHOGc9BSCvRPeL(int32_T
mc_kwrB3ZoKf7OufTHWaHJV7a,int32_T mc_kyp6uAyJE40UVuAQNEYzS1,double
mc_FKnJ9_uGmQ_yYPw_yTe4ZK,void*pm__sjTRWOMR4WzZisVeB2fYm){return(
mc_kwrB3ZoKf7OufTHWaHJV7a!=mc_kyp6uAyJE40UVuAQNEYzS1);}int32_T*
mc_FAnXK3hkeY_FimobZpSWy4(int32_T mc_FruBC65sPgSaZ5e_Y8cbTC,const
mc_F5Olyc6xUoG7ZyDq78exBD*A){mc_F5Olyc6xUoG7ZyDq78exBD*
mc_FStFcQlyAJ_dVy4kGZXBPQ,*mc__yYih2ZbFASEeyR0_Dhcnl,*
mc_FkvBQdfnWOCY_uJC_r4riI;int32_T*mc_k7NnK4S2Nx0Oc1_SgnTsdQ,*
mc_VQiKC_sK6bhBdy51ifHSOG,*mc__s9c11FV6MCacH_iL7euSO,*
mc_F5Ms7XlOr2OXjyocf4hGw2,*mc__Mwijnrb0M46cT7T_bvxpH,*
mc_kU7ggFH4OMWpai03C_e14O,*mc_FTf2iFFdsgK3hewKsMgEx4,*
mc_FZH6zKAr7oO3jijhKSuiBZ,*mc_FcKez189ghKAYyDjWA9v5n,*
mc_VGFqTyNi4g4A_yWCFVUz8v,*mc_kI0mjAHPXNSe_5d7sQlfnN,*
mc_V1pxxydYEnWVVi3QKesjvf,*mc_FBFgUbvlnkxXa9jBj82PWN,*
mc__Fn5EsB0mzxEVyfFLauR3G,*mc_Ff6ymDzpQMpzWH2RriXxEn,mc_F32Ql82vv6pW_PYIdpkFQ0
,mc_V5hmnKYoJxtYeXsPLFw9Dm,mc_kpH0JYkq_J01XTi_issE2r,mc_FdsAaRljWQtgielVhV0hE6
=0,mc_FCMoPwLeYFCfherwNS2L8C,mc__eEWUtjzzs_lh56__gM9HC,
mc__1s1WFrNXhKmXeQbW0gziC,mc_kwrB3ZoKf7OufTHWaHJV7a,mc_kyp6uAyJE40UVuAQNEYzS1,
mc_V2__YrimeI4E_yWnhKofpy,mc_VzvO0OUVd1llbq7AHin756,mc_V8asLYxbtVhDaa6g0v6kkm,
mc_VeXLrlIS1h8Zai5N7B0ZIb,mc_F4Nt2yaY74_FXL9Jz1UHgb,mc_kZvatJe9hBO2aLrboC3gGO,
mc__uZCUgR80SCMYic8wQ7amp,mc_FIxFweA3fcKFfuFXAKfA47,mc_kprk4TF6z6WpduVVli_Ph2=
0,mc_VoKDVQkmDo8J_qCjvSHdi7,mc__xY2K_DKAWGBhXFil2_bTe,
mc_V8FxTUVKviGuV9235TCBP_,mc__CLRBwg4eOSEiqHPYKDedF,mc_FzZTvPfL0mhDj10e5og2IC,
mc__suOgr_4PeCIZi_uhoSVwf,mc_FypnHlhKDX_h_qv0Oovb82,mc_kJg_DQxVlw4ChDUQlrBLIp=
0,pm__lqjegyKuwStj56WZLiC_e,mc_VCifngWB8ylih96lyIXhqB,
mc_kKqBGNT_1FKwc50fpD5uis,mc__mDWdk1CPwx0euBx3u7Q8_,mc_VA68FqGATPlDWiemoJ9Qug,
mc_kBH6mUWlpr4PjPk7CtNM78,mc_knuzqmrfEfp0W1w1cnHjxI,mc_FR9ceqZ3mNCacyybeXDg1S,
mc___GqWtOKIc8EcP1QpXfUOa,mc_V_WEE_p6i78_X19JePE6Tg,mc__AExROh1PVWNeP7hmMWuJv,
n,mc_VLHhnPUiNQpve5VIL9P3O9,mc__1eAP9V6_J_NYm_1gTIm7A;int32_T
mc__lU1mWENxFpCeio7tYki0i;if(!(A&&(A->mc___ECRgjqShlp_PytRplerL== -1))||
mc_FruBC65sPgSaZ5e_Y8cbTC<=0||mc_FruBC65sPgSaZ5e_Y8cbTC>3)return(NULL);
mc_FkvBQdfnWOCY_uJC_r4riI=mc_kzs_RE98zypjVHi58lxG6O(A,0);if(!
mc_FkvBQdfnWOCY_uJC_r4riI)return(NULL);mc_VLHhnPUiNQpve5VIL9P3O9=A->
mc_VLHhnPUiNQpve5VIL9P3O9;n=A->n;mc__uZCUgR80SCMYic8wQ7amp=(int32_T)((((16)>(
10*sqrt((double)n)))?(16):(10*sqrt((double)n))));mc__uZCUgR80SCMYic8wQ7amp=(((
n-2)<(mc__uZCUgR80SCMYic8wQ7amp))?(n-2):(mc__uZCUgR80SCMYic8wQ7amp));if(
mc_FruBC65sPgSaZ5e_Y8cbTC==1&&n==mc_VLHhnPUiNQpve5VIL9P3O9){
mc_FStFcQlyAJ_dVy4kGZXBPQ=mc_F_KsXRscHI0GbqNNEbk0p9(A,
mc_FkvBQdfnWOCY_uJC_r4riI,0,0);}else if(mc_FruBC65sPgSaZ5e_Y8cbTC==2){
mc__Fn5EsB0mzxEVyfFLauR3G=mc_FkvBQdfnWOCY_uJC_r4riI->pm__lqjegyKuwStj56WZLiC_e
;mc_Ff6ymDzpQMpzWH2RriXxEn=mc_FkvBQdfnWOCY_uJC_r4riI->
mc_kwrB3ZoKf7OufTHWaHJV7a;for(mc_kKqBGNT_1FKwc50fpD5uis=0,
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<
mc_VLHhnPUiNQpve5VIL9P3O9;mc_kyp6uAyJE40UVuAQNEYzS1++){
pm__lqjegyKuwStj56WZLiC_e=mc__Fn5EsB0mzxEVyfFLauR3G[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc__Fn5EsB0mzxEVyfFLauR3G[mc_kyp6uAyJE40UVuAQNEYzS1]=
mc_kKqBGNT_1FKwc50fpD5uis;if(mc__Fn5EsB0mzxEVyfFLauR3G[
mc_kyp6uAyJE40UVuAQNEYzS1+1]-pm__lqjegyKuwStj56WZLiC_e>
mc__uZCUgR80SCMYic8wQ7amp)continue;for(;pm__lqjegyKuwStj56WZLiC_e<
mc__Fn5EsB0mzxEVyfFLauR3G[mc_kyp6uAyJE40UVuAQNEYzS1+1];
pm__lqjegyKuwStj56WZLiC_e++)mc_Ff6ymDzpQMpzWH2RriXxEn[
mc_kKqBGNT_1FKwc50fpD5uis++]=mc_Ff6ymDzpQMpzWH2RriXxEn[
pm__lqjegyKuwStj56WZLiC_e];}mc__Fn5EsB0mzxEVyfFLauR3G[
mc_VLHhnPUiNQpve5VIL9P3O9]=mc_kKqBGNT_1FKwc50fpD5uis;mc__yYih2ZbFASEeyR0_Dhcnl
=mc_kzs_RE98zypjVHi58lxG6O(mc_FkvBQdfnWOCY_uJC_r4riI,0);
mc_FStFcQlyAJ_dVy4kGZXBPQ=mc__yYih2ZbFASEeyR0_Dhcnl?mc_F1T9nfE5YBd9_eUgmYQiFQ(
mc_FkvBQdfnWOCY_uJC_r4riI,mc__yYih2ZbFASEeyR0_Dhcnl):NULL;
mc__BJ1NEDJTgOMhaJKDrM6pN(mc__yYih2ZbFASEeyR0_Dhcnl);}else{
mc_FStFcQlyAJ_dVy4kGZXBPQ=mc_F1T9nfE5YBd9_eUgmYQiFQ(mc_FkvBQdfnWOCY_uJC_r4riI,
A);}mc__BJ1NEDJTgOMhaJKDrM6pN(mc_FkvBQdfnWOCY_uJC_r4riI);if(!
mc_FStFcQlyAJ_dVy4kGZXBPQ)return(NULL);mc__78cLFJw_ySFbTb4k127zA(
mc_FStFcQlyAJ_dVy4kGZXBPQ,&mc_Vx9gfgV3sHOGc9BSCvRPeL,NULL);
mc_k7NnK4S2Nx0Oc1_SgnTsdQ=mc_FStFcQlyAJ_dVy4kGZXBPQ->pm__lqjegyKuwStj56WZLiC_e
;mc_FypnHlhKDX_h_qv0Oovb82=mc_k7NnK4S2Nx0Oc1_SgnTsdQ[n];
mc_FZH6zKAr7oO3jijhKSuiBZ=mc_ktrY1jmEuvhTfeGflVz93o(n+1,sizeof(int32_T));
mc_F5Ms7XlOr2OXjyocf4hGw2=mc_ktrY1jmEuvhTfeGflVz93o(8*(n+1),sizeof(int32_T));
mc__1eAP9V6_J_NYm_1gTIm7A=mc_FypnHlhKDX_h_qv0Oovb82+mc_FypnHlhKDX_h_qv0Oovb82/
5+2*n;if(!mc_FZH6zKAr7oO3jijhKSuiBZ||!mc_F5Ms7XlOr2OXjyocf4hGw2||!
mc_VptvBjskDA83heaLThR8oY(mc_FStFcQlyAJ_dVy4kGZXBPQ,mc__1eAP9V6_J_NYm_1gTIm7A)
)return(mc_Ff7NuTFKk3OCYDKMqomZ1z(mc_FZH6zKAr7oO3jijhKSuiBZ,
mc_FStFcQlyAJ_dVy4kGZXBPQ,mc_F5Ms7XlOr2OXjyocf4hGw2,0));
mc__Mwijnrb0M46cT7T_bvxpH=mc_F5Ms7XlOr2OXjyocf4hGw2;mc_kU7ggFH4OMWpai03C_e14O=
mc_F5Ms7XlOr2OXjyocf4hGw2+(n+1);mc_FTf2iFFdsgK3hewKsMgEx4=
mc_F5Ms7XlOr2OXjyocf4hGw2+2*(n+1);mc_FcKez189ghKAYyDjWA9v5n=
mc_F5Ms7XlOr2OXjyocf4hGw2+3*(n+1);mc_VGFqTyNi4g4A_yWCFVUz8v=
mc_F5Ms7XlOr2OXjyocf4hGw2+4*(n+1);mc_kI0mjAHPXNSe_5d7sQlfnN=
mc_F5Ms7XlOr2OXjyocf4hGw2+5*(n+1);mc_V1pxxydYEnWVVi3QKesjvf=
mc_F5Ms7XlOr2OXjyocf4hGw2+6*(n+1);mc_FBFgUbvlnkxXa9jBj82PWN=
mc_F5Ms7XlOr2OXjyocf4hGw2+7*(n+1);mc__s9c11FV6MCacH_iL7euSO=
mc_FZH6zKAr7oO3jijhKSuiBZ;for(mc_V2__YrimeI4E_yWnhKofpy=0;
mc_V2__YrimeI4E_yWnhKofpy<n;mc_V2__YrimeI4E_yWnhKofpy++)
mc__Mwijnrb0M46cT7T_bvxpH[mc_V2__YrimeI4E_yWnhKofpy]=mc_k7NnK4S2Nx0Oc1_SgnTsdQ
[mc_V2__YrimeI4E_yWnhKofpy+1]-mc_k7NnK4S2Nx0Oc1_SgnTsdQ[
mc_V2__YrimeI4E_yWnhKofpy];mc__Mwijnrb0M46cT7T_bvxpH[n]=0;
mc_FIxFweA3fcKFfuFXAKfA47=mc_FStFcQlyAJ_dVy4kGZXBPQ->mc_FIxFweA3fcKFfuFXAKfA47
;mc_VQiKC_sK6bhBdy51ifHSOG=mc_FStFcQlyAJ_dVy4kGZXBPQ->
mc_kwrB3ZoKf7OufTHWaHJV7a;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<=n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_FcKez189ghKAYyDjWA9v5n[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;
mc__s9c11FV6MCacH_iL7euSO[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;
mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;
mc_FBFgUbvlnkxXa9jBj82PWN[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;
mc_kU7ggFH4OMWpai03C_e14O[mc_kwrB3ZoKf7OufTHWaHJV7a]=1;
mc_V1pxxydYEnWVVi3QKesjvf[mc_kwrB3ZoKf7OufTHWaHJV7a]=1;
mc_VGFqTyNi4g4A_yWCFVUz8v[mc_kwrB3ZoKf7OufTHWaHJV7a]=0;
mc_kI0mjAHPXNSe_5d7sQlfnN[mc_kwrB3ZoKf7OufTHWaHJV7a]=mc__Mwijnrb0M46cT7T_bvxpH
[mc_kwrB3ZoKf7OufTHWaHJV7a];}mc__CLRBwg4eOSEiqHPYKDedF=
mc_FEzcko_YIU0YX5mxnQRJ0p(0,0,mc_V1pxxydYEnWVVi3QKesjvf,n);
mc_VGFqTyNi4g4A_yWCFVUz8v[n]= -2;mc_k7NnK4S2Nx0Oc1_SgnTsdQ[n]= -1;
mc_V1pxxydYEnWVVi3QKesjvf[n]=0;for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++){
mc_F32Ql82vv6pW_PYIdpkFQ0=mc_kI0mjAHPXNSe_5d7sQlfnN[mc_kwrB3ZoKf7OufTHWaHJV7a]
;if(mc_F32Ql82vv6pW_PYIdpkFQ0==0){mc_VGFqTyNi4g4A_yWCFVUz8v[
mc_kwrB3ZoKf7OufTHWaHJV7a]= -2;mc_kJg_DQxVlw4ChDUQlrBLIp++;
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;
mc_V1pxxydYEnWVVi3QKesjvf[mc_kwrB3ZoKf7OufTHWaHJV7a]=0;}else if(
mc_F32Ql82vv6pW_PYIdpkFQ0>mc__uZCUgR80SCMYic8wQ7amp){mc_kU7ggFH4OMWpai03C_e14O
[mc_kwrB3ZoKf7OufTHWaHJV7a]=0;mc_VGFqTyNi4g4A_yWCFVUz8v[
mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;mc_kJg_DQxVlw4ChDUQlrBLIp++;
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a]=(-(n)-2);
mc_kU7ggFH4OMWpai03C_e14O[n]++;}else{if(mc_FcKez189ghKAYyDjWA9v5n[
mc_F32Ql82vv6pW_PYIdpkFQ0]!= -1)mc__s9c11FV6MCacH_iL7euSO[
mc_FcKez189ghKAYyDjWA9v5n[mc_F32Ql82vv6pW_PYIdpkFQ0]]=
mc_kwrB3ZoKf7OufTHWaHJV7a;mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a]
=mc_FcKez189ghKAYyDjWA9v5n[mc_F32Ql82vv6pW_PYIdpkFQ0];
mc_FcKez189ghKAYyDjWA9v5n[mc_F32Ql82vv6pW_PYIdpkFQ0]=mc_kwrB3ZoKf7OufTHWaHJV7a
;}}while(mc_kJg_DQxVlw4ChDUQlrBLIp<n){for(mc_V2__YrimeI4E_yWnhKofpy= -1;
mc_kprk4TF6z6WpduVVli_Ph2<n&&(mc_V2__YrimeI4E_yWnhKofpy=
mc_FcKez189ghKAYyDjWA9v5n[mc_kprk4TF6z6WpduVVli_Ph2])== -1;
mc_kprk4TF6z6WpduVVli_Ph2++);if(mc_FTf2iFFdsgK3hewKsMgEx4[
mc_V2__YrimeI4E_yWnhKofpy]!= -1)mc__s9c11FV6MCacH_iL7euSO[
mc_FTf2iFFdsgK3hewKsMgEx4[mc_V2__YrimeI4E_yWnhKofpy]]= -1;
mc_FcKez189ghKAYyDjWA9v5n[mc_kprk4TF6z6WpduVVli_Ph2]=mc_FTf2iFFdsgK3hewKsMgEx4
[mc_V2__YrimeI4E_yWnhKofpy];mc__eEWUtjzzs_lh56__gM9HC=
mc_VGFqTyNi4g4A_yWCFVUz8v[mc_V2__YrimeI4E_yWnhKofpy];mc_V8FxTUVKviGuV9235TCBP_
=mc_kU7ggFH4OMWpai03C_e14O[mc_V2__YrimeI4E_yWnhKofpy];
mc_kJg_DQxVlw4ChDUQlrBLIp+=mc_V8FxTUVKviGuV9235TCBP_;if(
mc__eEWUtjzzs_lh56__gM9HC>0&&mc_FypnHlhKDX_h_qv0Oovb82+
mc_kprk4TF6z6WpduVVli_Ph2>=mc_FIxFweA3fcKFfuFXAKfA47){for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<n;
mc_kyp6uAyJE40UVuAQNEYzS1++){if((pm__lqjegyKuwStj56WZLiC_e=
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1])>=0){
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1]=mc_VQiKC_sK6bhBdy51ifHSOG
[pm__lqjegyKuwStj56WZLiC_e];mc_VQiKC_sK6bhBdy51ifHSOG[
pm__lqjegyKuwStj56WZLiC_e]=(-(mc_kyp6uAyJE40UVuAQNEYzS1)-2);}}for(
mc__AExROh1PVWNeP7hmMWuJv=0,pm__lqjegyKuwStj56WZLiC_e=0;
pm__lqjegyKuwStj56WZLiC_e<mc_FypnHlhKDX_h_qv0Oovb82;){if((
mc_kyp6uAyJE40UVuAQNEYzS1=(-(mc_VQiKC_sK6bhBdy51ifHSOG[
pm__lqjegyKuwStj56WZLiC_e++])-2))>=0){mc_VQiKC_sK6bhBdy51ifHSOG[
mc__AExROh1PVWNeP7hmMWuJv]=mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1
];mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1]=
mc__AExROh1PVWNeP7hmMWuJv++;for(mc_VeXLrlIS1h8Zai5N7B0ZIb=0;
mc_VeXLrlIS1h8Zai5N7B0ZIb<mc__Mwijnrb0M46cT7T_bvxpH[mc_kyp6uAyJE40UVuAQNEYzS1]
-1;mc_VeXLrlIS1h8Zai5N7B0ZIb++)mc_VQiKC_sK6bhBdy51ifHSOG[
mc__AExROh1PVWNeP7hmMWuJv++]=mc_VQiKC_sK6bhBdy51ifHSOG[
pm__lqjegyKuwStj56WZLiC_e++];}}mc_FypnHlhKDX_h_qv0Oovb82=
mc__AExROh1PVWNeP7hmMWuJv;}mc_V5hmnKYoJxtYeXsPLFw9Dm=0;
mc_kU7ggFH4OMWpai03C_e14O[mc_V2__YrimeI4E_yWnhKofpy]= -
mc_V8FxTUVKviGuV9235TCBP_;pm__lqjegyKuwStj56WZLiC_e=mc_k7NnK4S2Nx0Oc1_SgnTsdQ[
mc_V2__YrimeI4E_yWnhKofpy];mc_FR9ceqZ3mNCacyybeXDg1S=(
mc__eEWUtjzzs_lh56__gM9HC==0)?pm__lqjegyKuwStj56WZLiC_e:
mc_FypnHlhKDX_h_qv0Oovb82;mc___GqWtOKIc8EcP1QpXfUOa=mc_FR9ceqZ3mNCacyybeXDg1S;
for(mc_VzvO0OUVd1llbq7AHin756=1;mc_VzvO0OUVd1llbq7AHin756<=
mc__eEWUtjzzs_lh56__gM9HC+1;mc_VzvO0OUVd1llbq7AHin756++){if(
mc_VzvO0OUVd1llbq7AHin756>mc__eEWUtjzzs_lh56__gM9HC){mc_FCMoPwLeYFCfherwNS2L8C
=mc_V2__YrimeI4E_yWnhKofpy;mc_kBH6mUWlpr4PjPk7CtNM78=pm__lqjegyKuwStj56WZLiC_e
;mc_kZvatJe9hBO2aLrboC3gGO=mc__Mwijnrb0M46cT7T_bvxpH[mc_V2__YrimeI4E_yWnhKofpy
]-mc__eEWUtjzzs_lh56__gM9HC;}else{mc_FCMoPwLeYFCfherwNS2L8C=
mc_VQiKC_sK6bhBdy51ifHSOG[pm__lqjegyKuwStj56WZLiC_e++];
mc_kBH6mUWlpr4PjPk7CtNM78=mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_FCMoPwLeYFCfherwNS2L8C]
;mc_kZvatJe9hBO2aLrboC3gGO=mc__Mwijnrb0M46cT7T_bvxpH[mc_FCMoPwLeYFCfherwNS2L8C
];}for(mc_V8asLYxbtVhDaa6g0v6kkm=1;mc_V8asLYxbtVhDaa6g0v6kkm<=
mc_kZvatJe9hBO2aLrboC3gGO;mc_V8asLYxbtVhDaa6g0v6kkm++){
mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VQiKC_sK6bhBdy51ifHSOG[mc_kBH6mUWlpr4PjPk7CtNM78
++];if((mc_VoKDVQkmDo8J_qCjvSHdi7=mc_kU7ggFH4OMWpai03C_e14O[
mc_kwrB3ZoKf7OufTHWaHJV7a])<=0)continue;mc_V5hmnKYoJxtYeXsPLFw9Dm+=
mc_VoKDVQkmDo8J_qCjvSHdi7;mc_kU7ggFH4OMWpai03C_e14O[mc_kwrB3ZoKf7OufTHWaHJV7a]
= -mc_VoKDVQkmDo8J_qCjvSHdi7;mc_VQiKC_sK6bhBdy51ifHSOG[
mc___GqWtOKIc8EcP1QpXfUOa++]=mc_kwrB3ZoKf7OufTHWaHJV7a;if(
mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a]!= -1)
mc__s9c11FV6MCacH_iL7euSO[mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a]
]=mc__s9c11FV6MCacH_iL7euSO[mc_kwrB3ZoKf7OufTHWaHJV7a];if(
mc__s9c11FV6MCacH_iL7euSO[mc_kwrB3ZoKf7OufTHWaHJV7a]!= -1){
mc_FTf2iFFdsgK3hewKsMgEx4[mc__s9c11FV6MCacH_iL7euSO[mc_kwrB3ZoKf7OufTHWaHJV7a]
]=mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a];}else{
mc_FcKez189ghKAYyDjWA9v5n[mc_kI0mjAHPXNSe_5d7sQlfnN[mc_kwrB3ZoKf7OufTHWaHJV7a]
]=mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a];}}if(
mc_FCMoPwLeYFCfherwNS2L8C!=mc_V2__YrimeI4E_yWnhKofpy){
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_FCMoPwLeYFCfherwNS2L8C]=(-(
mc_V2__YrimeI4E_yWnhKofpy)-2);mc_V1pxxydYEnWVVi3QKesjvf[
mc_FCMoPwLeYFCfherwNS2L8C]=0;}}if(mc__eEWUtjzzs_lh56__gM9HC!=0)
mc_FypnHlhKDX_h_qv0Oovb82=mc___GqWtOKIc8EcP1QpXfUOa;mc_kI0mjAHPXNSe_5d7sQlfnN[
mc_V2__YrimeI4E_yWnhKofpy]=mc_V5hmnKYoJxtYeXsPLFw9Dm;mc_k7NnK4S2Nx0Oc1_SgnTsdQ
[mc_V2__YrimeI4E_yWnhKofpy]=mc_FR9ceqZ3mNCacyybeXDg1S;
mc__Mwijnrb0M46cT7T_bvxpH[mc_V2__YrimeI4E_yWnhKofpy]=mc___GqWtOKIc8EcP1QpXfUOa
-mc_FR9ceqZ3mNCacyybeXDg1S;mc_VGFqTyNi4g4A_yWCFVUz8v[mc_V2__YrimeI4E_yWnhKofpy
]= -2;mc__CLRBwg4eOSEiqHPYKDedF=mc_FEzcko_YIU0YX5mxnQRJ0p(
mc__CLRBwg4eOSEiqHPYKDedF,mc_FdsAaRljWQtgielVhV0hE6,mc_V1pxxydYEnWVVi3QKesjvf,
n);for(mc_knuzqmrfEfp0W1w1cnHjxI=mc_FR9ceqZ3mNCacyybeXDg1S;
mc_knuzqmrfEfp0W1w1cnHjxI<mc___GqWtOKIc8EcP1QpXfUOa;mc_knuzqmrfEfp0W1w1cnHjxI
++){mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VQiKC_sK6bhBdy51ifHSOG[
mc_knuzqmrfEfp0W1w1cnHjxI];if((mc__1s1WFrNXhKmXeQbW0gziC=
mc_VGFqTyNi4g4A_yWCFVUz8v[mc_kwrB3ZoKf7OufTHWaHJV7a])<=0)continue;
mc_VoKDVQkmDo8J_qCjvSHdi7= -mc_kU7ggFH4OMWpai03C_e14O[
mc_kwrB3ZoKf7OufTHWaHJV7a];mc_FzZTvPfL0mhDj10e5og2IC=mc__CLRBwg4eOSEiqHPYKDedF
-mc_VoKDVQkmDo8J_qCjvSHdi7;for(pm__lqjegyKuwStj56WZLiC_e=
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a];pm__lqjegyKuwStj56WZLiC_e
<=mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a]+
mc__1s1WFrNXhKmXeQbW0gziC-1;pm__lqjegyKuwStj56WZLiC_e++){
mc_FCMoPwLeYFCfherwNS2L8C=mc_VQiKC_sK6bhBdy51ifHSOG[pm__lqjegyKuwStj56WZLiC_e]
;if(mc_V1pxxydYEnWVVi3QKesjvf[mc_FCMoPwLeYFCfherwNS2L8C]>=
mc__CLRBwg4eOSEiqHPYKDedF){mc_V1pxxydYEnWVVi3QKesjvf[mc_FCMoPwLeYFCfherwNS2L8C
]-=mc_VoKDVQkmDo8J_qCjvSHdi7;}else if(mc_V1pxxydYEnWVVi3QKesjvf[
mc_FCMoPwLeYFCfherwNS2L8C]!=0){mc_V1pxxydYEnWVVi3QKesjvf[
mc_FCMoPwLeYFCfherwNS2L8C]=mc_kI0mjAHPXNSe_5d7sQlfnN[mc_FCMoPwLeYFCfherwNS2L8C
]+mc_FzZTvPfL0mhDj10e5og2IC;}}}for(mc_knuzqmrfEfp0W1w1cnHjxI=
mc_FR9ceqZ3mNCacyybeXDg1S;mc_knuzqmrfEfp0W1w1cnHjxI<mc___GqWtOKIc8EcP1QpXfUOa;
mc_knuzqmrfEfp0W1w1cnHjxI++){mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_VQiKC_sK6bhBdy51ifHSOG[mc_knuzqmrfEfp0W1w1cnHjxI];mc_VCifngWB8ylih96lyIXhqB
=mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a];
mc_kKqBGNT_1FKwc50fpD5uis=mc_VCifngWB8ylih96lyIXhqB+mc_VGFqTyNi4g4A_yWCFVUz8v[
mc_kwrB3ZoKf7OufTHWaHJV7a]-1;mc_V_WEE_p6i78_X19JePE6Tg=
mc_VCifngWB8ylih96lyIXhqB;for(mc__lU1mWENxFpCeio7tYki0i=0,
mc_F32Ql82vv6pW_PYIdpkFQ0=0,pm__lqjegyKuwStj56WZLiC_e=
mc_VCifngWB8ylih96lyIXhqB;pm__lqjegyKuwStj56WZLiC_e<=mc_kKqBGNT_1FKwc50fpD5uis
;pm__lqjegyKuwStj56WZLiC_e++){mc_FCMoPwLeYFCfherwNS2L8C=
mc_VQiKC_sK6bhBdy51ifHSOG[pm__lqjegyKuwStj56WZLiC_e];if(
mc_V1pxxydYEnWVVi3QKesjvf[mc_FCMoPwLeYFCfherwNS2L8C]!=0){
mc_kpH0JYkq_J01XTi_issE2r=mc_V1pxxydYEnWVVi3QKesjvf[mc_FCMoPwLeYFCfherwNS2L8C]
-mc__CLRBwg4eOSEiqHPYKDedF;if(mc_kpH0JYkq_J01XTi_issE2r>0){
mc_F32Ql82vv6pW_PYIdpkFQ0+=mc_kpH0JYkq_J01XTi_issE2r;mc_VQiKC_sK6bhBdy51ifHSOG
[mc_V_WEE_p6i78_X19JePE6Tg++]=mc_FCMoPwLeYFCfherwNS2L8C;
mc__lU1mWENxFpCeio7tYki0i+=mc_FCMoPwLeYFCfherwNS2L8C;}else{
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_FCMoPwLeYFCfherwNS2L8C]=(-(
mc_V2__YrimeI4E_yWnhKofpy)-2);mc_V1pxxydYEnWVVi3QKesjvf[
mc_FCMoPwLeYFCfherwNS2L8C]=0;}}}mc_VGFqTyNi4g4A_yWCFVUz8v[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_V_WEE_p6i78_X19JePE6Tg-mc_VCifngWB8ylih96lyIXhqB
+1;mc__mDWdk1CPwx0euBx3u7Q8_=mc_V_WEE_p6i78_X19JePE6Tg;
mc_VA68FqGATPlDWiemoJ9Qug=mc_VCifngWB8ylih96lyIXhqB+mc__Mwijnrb0M46cT7T_bvxpH[
mc_kwrB3ZoKf7OufTHWaHJV7a];for(pm__lqjegyKuwStj56WZLiC_e=
mc_kKqBGNT_1FKwc50fpD5uis+1;pm__lqjegyKuwStj56WZLiC_e<
mc_VA68FqGATPlDWiemoJ9Qug;pm__lqjegyKuwStj56WZLiC_e++){
mc_kyp6uAyJE40UVuAQNEYzS1=mc_VQiKC_sK6bhBdy51ifHSOG[pm__lqjegyKuwStj56WZLiC_e]
;if((mc__xY2K_DKAWGBhXFil2_bTe=mc_kU7ggFH4OMWpai03C_e14O[
mc_kyp6uAyJE40UVuAQNEYzS1])<=0)continue;mc_F32Ql82vv6pW_PYIdpkFQ0+=
mc__xY2K_DKAWGBhXFil2_bTe;mc_VQiKC_sK6bhBdy51ifHSOG[mc_V_WEE_p6i78_X19JePE6Tg
++]=mc_kyp6uAyJE40UVuAQNEYzS1;mc__lU1mWENxFpCeio7tYki0i+=
mc_kyp6uAyJE40UVuAQNEYzS1;}if(mc_F32Ql82vv6pW_PYIdpkFQ0==0){
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a]=(-(
mc_V2__YrimeI4E_yWnhKofpy)-2);mc_VoKDVQkmDo8J_qCjvSHdi7= -
mc_kU7ggFH4OMWpai03C_e14O[mc_kwrB3ZoKf7OufTHWaHJV7a];mc_V5hmnKYoJxtYeXsPLFw9Dm
-=mc_VoKDVQkmDo8J_qCjvSHdi7;mc_V8FxTUVKviGuV9235TCBP_+=
mc_VoKDVQkmDo8J_qCjvSHdi7;mc_kJg_DQxVlw4ChDUQlrBLIp+=mc_VoKDVQkmDo8J_qCjvSHdi7
;mc_kU7ggFH4OMWpai03C_e14O[mc_kwrB3ZoKf7OufTHWaHJV7a]=0;
mc_VGFqTyNi4g4A_yWCFVUz8v[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;}else{
mc_kI0mjAHPXNSe_5d7sQlfnN[mc_kwrB3ZoKf7OufTHWaHJV7a]=(((
mc_kI0mjAHPXNSe_5d7sQlfnN[mc_kwrB3ZoKf7OufTHWaHJV7a])<(
mc_F32Ql82vv6pW_PYIdpkFQ0))?(mc_kI0mjAHPXNSe_5d7sQlfnN[
mc_kwrB3ZoKf7OufTHWaHJV7a]):(mc_F32Ql82vv6pW_PYIdpkFQ0));
mc_VQiKC_sK6bhBdy51ifHSOG[mc_V_WEE_p6i78_X19JePE6Tg]=mc_VQiKC_sK6bhBdy51ifHSOG
[mc__mDWdk1CPwx0euBx3u7Q8_];mc_VQiKC_sK6bhBdy51ifHSOG[
mc__mDWdk1CPwx0euBx3u7Q8_]=mc_VQiKC_sK6bhBdy51ifHSOG[mc_VCifngWB8ylih96lyIXhqB
];mc_VQiKC_sK6bhBdy51ifHSOG[mc_VCifngWB8ylih96lyIXhqB]=
mc_V2__YrimeI4E_yWnhKofpy;mc__Mwijnrb0M46cT7T_bvxpH[mc_kwrB3ZoKf7OufTHWaHJV7a]
=mc_V_WEE_p6i78_X19JePE6Tg-mc_VCifngWB8ylih96lyIXhqB+1;
mc__lU1mWENxFpCeio7tYki0i%=n;mc_FTf2iFFdsgK3hewKsMgEx4[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_FBFgUbvlnkxXa9jBj82PWN[mc__lU1mWENxFpCeio7tYki0i
];mc_FBFgUbvlnkxXa9jBj82PWN[mc__lU1mWENxFpCeio7tYki0i]=
mc_kwrB3ZoKf7OufTHWaHJV7a;mc__s9c11FV6MCacH_iL7euSO[mc_kwrB3ZoKf7OufTHWaHJV7a]
=mc__lU1mWENxFpCeio7tYki0i;}}mc_kI0mjAHPXNSe_5d7sQlfnN[
mc_V2__YrimeI4E_yWnhKofpy]=mc_V5hmnKYoJxtYeXsPLFw9Dm;mc_FdsAaRljWQtgielVhV0hE6
=(((mc_FdsAaRljWQtgielVhV0hE6)>(mc_V5hmnKYoJxtYeXsPLFw9Dm))?(
mc_FdsAaRljWQtgielVhV0hE6):(mc_V5hmnKYoJxtYeXsPLFw9Dm));
mc__CLRBwg4eOSEiqHPYKDedF=mc_FEzcko_YIU0YX5mxnQRJ0p(mc__CLRBwg4eOSEiqHPYKDedF+
mc_FdsAaRljWQtgielVhV0hE6,mc_FdsAaRljWQtgielVhV0hE6,mc_V1pxxydYEnWVVi3QKesjvf,
n);for(mc_knuzqmrfEfp0W1w1cnHjxI=mc_FR9ceqZ3mNCacyybeXDg1S;
mc_knuzqmrfEfp0W1w1cnHjxI<mc___GqWtOKIc8EcP1QpXfUOa;mc_knuzqmrfEfp0W1w1cnHjxI
++){mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VQiKC_sK6bhBdy51ifHSOG[
mc_knuzqmrfEfp0W1w1cnHjxI];if(mc_kU7ggFH4OMWpai03C_e14O[
mc_kwrB3ZoKf7OufTHWaHJV7a]>=0)continue;mc__lU1mWENxFpCeio7tYki0i=
mc__s9c11FV6MCacH_iL7euSO[mc_kwrB3ZoKf7OufTHWaHJV7a];mc_kwrB3ZoKf7OufTHWaHJV7a
=mc_FBFgUbvlnkxXa9jBj82PWN[mc__lU1mWENxFpCeio7tYki0i];
mc_FBFgUbvlnkxXa9jBj82PWN[mc__lU1mWENxFpCeio7tYki0i]= -1;for(;
mc_kwrB3ZoKf7OufTHWaHJV7a!= -1&&mc_FTf2iFFdsgK3hewKsMgEx4[
mc_kwrB3ZoKf7OufTHWaHJV7a]!= -1;mc_kwrB3ZoKf7OufTHWaHJV7a=
mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a],mc__CLRBwg4eOSEiqHPYKDedF
++){mc_kZvatJe9hBO2aLrboC3gGO=mc__Mwijnrb0M46cT7T_bvxpH[
mc_kwrB3ZoKf7OufTHWaHJV7a];mc__1s1WFrNXhKmXeQbW0gziC=mc_VGFqTyNi4g4A_yWCFVUz8v
[mc_kwrB3ZoKf7OufTHWaHJV7a];for(pm__lqjegyKuwStj56WZLiC_e=
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a]+1;
pm__lqjegyKuwStj56WZLiC_e<=mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a
]+mc_kZvatJe9hBO2aLrboC3gGO-1;pm__lqjegyKuwStj56WZLiC_e++)
mc_V1pxxydYEnWVVi3QKesjvf[mc_VQiKC_sK6bhBdy51ifHSOG[pm__lqjegyKuwStj56WZLiC_e]
]=mc__CLRBwg4eOSEiqHPYKDedF;mc_F4Nt2yaY74_FXL9Jz1UHgb=
mc_kwrB3ZoKf7OufTHWaHJV7a;for(mc_kyp6uAyJE40UVuAQNEYzS1=
mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a];mc_kyp6uAyJE40UVuAQNEYzS1
!= -1;){mc__suOgr_4PeCIZi_uhoSVwf=(mc__Mwijnrb0M46cT7T_bvxpH[
mc_kyp6uAyJE40UVuAQNEYzS1]==mc_kZvatJe9hBO2aLrboC3gGO)&&(
mc_VGFqTyNi4g4A_yWCFVUz8v[mc_kyp6uAyJE40UVuAQNEYzS1]==
mc__1s1WFrNXhKmXeQbW0gziC);for(pm__lqjegyKuwStj56WZLiC_e=
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1]+1;
mc__suOgr_4PeCIZi_uhoSVwf&&pm__lqjegyKuwStj56WZLiC_e<=
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1]+mc_kZvatJe9hBO2aLrboC3gGO
-1;pm__lqjegyKuwStj56WZLiC_e++){if(mc_V1pxxydYEnWVVi3QKesjvf[
mc_VQiKC_sK6bhBdy51ifHSOG[pm__lqjegyKuwStj56WZLiC_e]]!=
mc__CLRBwg4eOSEiqHPYKDedF)mc__suOgr_4PeCIZi_uhoSVwf=0;}if(
mc__suOgr_4PeCIZi_uhoSVwf){mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1
]=(-(mc_kwrB3ZoKf7OufTHWaHJV7a)-2);mc_kU7ggFH4OMWpai03C_e14O[
mc_kwrB3ZoKf7OufTHWaHJV7a]+=mc_kU7ggFH4OMWpai03C_e14O[
mc_kyp6uAyJE40UVuAQNEYzS1];mc_kU7ggFH4OMWpai03C_e14O[mc_kyp6uAyJE40UVuAQNEYzS1
]=0;mc_VGFqTyNi4g4A_yWCFVUz8v[mc_kyp6uAyJE40UVuAQNEYzS1]= -1;
mc_kyp6uAyJE40UVuAQNEYzS1=mc_FTf2iFFdsgK3hewKsMgEx4[mc_kyp6uAyJE40UVuAQNEYzS1]
;mc_FTf2iFFdsgK3hewKsMgEx4[mc_F4Nt2yaY74_FXL9Jz1UHgb]=
mc_kyp6uAyJE40UVuAQNEYzS1;}else{mc_F4Nt2yaY74_FXL9Jz1UHgb=
mc_kyp6uAyJE40UVuAQNEYzS1;mc_kyp6uAyJE40UVuAQNEYzS1=mc_FTf2iFFdsgK3hewKsMgEx4[
mc_kyp6uAyJE40UVuAQNEYzS1];}}}}for(pm__lqjegyKuwStj56WZLiC_e=
mc_FR9ceqZ3mNCacyybeXDg1S,mc_knuzqmrfEfp0W1w1cnHjxI=mc_FR9ceqZ3mNCacyybeXDg1S;
mc_knuzqmrfEfp0W1w1cnHjxI<mc___GqWtOKIc8EcP1QpXfUOa;mc_knuzqmrfEfp0W1w1cnHjxI
++){mc_kwrB3ZoKf7OufTHWaHJV7a=mc_VQiKC_sK6bhBdy51ifHSOG[
mc_knuzqmrfEfp0W1w1cnHjxI];if((mc_VoKDVQkmDo8J_qCjvSHdi7= -
mc_kU7ggFH4OMWpai03C_e14O[mc_kwrB3ZoKf7OufTHWaHJV7a])<=0)continue;
mc_kU7ggFH4OMWpai03C_e14O[mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_VoKDVQkmDo8J_qCjvSHdi7
;mc_F32Ql82vv6pW_PYIdpkFQ0=mc_kI0mjAHPXNSe_5d7sQlfnN[mc_kwrB3ZoKf7OufTHWaHJV7a
]+mc_V5hmnKYoJxtYeXsPLFw9Dm-mc_VoKDVQkmDo8J_qCjvSHdi7;
mc_F32Ql82vv6pW_PYIdpkFQ0=(((mc_F32Ql82vv6pW_PYIdpkFQ0)<(n-
mc_kJg_DQxVlw4ChDUQlrBLIp-mc_VoKDVQkmDo8J_qCjvSHdi7))?(
mc_F32Ql82vv6pW_PYIdpkFQ0):(n-mc_kJg_DQxVlw4ChDUQlrBLIp-
mc_VoKDVQkmDo8J_qCjvSHdi7));if(mc_FcKez189ghKAYyDjWA9v5n[
mc_F32Ql82vv6pW_PYIdpkFQ0]!= -1)mc__s9c11FV6MCacH_iL7euSO[
mc_FcKez189ghKAYyDjWA9v5n[mc_F32Ql82vv6pW_PYIdpkFQ0]]=
mc_kwrB3ZoKf7OufTHWaHJV7a;mc_FTf2iFFdsgK3hewKsMgEx4[mc_kwrB3ZoKf7OufTHWaHJV7a]
=mc_FcKez189ghKAYyDjWA9v5n[mc_F32Ql82vv6pW_PYIdpkFQ0];
mc__s9c11FV6MCacH_iL7euSO[mc_kwrB3ZoKf7OufTHWaHJV7a]= -1;
mc_FcKez189ghKAYyDjWA9v5n[mc_F32Ql82vv6pW_PYIdpkFQ0]=mc_kwrB3ZoKf7OufTHWaHJV7a
;mc_kprk4TF6z6WpduVVli_Ph2=(((mc_kprk4TF6z6WpduVVli_Ph2)<(
mc_F32Ql82vv6pW_PYIdpkFQ0))?(mc_kprk4TF6z6WpduVVli_Ph2):(
mc_F32Ql82vv6pW_PYIdpkFQ0));mc_kI0mjAHPXNSe_5d7sQlfnN[
mc_kwrB3ZoKf7OufTHWaHJV7a]=mc_F32Ql82vv6pW_PYIdpkFQ0;mc_VQiKC_sK6bhBdy51ifHSOG
[pm__lqjegyKuwStj56WZLiC_e++]=mc_kwrB3ZoKf7OufTHWaHJV7a;}
mc_kU7ggFH4OMWpai03C_e14O[mc_V2__YrimeI4E_yWnhKofpy]=mc_V8FxTUVKviGuV9235TCBP_
;if((mc__Mwijnrb0M46cT7T_bvxpH[mc_V2__YrimeI4E_yWnhKofpy]=
pm__lqjegyKuwStj56WZLiC_e-mc_FR9ceqZ3mNCacyybeXDg1S)==0){
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_V2__YrimeI4E_yWnhKofpy]= -1;
mc_V1pxxydYEnWVVi3QKesjvf[mc_V2__YrimeI4E_yWnhKofpy]=0;}if(
mc__eEWUtjzzs_lh56__gM9HC!=0)mc_FypnHlhKDX_h_qv0Oovb82=
pm__lqjegyKuwStj56WZLiC_e;}for(mc_kwrB3ZoKf7OufTHWaHJV7a=0;
mc_kwrB3ZoKf7OufTHWaHJV7a<n;mc_kwrB3ZoKf7OufTHWaHJV7a++)
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a]=(-(
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kwrB3ZoKf7OufTHWaHJV7a])-2);for(
mc_kyp6uAyJE40UVuAQNEYzS1=0;mc_kyp6uAyJE40UVuAQNEYzS1<=n;
mc_kyp6uAyJE40UVuAQNEYzS1++)mc_FcKez189ghKAYyDjWA9v5n[
mc_kyp6uAyJE40UVuAQNEYzS1]= -1;for(mc_kyp6uAyJE40UVuAQNEYzS1=n;
mc_kyp6uAyJE40UVuAQNEYzS1>=0;mc_kyp6uAyJE40UVuAQNEYzS1--){if(
mc_kU7ggFH4OMWpai03C_e14O[mc_kyp6uAyJE40UVuAQNEYzS1]>0)continue;
mc_FTf2iFFdsgK3hewKsMgEx4[mc_kyp6uAyJE40UVuAQNEYzS1]=mc_FcKez189ghKAYyDjWA9v5n
[mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1]];
mc_FcKez189ghKAYyDjWA9v5n[mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_kyp6uAyJE40UVuAQNEYzS1]
]=mc_kyp6uAyJE40UVuAQNEYzS1;}for(mc_FCMoPwLeYFCfherwNS2L8C=n;
mc_FCMoPwLeYFCfherwNS2L8C>=0;mc_FCMoPwLeYFCfherwNS2L8C--){if(
mc_kU7ggFH4OMWpai03C_e14O[mc_FCMoPwLeYFCfherwNS2L8C]<=0)continue;if(
mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_FCMoPwLeYFCfherwNS2L8C]!= -1){
mc_FTf2iFFdsgK3hewKsMgEx4[mc_FCMoPwLeYFCfherwNS2L8C]=mc_FcKez189ghKAYyDjWA9v5n
[mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_FCMoPwLeYFCfherwNS2L8C]];
mc_FcKez189ghKAYyDjWA9v5n[mc_k7NnK4S2Nx0Oc1_SgnTsdQ[mc_FCMoPwLeYFCfherwNS2L8C]
]=mc_FCMoPwLeYFCfherwNS2L8C;}}for(mc_V2__YrimeI4E_yWnhKofpy=0,
mc_kwrB3ZoKf7OufTHWaHJV7a=0;mc_kwrB3ZoKf7OufTHWaHJV7a<=n;
mc_kwrB3ZoKf7OufTHWaHJV7a++){if(mc_k7NnK4S2Nx0Oc1_SgnTsdQ[
mc_kwrB3ZoKf7OufTHWaHJV7a]== -1)mc_V2__YrimeI4E_yWnhKofpy=
mc_Fx2UoNYY4W0WY5iaMITghy(mc_kwrB3ZoKf7OufTHWaHJV7a,mc_V2__YrimeI4E_yWnhKofpy,
mc_FcKez189ghKAYyDjWA9v5n,mc_FTf2iFFdsgK3hewKsMgEx4,mc_FZH6zKAr7oO3jijhKSuiBZ,
mc_V1pxxydYEnWVVi3QKesjvf);}return(mc_Ff7NuTFKk3OCYDKMqomZ1z(
mc_FZH6zKAr7oO3jijhKSuiBZ,mc_FStFcQlyAJ_dVy4kGZXBPQ,mc_F5Ms7XlOr2OXjyocf4hGw2,
1));}
