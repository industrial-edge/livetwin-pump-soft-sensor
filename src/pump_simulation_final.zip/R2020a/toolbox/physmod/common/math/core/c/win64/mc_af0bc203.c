#include "pm_std.h"
#include "pm_std.h"
#include "mc_std.h"
#include "mc_std.h"
void mc_Fuhi5y7GCg0reqAEm1r_l_(boolean_T mc__BdKVTewIl8TaXwgBW0hvv);boolean_T
mc_FfedxnfpDwWSdTfkUMENH5(void);static boolean_T mc_VRpKvXcVHHSGdiv8MDZfm2=
false;void mc_Fuhi5y7GCg0reqAEm1r_l_(boolean_T mc__BdKVTewIl8TaXwgBW0hvv){
mc_VRpKvXcVHHSGdiv8MDZfm2=mc__BdKVTewIl8TaXwgBW0hvv;}boolean_T
mc_FfedxnfpDwWSdTfkUMENH5(void){return mc_VRpKvXcVHHSGdiv8MDZfm2;}
