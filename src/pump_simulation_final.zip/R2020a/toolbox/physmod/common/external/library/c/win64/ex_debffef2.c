#include "pm_std.h"
#include "lang_std.h"
#include "external_std.h"
real_T ex_kpX___S1Lgx3hu0ti95uMw(const real_T*a,const size_t n);real_T
ex_VCMYZqH7FzWLWPHooBByoI(const real_T x);real_T*ex_VQMmQUcKA3_3ei3Owj7WVV(
const real_T*x);size_t*ex__ge8CPdYTqKVfmxfN0MdXT(const size_t*x);void
ex_ktEh0_dPE7WMZaXpgviZfL(real_T*fx1,real_T*ex__rg5CXJeg_Cndu5WDoxbMl,real_T*
ex_V5xxz05F7a_ihqj30K8FAv,real_T*ex_FNXAh_ftg_KpWeXlYDyRqE,const real_T*x1,
const real_T*f,const size_t n1,const size_t n2,const size_t n3,const size_t n4
,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH
,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT
,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45
,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn
,const size_t ex__dZ6arJEU5pmV9XKy8etwi,const size_t ex_VvovjV_Yc_G4fP1XodrLft
,const size_t ex_VhUgI4c0k9GOgm8dFTThdK,const size_t ex_Fsdzbs_wz00cfyfchwr6K7
,const real_T ex_V4NyKkWjXNKyiujQkyTHSS);void ex_VKUiWhgLteGl_1sCHRJXum(real_T
*ex_k8zBiCVRtSWw_L3ohL9ZU6,real_T*ex__q3Je3USIpxhYaV_bmlNgE,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF);void ex_F7_9Sgo0sqlceT8kkrDtm9(real_T*
ex_kESK0x0mPXxyfXNDYQuNSo,real_T*ex__idLDQm5dX_uePEg9ek_dK,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT,const size_t
ex_VTVqjDxUr989h9kcIs8Z9k,const size_t ex_Fklov8agSChIfPNAP5Ja45,const size_t
ex_kuuoJqthi7CXc5HX6B4l4u,const size_t ex_F_O8atNKby42ZPR5omsaZn,const size_t
ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t ex__Et5EUn_AfCGcaoPYM3rE7,const size_t
ex_VRc9H9oEh84hXu9Yu4okxd,const size_t ex__vFO6imE0nOcdTAyK5nWZf,const size_t
ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t ex_k64KfxW_YeCBd1Jcztnal5,const size_t
ex_FpCuD8p2g1ldYupGLDualI,const size_t ex_F4NwsNKf_S_ubm278AmjEt,const size_t
ex_VzS__hA47OtneLeQmJKhJU,const size_t ex_VseJVSrhmHl_fHMdqZQUoK,const size_t
ex__zov1f51H_xVZDV3hSAwLo,const size_t ex__UCiJ_ovpi8viepU66XSz1,const real_T
ex_V4NyKkWjXNKyiujQkyTHSS,const real_T ex__QgqlEW2f18scLxPhDEnMF,const real_T
ex__yrlSbVOXjWXaTMEdN9cIu);void ex_Futd5IPo6_Sea16WtbGVmf(real_T*
ex__nq35K78gNGYiPqAi6FlY1,real_T*ex_k7clpQTkJip2cDihM27xMo,const real_T*
ex_V5xxz05F7a_ihqj30K8FAv,const real_T*ex__rg5CXJeg_Cndu5WDoxbMl,const real_T*
ex_FnljSwbMX3SPj5etZa8_lO,const real_T*ex__nVSfRrp1Ld7fuuZg1ACm0,const real_T*
ex__4uaYPi3B7txZPrRD2z8ek,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT,const size_t ex_VTVqjDxUr989h9kcIs8Z9k,const size_t
ex_Fklov8agSChIfPNAP5Ja45,const size_t ex_kuuoJqthi7CXc5HX6B4l4u,const size_t
ex_F_O8atNKby42ZPR5omsaZn,const size_t ex_FEpQvc7eQhxoY1eyOlzQgC,const size_t
ex__Et5EUn_AfCGcaoPYM3rE7,const size_t ex_VRc9H9oEh84hXu9Yu4okxd,const size_t
ex__vFO6imE0nOcdTAyK5nWZf,const size_t ex_VRPFkIFFnYS8jTEIvSRCk8,const size_t
ex_k64KfxW_YeCBd1Jcztnal5,const size_t ex_FpCuD8p2g1ldYupGLDualI,const size_t
ex_F4NwsNKf_S_ubm278AmjEt,const size_t ex_VzS__hA47OtneLeQmJKhJU,const size_t
ex_VseJVSrhmHl_fHMdqZQUoK,const size_t ex__zov1f51H_xVZDV3hSAwLo,const size_t
ex__UCiJ_ovpi8viepU66XSz1,const size_t ex_FDTDXUQhgm_eYmdJ8sNRVZ,const size_t
ex_VlNl_tKLFzxvYHI0dZ9wzf,const size_t ex_kiGZSX33fPpmaucBO5il15,const size_t
ex__1tnMVPyaKpZeawGCX2ExG,const real_T ex_V4NyKkWjXNKyiujQkyTHSS,const real_T
ex__QgqlEW2f18scLxPhDEnMF,const real_T ex__yrlSbVOXjWXaTMEdN9cIu,const real_T
ex_F1sFV5GwlJdShuwH_gb9cU);size_t ex_F0HBEJ7qD9OkfDK6FdP9lf(real_T*basis,
real_T*basisDerivative,const real_T*x,const size_t n,const real_T t,const
size_t ex_F_tm5fod4xxuguhS49BSQm);size_t ex_FSBp3lkv5gpCXL2yT9vLNh(const real_T
*x,const size_t n,const real_T t);void ex_kGRJvwU4WMthWL53sjRCpO(real_T*
ex_F2l4p_g4sn02huHNflQjMH,const size_t n1,const size_t n2,const size_t n3,
const size_t n4,const size_t ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t
ex_VSy0VE52bQSafuDoXEVasH,const size_t ex_keXUKEfwn7pKd9Pw_tgV73,const size_t
ex_FZiPJehSX8hycyX0BLEeoT);void ex_FtfBZE2kLGxyWamCvlRfeQ(real_T*x,real_T*f,
const size_t n);void ex_F4LajttG6uGtbXBJgUNQpW(real_T*x1,real_T*x2,real_T*f,
const size_t n1,const size_t n2);void ex_kIBgcKPC9nhchTKovcabSa(real_T*x1,
real_T*x2,real_T*x3,real_T*f,const size_t n1,const size_t n2,const size_t n3);
void ex_F_6wSEEsvm_1cTAuvwDt9B(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*
f,const size_t n1,const size_t n2,const size_t n3,const size_t n4);
#include "pm_std.h"
#include "lang_std.h"
#include "string.h"
#include "stddef.h"
void ex_kdH1Hb3ZR9_6cqIDW1RDok(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const
size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const
double*ex_VsAv95vpmFp3i1E54_unM9,double*work1,size_t*work2,double*
ex_koSOkfGA3wCTgD7UMHzVC6);void ex_Vt43VeczGdCdVuEpZQh81F(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t
ex__Qhq8A0DwpCxayd3Wx4meP,double*ex__g9rIuQqKUWtZastp1XFl9,size_t*
ex_ked9tdolvUCd_PP3XHAAJ5,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t
ex__NJXN1LXJ3dhZPDo3_p2LH,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_VUv5qERYa5OL_DZXviEVuZ(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*ex__DeeKqxVkgxqhHgsvRavsg
,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double*ex_kKG_5OBKXuhncyckTip21X);void
ex__I__tR3HVGtUdmAFtUcU_G(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const size_t
ex_F_tm5fod4xxuguhS49BSQm,double*ex_koSOkfGA3wCTgD7UMHzVC6,double**
ex_kKG_5OBKXuhncyckTip21X,double*work1,size_t*work2,const size_t
ex__NJXN1LXJ3dhZPDo3_p2LH,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_k3a7efHitoCaVqpYN7YToy(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*ex__DeeKqxVkgxqhHgsvRavsg
,size_t*ex_Vic4f_t1_8lMdPxTHOuua8);void ex_kEWp_Qwr9TpuV5h0iCW4f_(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const double*ex_VsAv95vpmFp3i1E54_unM9,double*work1
,size_t*work2,double*ex_koSOkfGA3wCTgD7UMHzVC6);void ex_Vs9jGA8_KnhLXD1GzoOLPW
(const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*x,const double*v,double*
ex__UNT5rIVeICNXTfUhGCl8W,double*ex_koSOkfGA3wCTgD7UMHzVC6);void
ex__KeFoQApKT8cgHlyO01BeY(const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*
x,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const
double*ex__DeeKqxVkgxqhHgsvRavsg,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double
*ex_F1rQUll_EnhbfeQZPiHn_s);void ex_FZZQ_zd6zHpHcqkvqQcKeE(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,size_t*
ex_kklNzzcIKMxNV52OR5eVxc,size_t*ex_Vk1Sst4gGPtFjylmh_eoTy,size_t*
ex_kbqze1jjAT_jfXlAX_BPu5);void ex_VzBWCTabh80jfiaToytNrB(const size_t
ex_V5LBNJCbhICNbmMG_hLaZ6,size_t*ex_FEl_KnkYLbOphi5ZGombgS,size_t*
ex_kbqze1jjAT_jfXlAX_BPu5);void ex_kAQl7CorwHpieefIkLdDbn(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,size_t*ex_kklNzzcIKMxNV52OR5eVxc,size_t*
ex_Vk1Sst4gGPtFjylmh_eoTy);size_t ex_FO1_qmvrJCdajiha0f8t_g(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH);size_t
ex_FYKXiobTtQ43ZiaA1coL20(const size_t ex__NJXN1LXJ3dhZPDo3_p2LH);void
ex_VPRwPLG3xi0jeD9oJbEfA_(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,size_t*ex_kklNzzcIKMxNV52OR5eVxc,size_t*
ex_Vk1Sst4gGPtFjylmh_eoTy);void ex_F4Ytgbl_Ex8CjPG1tYAR6T(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,size_t*ex_kklNzzcIKMxNV52OR5eVxc,size_t*
ex_Vk1Sst4gGPtFjylmh_eoTy);size_t ex__RCgSalFfyKnVen_XlbT_L(const size_t
ex_V5LBNJCbhICNbmMG_hLaZ6);size_t ex_FSNiYyUn_6OGZPhMmYpPun(const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B);void
ex_FJUlENJSohGphDc_Rf36LU(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,size_t*ex_kklNzzcIKMxNV52OR5eVxc,size_t*
ex_Vk1Sst4gGPtFjylmh_eoTy,size_t*ex_kbqze1jjAT_jfXlAX_BPu5);static void
ex_FcBoyAOGyQhIhHf_kb6OE_(real_T*fi,const real_T*basis1,const real_T*
basisDerivative1,const size_t bin1,const real_T*basis2,const real_T*
basisDerivative2,const size_t bin2,const real_T*basis3,const real_T*
basisDerivative3,const size_t bin3,const real_T*fx,const size_t n1,const size_t
n2,const size_t n3,const size_t ex_F_tm5fod4xxuguhS49BSQm,const boolean_T
ex_kMAXUIgm88xvaunhJ2st8X,const real_T*work1,const size_t*work2);static void
ex_FTfRmGUQPqlNaHvVdAUgIB(real_T*x1,real_T*x2,real_T*x3,real_T*fx,const real_T
*x1s,const real_T*x2s,const real_T*x3s,const real_T*fs,const size_t n1,const
size_t n2,const size_t n3);void tlu2_3d_akima_nearest_process(real_T*x1,real_T
*x2,real_T*x3,real_T*fx1,const real_T*x1s,const real_T*x2s,const real_T*x3s,
const real_T*fs,const size_t*n1,const size_t*n2,const size_t*n3){
ex_FTfRmGUQPqlNaHvVdAUgIB(x1,x2,x3,fx1,x1s,x2s,x3s,fs,*n1,*n2,*n3);}void
tlu2_3d_akima_nearest_process_custom_function_(void*out,const void*in){const
real_T*x1s=(const real_T*)((const void*const*)in)[0];const real_T*x2s=(const
real_T*)((const void*const*)in)[1];const real_T*x3s=(const real_T*)((const void
*const*)in)[2];const real_T*fs=(const real_T*)((const void*const*)in)[3];const
size_t*n1=(const size_t*)((const void*const*)in)[4];const size_t*n2=(const
size_t*)((const void*const*)in)[5];const size_t*n3=(const size_t*)((const void
*const*)in)[6];real_T*x1=(real_T*)((void**)out)[0];real_T*x2=(real_T*)((void**
)out)[1];real_T*x3=(real_T*)((void**)out)[2];real_T*fx=(real_T*)((void**)out)[
3];tlu2_3d_akima_nearest_process(x1,x2,x3,fx,x1s,x2s,x3s,fs,n1,n2,n3);}void
tlu2_3d_akima_linear_process(real_T*x1,real_T*x2,real_T*x3,real_T*fx1,const
real_T*x1s,const real_T*x2s,const real_T*x3s,const real_T*fs,const size_t*n1,
const size_t*n2,const size_t*n3){ex_FTfRmGUQPqlNaHvVdAUgIB(x1,x2,x3,fx1,x1s,
x2s,x3s,fs,*n1,*n2,*n3);}void tlu2_3d_akima_linear_process_custom_function_(
void*out,const void*in){const real_T*x1s=(const real_T*)((const void*const*)in
)[0];const real_T*x2s=(const real_T*)((const void*const*)in)[1];const real_T*
x3s=(const real_T*)((const void*const*)in)[2];const real_T*fs=(const real_T*)(
(const void*const*)in)[3];const size_t*n1=(const size_t*)((const void*const*)
in)[4];const size_t*n2=(const size_t*)((const void*const*)in)[5];const size_t*
n3=(const size_t*)((const void*const*)in)[6];real_T*x1=(real_T*)((void**)out)[
0];real_T*x2=(real_T*)((void**)out)[1];real_T*x3=(real_T*)((void**)out)[2];
real_T*fx=(real_T*)((void**)out)[3];tlu2_3d_akima_linear_process(x1,x2,x3,fx,
x1s,x2s,x3s,fs,n1,n2,n3);}static void ex_FTfRmGUQPqlNaHvVdAUgIB(real_T*x1,
real_T*x2,real_T*x3,real_T*ex_VorZCi5_B5tOa9oe3bnRf5,const real_T*x1s,const
real_T*x2s,const real_T*x3s,const real_T*fs,const size_t n1,const size_t n2,
const size_t n3){const size_t ex_F3nVSXkoDK8VeeL5OmY0_B=3;size_t
ex__jP7F4Fk5ExlWmUH2CnO0p[3];const real_T*ex_VToqGBrino_cYuTsjsb5G7[3];const
size_t n=n1*n2*n3;real_T*ex_VsAv95vpmFp3i1E54_unM9=pmf_malloc(n*sizeof(real_T)
);size_t ex_FzsezTJVFaKAhHt_a3UeWF;size_t ex_kdATsbeSp_x8_DV4Ry4QD0;size_t
ex_FP2u25405gSWeDgzM8AO0G;real_T*ex_V1PpSt9JShK3bL1Bw6asF1;size_t*
ex_VVfVnPxpzepMZXSq9ZSsjY;ex__jP7F4Fk5ExlWmUH2CnO0p[0]=n1;
ex__jP7F4Fk5ExlWmUH2CnO0p[1]=n2;ex__jP7F4Fk5ExlWmUH2CnO0p[2]=n3;
ex_VToqGBrino_cYuTsjsb5G7[0]=x1;ex_VToqGBrino_cYuTsjsb5G7[1]=x2;
ex_VToqGBrino_cYuTsjsb5G7[2]=x3;memcpy(x1,x1s,n1*sizeof(real_T));memcpy(x2,x2s
,n2*sizeof(real_T));memcpy(x3,x3s,n3*sizeof(real_T));memcpy(
ex_VsAv95vpmFp3i1E54_unM9,fs,n*sizeof(real_T));ex_kIBgcKPC9nhchTKovcabSa(x1,x2
,x3,ex_VsAv95vpmFp3i1E54_unM9,n1,n2,n3);ex_FJUlENJSohGphDc_Rf36LU(
ex_F3nVSXkoDK8VeeL5OmY0_B,ex__jP7F4Fk5ExlWmUH2CnO0p,&ex_FzsezTJVFaKAhHt_a3UeWF
,&ex_kdATsbeSp_x8_DV4Ry4QD0,&ex_FP2u25405gSWeDgzM8AO0G);
ex_V1PpSt9JShK3bL1Bw6asF1=pmf_malloc(ex_FzsezTJVFaKAhHt_a3UeWF*sizeof(real_T))
;ex_VVfVnPxpzepMZXSq9ZSsjY=pmf_malloc(ex_kdATsbeSp_x8_DV4Ry4QD0*sizeof(size_t)
);ex_kEWp_Qwr9TpuV5h0iCW4f_(ex_F3nVSXkoDK8VeeL5OmY0_B,
ex__jP7F4Fk5ExlWmUH2CnO0p,ex_VToqGBrino_cYuTsjsb5G7,ex_VsAv95vpmFp3i1E54_unM9,
&ex_V1PpSt9JShK3bL1Bw6asF1[0],&ex_VVfVnPxpzepMZXSq9ZSsjY[0],
ex_VQMmQUcKA3_3ei3Owj7WVV(ex_VorZCi5_B5tOa9oe3bnRf5));pmf_free(
ex_VsAv95vpmFp3i1E54_unM9);pmf_free(ex_V1PpSt9JShK3bL1Bw6asF1);pmf_free(
ex_VVfVnPxpzepMZXSq9ZSsjY);}void tlu2_3d_akima_nearest_value(real_T*fi,const
real_T*basis1,const real_T*basisDerivative1,const size_t*bin1,const real_T*
basis2,const real_T*basisDerivative2,const size_t*bin2,const real_T*basis3,
const real_T*basisDerivative3,const size_t*bin3,const real_T*fx,const size_t*
n1,const size_t*n2,const size_t*n3,const real_T*work1,const size_t*work2){
ex_FcBoyAOGyQhIhHf_kb6OE_(fi,basis1,basisDerivative1,*bin1,basis2,
basisDerivative2,*bin2,basis3,basisDerivative3,*bin3,fx,*n1,*n2,*n3,0,false,
work1,work2);}void tlu2_3d_akima_nearest_value_custom_function_(void*out,const
void*in){const real_T*basis1=(const real_T*)((const void*const*)in)[0];const
real_T*basisDerivative1=(const real_T*)((const void*const*)in)[1];const size_t
*bin1=(const size_t*)((const void*const*)in)[2];const real_T*basis2=(const
real_T*)((const void*const*)in)[3];const real_T*basisDerivative2=(const real_T
*)((const void*const*)in)[4];const size_t*bin2=(const size_t*)((const void*
const*)in)[5];const real_T*basis3=(const real_T*)((const void*const*)in)[6];
const real_T*basisDerivative3=(const real_T*)((const void*const*)in)[7];const
size_t*bin3=(const size_t*)((const void*const*)in)[8];const real_T*fx=(const
real_T*)((const void*const*)in)[9];const size_t*n1=(const size_t*)((const void
*const*)in)[10];const size_t*n2=(const size_t*)((const void*const*)in)[11];
const size_t*n3=(const size_t*)((const void*const*)in)[12];const real_T*work1=
(const real_T*)((const void*const*)in)[13];const size_t*work2=(const size_t*)(
(const void*const*)in)[14];real_T*fi=(real_T*)out;tlu2_3d_akima_nearest_value(
fi,basis1,basisDerivative1,bin1,basis2,basisDerivative2,bin2,basis3,
basisDerivative3,bin3,fx,n1,n2,n3,work1,work2);}void tlu2_3d_akima_linear_value
(real_T*fi,const real_T*basis1,const real_T*basisDerivative1,const size_t*bin1
,const real_T*basis2,const real_T*basisDerivative2,const size_t*bin2,const
real_T*basis3,const real_T*basisDerivative3,const size_t*bin3,const real_T*fx1
,const size_t*n1,const size_t*n2,const size_t*n3,const real_T*work1,const
size_t*work2){ex_FcBoyAOGyQhIhHf_kb6OE_(fi,basis1,basisDerivative1,*bin1,
basis2,basisDerivative2,*bin2,basis3,basisDerivative3,*bin3,fx1,*n1,*n2,*n3,1,
false,work1,work2);}void tlu2_3d_akima_linear_value_custom_function_(void*out,
const void*in){const real_T*basis1=(const real_T*)((const void*const*)in)[0];
const real_T*basisDerivative1=(const real_T*)((const void*const*)in)[1];const
size_t*bin1=(const size_t*)((const void*const*)in)[2];const real_T*basis2=(
const real_T*)((const void*const*)in)[3];const real_T*basisDerivative2=(const
real_T*)((const void*const*)in)[4];const size_t*bin2=(const size_t*)((const
void*const*)in)[5];const real_T*basis3=(const real_T*)((const void*const*)in)[
6];const real_T*basisDerivative3=(const real_T*)((const void*const*)in)[7];
const size_t*bin3=(const size_t*)((const void*const*)in)[8];const real_T*fx=(
const real_T*)((const void*const*)in)[9];const size_t*n1=(const size_t*)((
const void*const*)in)[10];const size_t*n2=(const size_t*)((const void*const*)
in)[11];const size_t*n3=(const size_t*)((const void*const*)in)[12];const real_T
*work1=(const real_T*)((const void*const*)in)[13];const size_t*work2=(const
size_t*)((const void*const*)in)[14];real_T*fi=(real_T*)out;
tlu2_3d_akima_linear_value(fi,basis1,basisDerivative1,bin1,basis2,
basisDerivative2,bin2,basis3,basisDerivative3,bin3,fx,n1,n2,n3,work1,work2);}
void tlu2_3d_akima_nearest_derivatives(real_T*fi,const real_T*basis1,const
real_T*basisDerivative1,const size_t*bin1,const real_T*basis2,const real_T*
basisDerivative2,const size_t*bin2,const real_T*basis3,const real_T*
basisDerivative3,const size_t*bin3,const real_T*fx1,const size_t*n1,const
size_t*n2,const size_t*n3,const real_T*work1,const size_t*work2){
ex_FcBoyAOGyQhIhHf_kb6OE_(fi,basis1,basisDerivative1,*bin1,basis2,
basisDerivative2,*bin2,basis3,basisDerivative3,*bin3,fx1,*n1,*n2,*n3,0,true,
work1,work2);}void tlu2_3d_akima_nearest_derivatives_custom_function_(void*out
,const void*in){const real_T*basis1=(const real_T*)((const void*const*)in)[0];
const real_T*basisDerivative1=(const real_T*)((const void*const*)in)[1];const
size_t*bin1=(const size_t*)((const void*const*)in)[2];const real_T*basis2=(
const real_T*)((const void*const*)in)[3];const real_T*basisDerivative2=(const
real_T*)((const void*const*)in)[4];const size_t*bin2=(const size_t*)((const
void*const*)in)[5];const real_T*basis3=(const real_T*)((const void*const*)in)[
6];const real_T*basisDerivative3=(const real_T*)((const void*const*)in)[7];
const size_t*bin3=(const size_t*)((const void*const*)in)[8];const real_T*fx=(
const real_T*)((const void*const*)in)[9];const size_t*n1=(const size_t*)((
const void*const*)in)[10];const size_t*n2=(const size_t*)((const void*const*)
in)[11];const size_t*n3=(const size_t*)((const void*const*)in)[12];const real_T
*work1=(const real_T*)((const void*const*)in)[13];const size_t*work2=(const
size_t*)((const void*const*)in)[14];real_T*fi=(real_T*)out;
tlu2_3d_akima_nearest_derivatives(fi,basis1,basisDerivative1,bin1,basis2,
basisDerivative2,bin2,basis3,basisDerivative3,bin3,fx,n1,n2,n3,work1,work2);}
void tlu2_3d_akima_linear_derivatives(real_T*fi,const real_T*basis1,const
real_T*basisDerivative1,const size_t*bin1,const real_T*basis2,const real_T*
basisDerivative2,const size_t*bin2,const real_T*basis3,const real_T*
basisDerivative3,const size_t*bin3,const real_T*fx1,const size_t*n1,const
size_t*n2,const size_t*n3,const real_T*work1,const size_t*work2){
ex_FcBoyAOGyQhIhHf_kb6OE_(fi,basis1,basisDerivative1,*bin1,basis2,
basisDerivative2,*bin2,basis3,basisDerivative3,*bin3,fx1,*n1,*n2,*n3,1,true,
work1,work2);}void tlu2_3d_akima_linear_derivatives_custom_function_(void*out,
const void*in){const real_T*basis1=(const real_T*)((const void*const*)in)[0];
const real_T*basisDerivative1=(const real_T*)((const void*const*)in)[1];const
size_t*bin1=(const size_t*)((const void*const*)in)[2];const real_T*basis2=(
const real_T*)((const void*const*)in)[3];const real_T*basisDerivative2=(const
real_T*)((const void*const*)in)[4];const size_t*bin2=(const size_t*)((const
void*const*)in)[5];const real_T*basis3=(const real_T*)((const void*const*)in)[
6];const real_T*basisDerivative3=(const real_T*)((const void*const*)in)[7];
const size_t*bin3=(const size_t*)((const void*const*)in)[8];const real_T*fx=(
const real_T*)((const void*const*)in)[9];const size_t*n1=(const size_t*)((
const void*const*)in)[10];const size_t*n2=(const size_t*)((const void*const*)
in)[11];const size_t*n3=(const size_t*)((const void*const*)in)[12];const real_T
*work1=(const real_T*)((const void*const*)in)[13];const size_t*work2=(const
size_t*)((const void*const*)in)[14];real_T*fi=(real_T*)out;
tlu2_3d_akima_linear_derivatives(fi,basis1,basisDerivative1,bin1,basis2,
basisDerivative2,bin2,basis3,basisDerivative3,bin3,fx,n1,n2,n3,work1,work2);}
static void ex_FcBoyAOGyQhIhHf_kb6OE_(real_T*fi,const real_T*
ex_Vl61InPOzylYgiebES6ELs,const real_T*ex_FMWNpeuUHEGegPasHZICvW,const size_t
bin1,const real_T*ex_kB9XB9hzwwW7Vu4shvxxya,const real_T*
ex_FztrEwsuKLWtXHBYTAffgh,const size_t bin2,const real_T*
ex__laKwhSBF10XcXh2QbGZxl,const real_T*ex_k_lASBgCHSpV_ixifFx5vQ,const size_t
bin3,const real_T*fx,const size_t n1,const size_t n2,const size_t n3,const
size_t ex_F_tm5fod4xxuguhS49BSQm,const boolean_T ex_kMAXUIgm88xvaunhJ2st8X,
const real_T*work1,const size_t*work2){const size_t n=n1*n2*n3;const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B=3;size_t ex__jP7F4Fk5ExlWmUH2CnO0p[3];const real_T**
ex_kB4aOAnByNCbf5JZPcoQy5=0;const real_T**ex_FNyrrBDfkJhIjyNSa2fMBz=0;const
size_t ex__NJXN1LXJ3dhZPDo3_p2LH=1;real_T*basis[3];real_T*basisDerivative1[3];
real_T*basisDerivative2[3];real_T*basisDerivative3[3];size_t
ex__I2IEgdElv80cD1Kv0uRpM[1];size_t ex__bBTzednxRh0WT2E2HNmTx[1];size_t
ex_VTU42MKlyy4vayjUvcNV_7[1];size_t*ex_Vic4f_t1_8lMdPxTHOuua8[3];real_T*
ex_V1PpSt9JShK3bL1Bw6asF1=ex_VQMmQUcKA3_3ei3Owj7WVV(work1);size_t*
ex_VVfVnPxpzepMZXSq9ZSsjY=ex__ge8CPdYTqKVfmxfN0MdXT(work2);real_T*
ex_VorZCi5_B5tOa9oe3bnRf5=ex_VQMmQUcKA3_3ei3Owj7WVV(fx);
ex__jP7F4Fk5ExlWmUH2CnO0p[0]=n1;ex__jP7F4Fk5ExlWmUH2CnO0p[1]=n2;
ex__jP7F4Fk5ExlWmUH2CnO0p[2]=n3;basis[0]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_Vl61InPOzylYgiebES6ELs);basis[1]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_kB9XB9hzwwW7Vu4shvxxya);basis[2]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex__laKwhSBF10XcXh2QbGZxl);basisDerivative1[0]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_FMWNpeuUHEGegPasHZICvW);basisDerivative1[1]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_kB9XB9hzwwW7Vu4shvxxya);basisDerivative1[2]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex__laKwhSBF10XcXh2QbGZxl);basisDerivative2[0]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_Vl61InPOzylYgiebES6ELs);basisDerivative2[1]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_FztrEwsuKLWtXHBYTAffgh);basisDerivative2[2]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex__laKwhSBF10XcXh2QbGZxl);basisDerivative3[0]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_Vl61InPOzylYgiebES6ELs);basisDerivative3[1]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_kB9XB9hzwwW7Vu4shvxxya);basisDerivative3[2]=ex_VQMmQUcKA3_3ei3Owj7WVV(
ex_k_lASBgCHSpV_ixifFx5vQ);ex__I2IEgdElv80cD1Kv0uRpM[0]=bin1;
ex__bBTzednxRh0WT2E2HNmTx[0]=bin2;ex_VTU42MKlyy4vayjUvcNV_7[0]=bin3;
ex_Vic4f_t1_8lMdPxTHOuua8[0]=ex__I2IEgdElv80cD1Kv0uRpM;
ex_Vic4f_t1_8lMdPxTHOuua8[1]=ex__bBTzednxRh0WT2E2HNmTx;
ex_Vic4f_t1_8lMdPxTHOuua8[2]=ex_VTU42MKlyy4vayjUvcNV_7;if(!
ex_kMAXUIgm88xvaunhJ2st8X){ex__I__tR3HVGtUdmAFtUcU_G(ex_F3nVSXkoDK8VeeL5OmY0_B
,ex__jP7F4Fk5ExlWmUH2CnO0p,ex_kB4aOAnByNCbf5JZPcoQy5,ex_F_tm5fod4xxuguhS49BSQm
+1,&ex_VorZCi5_B5tOa9oe3bnRf5[0],basis,&ex_V1PpSt9JShK3bL1Bw6asF1[0],&
ex_VVfVnPxpzepMZXSq9ZSsjY[0],ex__NJXN1LXJ3dhZPDo3_p2LH,
ex_FNyrrBDfkJhIjyNSa2fMBz,ex_Vic4f_t1_8lMdPxTHOuua8,&fi[0]);}else{
ex__I__tR3HVGtUdmAFtUcU_G(ex_F3nVSXkoDK8VeeL5OmY0_B,ex__jP7F4Fk5ExlWmUH2CnO0p,
ex_kB4aOAnByNCbf5JZPcoQy5,ex_F_tm5fod4xxuguhS49BSQm+1,&
ex_VorZCi5_B5tOa9oe3bnRf5[0],basisDerivative1,&ex_V1PpSt9JShK3bL1Bw6asF1[0],&
ex_VVfVnPxpzepMZXSq9ZSsjY[0],ex__NJXN1LXJ3dhZPDo3_p2LH,
ex_FNyrrBDfkJhIjyNSa2fMBz,ex_Vic4f_t1_8lMdPxTHOuua8,&fi[0]);
ex__I__tR3HVGtUdmAFtUcU_G(ex_F3nVSXkoDK8VeeL5OmY0_B,ex__jP7F4Fk5ExlWmUH2CnO0p,
ex_kB4aOAnByNCbf5JZPcoQy5,ex_F_tm5fod4xxuguhS49BSQm+1,&
ex_VorZCi5_B5tOa9oe3bnRf5[0],basisDerivative2,&ex_V1PpSt9JShK3bL1Bw6asF1[0],&
ex_VVfVnPxpzepMZXSq9ZSsjY[0],ex__NJXN1LXJ3dhZPDo3_p2LH,
ex_FNyrrBDfkJhIjyNSa2fMBz,ex_Vic4f_t1_8lMdPxTHOuua8,&fi[1]);
ex__I__tR3HVGtUdmAFtUcU_G(ex_F3nVSXkoDK8VeeL5OmY0_B,ex__jP7F4Fk5ExlWmUH2CnO0p,
ex_kB4aOAnByNCbf5JZPcoQy5,ex_F_tm5fod4xxuguhS49BSQm+1,&
ex_VorZCi5_B5tOa9oe3bnRf5[0],basisDerivative3,&ex_V1PpSt9JShK3bL1Bw6asF1[0],&
ex_VVfVnPxpzepMZXSq9ZSsjY[0],ex__NJXN1LXJ3dhZPDo3_p2LH,
ex_FNyrrBDfkJhIjyNSa2fMBz,ex_Vic4f_t1_8lMdPxTHOuua8,&fi[2]);}}
