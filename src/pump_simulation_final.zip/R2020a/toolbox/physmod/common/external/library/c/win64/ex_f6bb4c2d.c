#include "math.h"
#include "stddef.h"
double ex_V7K1AhcbGYxBXLLX4NJH5f(const double a);size_t
ex_VP1AIhBqhr8UjPFzg_S70e(const double*x,const size_t n,const double
ex__DeeKqxVkgxqhHgsvRavsg);size_t ex__h_X9bmrQK0Rg9mXMtm6iz(const double*x,
const size_t ex_V5LBNJCbhICNbmMG_hLaZ6);size_t ex___xN3n8gXlhcdqFMCs70RT(const
double**ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const
size_t ex_F3nVSXkoDK8VeeL5OmY0_B);double ex_V7K1AhcbGYxBXLLX4NJH5f(const double
a){return(double)fabs((double)a);}size_t ex_VP1AIhBqhr8UjPFzg_S70e(const double
*x,const size_t n,const double ex__DeeKqxVkgxqhHgsvRavsg){size_t b;if(x[n-2]<=
ex__DeeKqxVkgxqhHgsvRavsg){b=n-2;}else{b=1;while(x[b]<
ex__DeeKqxVkgxqhHgsvRavsg){++b;}--b;}return b;}size_t ex__h_X9bmrQK0Rg9mXMtm6iz
(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6){size_t
ex_Vr11O__h4iWxb97wIDFqlh,ex_FJlFrKJTlv_ThaUlVMpivJ;ex_Vr11O__h4iWxb97wIDFqlh=
1;if(ex_V5LBNJCbhICNbmMG_hLaZ6<2){ex_Vr11O__h4iWxb97wIDFqlh=0;}else{for(
ex_FJlFrKJTlv_ThaUlVMpivJ=1;ex_FJlFrKJTlv_ThaUlVMpivJ<
ex_V5LBNJCbhICNbmMG_hLaZ6;++ex_FJlFrKJTlv_ThaUlVMpivJ){if(!(x[
ex_FJlFrKJTlv_ThaUlVMpivJ-1]<x[ex_FJlFrKJTlv_ThaUlVMpivJ])){
ex_Vr11O__h4iWxb97wIDFqlh=0;break;}}for(ex_FJlFrKJTlv_ThaUlVMpivJ=0;
ex_FJlFrKJTlv_ThaUlVMpivJ<ex_V5LBNJCbhICNbmMG_hLaZ6;++
ex_FJlFrKJTlv_ThaUlVMpivJ){if((x[ex_FJlFrKJTlv_ThaUlVMpivJ]-x[
ex_FJlFrKJTlv_ThaUlVMpivJ])!=(x[ex_FJlFrKJTlv_ThaUlVMpivJ]-x[
ex_FJlFrKJTlv_ThaUlVMpivJ])){ex_Vr11O__h4iWxb97wIDFqlh=0;break;}}}return
ex_Vr11O__h4iWxb97wIDFqlh;}size_t ex___xN3n8gXlhcdqFMCs70RT(const double**
ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B){size_t ex_Vr11O__h4iWxb97wIDFqlh,
ex_FEa9HpQub3K9X1Fkj0Fvl_;ex_Vr11O__h4iWxb97wIDFqlh=1;for(
ex_FEa9HpQub3K9X1Fkj0Fvl_=0;ex_FEa9HpQub3K9X1Fkj0Fvl_<
ex_F3nVSXkoDK8VeeL5OmY0_B;++ex_FEa9HpQub3K9X1Fkj0Fvl_){
ex_Vr11O__h4iWxb97wIDFqlh=ex__h_X9bmrQK0Rg9mXMtm6iz(ex_VToqGBrino_cYuTsjsb5G7[
ex_FEa9HpQub3K9X1Fkj0Fvl_],ex__jP7F4Fk5ExlWmUH2CnO0p[ex_FEa9HpQub3K9X1Fkj0Fvl_
]);if(ex_Vr11O__h4iWxb97wIDFqlh!=1){break;}}return ex_Vr11O__h4iWxb97wIDFqlh;}
