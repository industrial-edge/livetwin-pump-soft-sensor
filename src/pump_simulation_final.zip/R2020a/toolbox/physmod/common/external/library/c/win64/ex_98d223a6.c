#include "stddef.h"
void ex_kdH1Hb3ZR9_6cqIDW1RDok(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const
size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const
double*ex_VsAv95vpmFp3i1E54_unM9,double*work1,size_t*work2,double*
ex_koSOkfGA3wCTgD7UMHzVC6);void ex_Vt43VeczGdCdVuEpZQh81F(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t
ex__Qhq8A0DwpCxayd3Wx4meP,double*ex__g9rIuQqKUWtZastp1XFl9,size_t*
ex_ked9tdolvUCd_PP3XHAAJ5,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t
ex__NJXN1LXJ3dhZPDo3_p2LH,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_VUv5qERYa5OL_DZXviEVuZ(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*ex__DeeKqxVkgxqhHgsvRavsg
,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double*ex_kKG_5OBKXuhncyckTip21X);void
ex__I__tR3HVGtUdmAFtUcU_G(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const size_t
ex_F_tm5fod4xxuguhS49BSQm,double*ex_koSOkfGA3wCTgD7UMHzVC6,double**
ex_kKG_5OBKXuhncyckTip21X,double*work1,size_t*work2,const size_t
ex__NJXN1LXJ3dhZPDo3_p2LH,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_k3a7efHitoCaVqpYN7YToy(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*ex__DeeKqxVkgxqhHgsvRavsg
,size_t*ex_Vic4f_t1_8lMdPxTHOuua8);void ex_kEWp_Qwr9TpuV5h0iCW4f_(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const double*ex_VsAv95vpmFp3i1E54_unM9,double*work1
,size_t*work2,double*ex_koSOkfGA3wCTgD7UMHzVC6);void ex_Vs9jGA8_KnhLXD1GzoOLPW
(const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*x,const double*v,double*
ex__UNT5rIVeICNXTfUhGCl8W,double*ex_koSOkfGA3wCTgD7UMHzVC6);void
ex__KeFoQApKT8cgHlyO01BeY(const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*
x,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const
double*ex__DeeKqxVkgxqhHgsvRavsg,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double
*ex_F1rQUll_EnhbfeQZPiHn_s);void ex__e_Rvt1zKg_LiqW_Ljkdfe(const double**
ex_VToqGBrino_cYuTsjsb5G7,const double*ex_VsAv95vpmFp3i1E54_unM9,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,double*
ex_FjX_aej9XuC9jmyiw5QzyY,size_t*ex_ked9tdolvUCd_PP3XHAAJ5,double*
ex_koSOkfGA3wCTgD7UMHzVC6);void ex_kMdulA9uFAKeaDf3iz34v4(const double*x,const
double*v,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,double*
ex__UNT5rIVeICNXTfUhGCl8W,double*ex_koSOkfGA3wCTgD7UMHzVC6);void
ex_kUMpUuPKaDtphe_ZEm_2A_(const double**ex_VToqGBrino_cYuTsjsb5G7,const size_t
*ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t
ex_F_tm5fod4xxuguhS49BSQm,double*ex__g9rIuQqKUWtZastp1XFl9,size_t*
ex_ked9tdolvUCd_PP3XHAAJ5,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t
ex__Qhq8A0DwpCxayd3Wx4meP,const size_t ex__o3nHuxrYcSAfPDlW4I06H,const double*
*ex_keuqc0JkC8SQZLp7wSGmG6,size_t**ex_Vic4f_t1_8lMdPxTHOuua8,double**
ex_kNB1fXR86Plkbu9Fg9Jx9N,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_k7ypWjDWg_lUbHU7ul6PL1(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,double*ex_koSOkfGA3wCTgD7UMHzVC6,const
size_t ex__Qhq8A0DwpCxayd3Wx4meP,const size_t ex__o3nHuxrYcSAfPDlW4I06H,const
double*ex__DeeKqxVkgxqhHgsvRavsg,const size_t*ex_VZzCVEv_E686iTwj8YGVM7,double
*ex_F1rQUll_EnhbfeQZPiHn_s);double ex_Vwan_yZETEpgj9oiOzAX4n(const size_t
ex_k_6zaL2966Wtbi_ZH4jtru,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t
ex__yM_A_2BN54jcmwUSM5scj,const double*ex_FStFcQlyAJ_dVy4kGZXBPQ,const double*
H,const double*ex_F6RnVICINc49ciNf98e_Is,const size_t*
ex_V_UvGTfGl_SJaiQExjAoMx,double*ex_V_B9zWHH1lOKeDF123SdyB);size_t
ex_Vy7Ms6IbIBlXhqmj1nRra2(const size_t ex_FtLpaXfWjlhXVyJeyN2hSL,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t
*ex_FHcjR_usTa4LYqB68SWCBT,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t
ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP,const double*
*ex_keuqc0JkC8SQZLp7wSGmG6,size_t**ex_Vic4f_t1_8lMdPxTHOuua8,double**
ex_kNB1fXR86Plkbu9Fg9Jx9N,double*H,double*ex_F6RnVICINc49ciNf98e_Is);void
ex__r0oWBiQ7Fp4aXbH65BZ_t(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,const double ex__DeeKqxVkgxqhHgsvRavsg,const size_t b,double*H1,double*H2,
double*H3,double*H4);size_t ex_VF6BzpGacs_E_9CXFHed_I(const size_t*
ex_F2l4p_g4sn02huHNflQjMH,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B);void
ex_kw_oFrpzPH_7eyJRzldHYQ(size_t*ex_F2l4p_g4sn02huHNflQjMH,const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B);void ex_FdOINfzBl14LhHoPJjZvQg(const size_t*
ex_kxydxYiH7Klu_5VxWpaRqo,const size_t ex_F9XXYvbW1X_RXP6D2uUU48,size_t*
ex_FxajFA_1TahGZXVH9j9Gmx,size_t*ex_VP6UMDxcGrpRcThEcmqI0C,size_t*
ex_kaClFa7GFotAhac1oMBMZn);double ex_V7K1AhcbGYxBXLLX4NJH5f(const double a);
size_t ex_VP1AIhBqhr8UjPFzg_S70e(const double*x,const size_t n,const double
ex__DeeKqxVkgxqhHgsvRavsg);size_t ex__h_X9bmrQK0Rg9mXMtm6iz(const double*x,
const size_t ex_V5LBNJCbhICNbmMG_hLaZ6);size_t ex___xN3n8gXlhcdqFMCs70RT(const
double**ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const
size_t ex_F3nVSXkoDK8VeeL5OmY0_B);void ex_kdH1Hb3ZR9_6cqIDW1RDok(const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const double*ex_VsAv95vpmFp3i1E54_unM9,double*work1
,size_t*work2,double*ex_koSOkfGA3wCTgD7UMHzVC6){ex__e_Rvt1zKg_LiqW_Ljkdfe(
ex_VToqGBrino_cYuTsjsb5G7,ex_VsAv95vpmFp3i1E54_unM9,ex__jP7F4Fk5ExlWmUH2CnO0p,
ex_F3nVSXkoDK8VeeL5OmY0_B,work1,work2,ex_koSOkfGA3wCTgD7UMHzVC6);}void
ex_Vt43VeczGdCdVuEpZQh81F(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const size_t
ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP,double*
ex__g9rIuQqKUWtZastp1XFl9,size_t*ex_ked9tdolvUCd_PP3XHAAJ5,double*
ex_koSOkfGA3wCTgD7UMHzVC6,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*
*ex_keuqc0JkC8SQZLp7wSGmG6,size_t**ex_Vic4f_t1_8lMdPxTHOuua8,double*
ex__zQbdTEDftlFdLWYhMGZcH){ex_kUMpUuPKaDtphe_ZEm_2A_(ex_VToqGBrino_cYuTsjsb5G7
,ex__jP7F4Fk5ExlWmUH2CnO0p,ex_F3nVSXkoDK8VeeL5OmY0_B,ex_F_tm5fod4xxuguhS49BSQm
,ex__g9rIuQqKUWtZastp1XFl9,ex_ked9tdolvUCd_PP3XHAAJ5,ex_koSOkfGA3wCTgD7UMHzVC6
,ex__Qhq8A0DwpCxayd3Wx4meP,ex__NJXN1LXJ3dhZPDo3_p2LH,ex_keuqc0JkC8SQZLp7wSGmG6
,ex_Vic4f_t1_8lMdPxTHOuua8,(double**)0,ex__zQbdTEDftlFdLWYhMGZcH);}void
ex_VUv5qERYa5OL_DZXviEVuZ(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*ex__DeeKqxVkgxqhHgsvRavsg
,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double*ex_kKG_5OBKXuhncyckTip21X){
size_t b,ex_FtLpaXfWjlhXVyJeyN2hSL,ex__Cd9Ggd936_Hg1SkLb3g6J;for(
ex_FtLpaXfWjlhXVyJeyN2hSL=0;ex_FtLpaXfWjlhXVyJeyN2hSL<
ex__NJXN1LXJ3dhZPDo3_p2LH;++ex_FtLpaXfWjlhXVyJeyN2hSL){b=
ex_Vic4f_t1_8lMdPxTHOuua8?ex_Vic4f_t1_8lMdPxTHOuua8[ex_FtLpaXfWjlhXVyJeyN2hSL]
:ex_VP1AIhBqhr8UjPFzg_S70e(x,ex_V5LBNJCbhICNbmMG_hLaZ6,
ex__DeeKqxVkgxqhHgsvRavsg[ex_FtLpaXfWjlhXVyJeyN2hSL]);
ex__Cd9Ggd936_Hg1SkLb3g6J=4*ex_FtLpaXfWjlhXVyJeyN2hSL;
ex__r0oWBiQ7Fp4aXbH65BZ_t(x,ex_V5LBNJCbhICNbmMG_hLaZ6,
ex_F_tm5fod4xxuguhS49BSQm,ex__Qhq8A0DwpCxayd3Wx4meP,ex__DeeKqxVkgxqhHgsvRavsg[
ex_FtLpaXfWjlhXVyJeyN2hSL],b,ex_kKG_5OBKXuhncyckTip21X+
ex__Cd9Ggd936_Hg1SkLb3g6J,ex_kKG_5OBKXuhncyckTip21X+ex__Cd9Ggd936_Hg1SkLb3g6J+
1,ex_kKG_5OBKXuhncyckTip21X+ex__Cd9Ggd936_Hg1SkLb3g6J+2,
ex_kKG_5OBKXuhncyckTip21X+ex__Cd9Ggd936_Hg1SkLb3g6J+3);}}void
ex__I__tR3HVGtUdmAFtUcU_G(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const size_t
ex_F_tm5fod4xxuguhS49BSQm,double*ex_koSOkfGA3wCTgD7UMHzVC6,double**
ex_kKG_5OBKXuhncyckTip21X,double*work1,size_t*work2,const size_t
ex__NJXN1LXJ3dhZPDo3_p2LH,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double*ex__zQbdTEDftlFdLWYhMGZcH){const size_t
ex__XmeRCn_Hs4Wi9RvpsBaCd=2;ex_kUMpUuPKaDtphe_ZEm_2A_(
ex_VToqGBrino_cYuTsjsb5G7,ex__jP7F4Fk5ExlWmUH2CnO0p,ex_F3nVSXkoDK8VeeL5OmY0_B,
ex_F_tm5fod4xxuguhS49BSQm,work1,work2,ex_koSOkfGA3wCTgD7UMHzVC6,
ex__XmeRCn_Hs4Wi9RvpsBaCd,ex__NJXN1LXJ3dhZPDo3_p2LH,ex_keuqc0JkC8SQZLp7wSGmG6,
ex_Vic4f_t1_8lMdPxTHOuua8,ex_kKG_5OBKXuhncyckTip21X,ex__zQbdTEDftlFdLWYhMGZcH)
;}void ex_k3a7efHitoCaVqpYN7YToy(const double*x,const size_t
ex_V5LBNJCbhICNbmMG_hLaZ6,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const double*
ex__DeeKqxVkgxqhHgsvRavsg,size_t*ex_Vic4f_t1_8lMdPxTHOuua8){size_t
ex_V2__YrimeI4E_yWnhKofpy;for(ex_V2__YrimeI4E_yWnhKofpy=0;
ex_V2__YrimeI4E_yWnhKofpy<ex__NJXN1LXJ3dhZPDo3_p2LH;++
ex_V2__YrimeI4E_yWnhKofpy){ex_Vic4f_t1_8lMdPxTHOuua8[ex_V2__YrimeI4E_yWnhKofpy
]=ex_VP1AIhBqhr8UjPFzg_S70e(x,ex_V5LBNJCbhICNbmMG_hLaZ6,
ex__DeeKqxVkgxqhHgsvRavsg[ex_V2__YrimeI4E_yWnhKofpy]);}}void
ex_kEWp_Qwr9TpuV5h0iCW4f_(const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t*
ex__jP7F4Fk5ExlWmUH2CnO0p,const double**ex_VToqGBrino_cYuTsjsb5G7,const double
*ex_VsAv95vpmFp3i1E54_unM9,double*work1,size_t*work2,double*
ex_koSOkfGA3wCTgD7UMHzVC6){ex_kdH1Hb3ZR9_6cqIDW1RDok(ex_F3nVSXkoDK8VeeL5OmY0_B
,ex__jP7F4Fk5ExlWmUH2CnO0p,ex_VToqGBrino_cYuTsjsb5G7,ex_VsAv95vpmFp3i1E54_unM9
,work1,work2,ex_koSOkfGA3wCTgD7UMHzVC6);}void ex_Vs9jGA8_KnhLXD1GzoOLPW(const
size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*x,const double*v,double*
ex__UNT5rIVeICNXTfUhGCl8W,double*ex_koSOkfGA3wCTgD7UMHzVC6){
ex_kMdulA9uFAKeaDf3iz34v4(x,v,ex_V5LBNJCbhICNbmMG_hLaZ6,
ex__UNT5rIVeICNXTfUhGCl8W,ex_koSOkfGA3wCTgD7UMHzVC6);}void
ex__KeFoQApKT8cgHlyO01BeY(const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const double*
x,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t ex__NJXN1LXJ3dhZPDo3_p2LH,const
double*ex__DeeKqxVkgxqhHgsvRavsg,const size_t*ex_Vic4f_t1_8lMdPxTHOuua8,double
*ex_F1rQUll_EnhbfeQZPiHn_s){ex_k7ypWjDWg_lUbHU7ul6PL1(x,
ex_V5LBNJCbhICNbmMG_hLaZ6,ex_F_tm5fod4xxuguhS49BSQm,ex_koSOkfGA3wCTgD7UMHzVC6,
ex__Qhq8A0DwpCxayd3Wx4meP,ex__NJXN1LXJ3dhZPDo3_p2LH,ex__DeeKqxVkgxqhHgsvRavsg,
ex_Vic4f_t1_8lMdPxTHOuua8,ex_F1rQUll_EnhbfeQZPiHn_s);}
