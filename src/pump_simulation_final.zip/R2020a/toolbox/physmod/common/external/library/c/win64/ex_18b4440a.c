#include "pm_std.h"
#include "lang_std.h"
size_t ex_FSBp3lkv5gpCXL2yT9vLNh(const real_T*x,const size_t n,const real_T t)
;void ex_kGRJvwU4WMthWL53sjRCpO(real_T*ex_F2l4p_g4sn02huHNflQjMH,const size_t
n1,const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT);void
ex_FtfBZE2kLGxyWamCvlRfeQ(real_T*x,real_T*f,const size_t n);void
ex_F4LajttG6uGtbXBJgUNQpW(real_T*x1,real_T*x2,real_T*f,const size_t n1,const
size_t n2);void ex_kIBgcKPC9nhchTKovcabSa(real_T*x1,real_T*x2,real_T*x3,real_T
*f,const size_t n1,const size_t n2,const size_t n3);void
ex_F_6wSEEsvm_1cTAuvwDt9B(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*f,
const size_t n1,const size_t n2,const size_t n3,const size_t n4);size_t
ex_FSBp3lkv5gpCXL2yT9vLNh(const real_T*x,const size_t n,const real_T t){size_t
ex_kwrB3ZoKf7OufTHWaHJV7a;for(ex_kwrB3ZoKf7OufTHWaHJV7a=0;
ex_kwrB3ZoKf7OufTHWaHJV7a<n;++ex_kwrB3ZoKf7OufTHWaHJV7a){if(t<x[
ex_kwrB3ZoKf7OufTHWaHJV7a]){return ex_kwrB3ZoKf7OufTHWaHJV7a;}}return n;}void
ex_kGRJvwU4WMthWL53sjRCpO(real_T*ex_F2l4p_g4sn02huHNflQjMH,const size_t n1,
const size_t n2,const size_t n3,const size_t n4,const size_t
ex_kyZWlRgyPY_nhaYrzhlz4N,const size_t ex_VSy0VE52bQSafuDoXEVasH,const size_t
ex_keXUKEfwn7pKd9Pw_tgV73,const size_t ex_FZiPJehSX8hycyX0BLEeoT){size_t
ex_FnrjFNs9eQp9V5vCxPaoKw,ex_FRuIUemzxbdhfqkjXhoyK7,ex_kRXTNbOCUd0KeHaF5Udb_Y,
ex_Fz136CeCPW_CcPzKpIHjrJ;size_t ex_VEXzFHKjFN87iiOtLrddNz;size_t
ex_Fb8WfqABMs_vcqFzZf37Fa=0,ex_k4UiAV7JSYpMjHsHDM_wV6=0,
ex__Y8nRW2S0zdlXHnGSWOxB7=0,ex_k0tWTAAjJXlFYq0zTB2_9p=0,
ex_VW6olMqleTpGW5_xILSuOW=0;real_T ex__0Gxic3Bpu_HjDevqjQi0l;for(
ex_Fz136CeCPW_CcPzKpIHjrJ=0;ex_Fz136CeCPW_CcPzKpIHjrJ<n4;++
ex_Fz136CeCPW_CcPzKpIHjrJ){ex_k0tWTAAjJXlFYq0zTB2_9p=ex_FZiPJehSX8hycyX0BLEeoT
*ex_Fz136CeCPW_CcPzKpIHjrJ;for(ex_kRXTNbOCUd0KeHaF5Udb_Y=0;
ex_kRXTNbOCUd0KeHaF5Udb_Y<n3;++ex_kRXTNbOCUd0KeHaF5Udb_Y){
ex__Y8nRW2S0zdlXHnGSWOxB7=ex_keXUKEfwn7pKd9Pw_tgV73*ex_kRXTNbOCUd0KeHaF5Udb_Y+
ex_k0tWTAAjJXlFYq0zTB2_9p;for(ex_FRuIUemzxbdhfqkjXhoyK7=0;
ex_FRuIUemzxbdhfqkjXhoyK7<n2;++ex_FRuIUemzxbdhfqkjXhoyK7){
ex_k4UiAV7JSYpMjHsHDM_wV6=ex_VSy0VE52bQSafuDoXEVasH*ex_FRuIUemzxbdhfqkjXhoyK7+
ex__Y8nRW2S0zdlXHnGSWOxB7;ex_VEXzFHKjFN87iiOtLrddNz=n1-1;for(
ex_FnrjFNs9eQp9V5vCxPaoKw=0;ex_FnrjFNs9eQp9V5vCxPaoKw<(n1/2);++
ex_FnrjFNs9eQp9V5vCxPaoKw){ex_Fb8WfqABMs_vcqFzZf37Fa=ex_kyZWlRgyPY_nhaYrzhlz4N
*ex_FnrjFNs9eQp9V5vCxPaoKw+ex_k4UiAV7JSYpMjHsHDM_wV6;ex_VW6olMqleTpGW5_xILSuOW
=ex_kyZWlRgyPY_nhaYrzhlz4N*ex_VEXzFHKjFN87iiOtLrddNz+ex_k4UiAV7JSYpMjHsHDM_wV6
;ex__0Gxic3Bpu_HjDevqjQi0l=ex_F2l4p_g4sn02huHNflQjMH[ex_Fb8WfqABMs_vcqFzZf37Fa
];ex_F2l4p_g4sn02huHNflQjMH[ex_Fb8WfqABMs_vcqFzZf37Fa]=
ex_F2l4p_g4sn02huHNflQjMH[ex_VW6olMqleTpGW5_xILSuOW];ex_F2l4p_g4sn02huHNflQjMH
[ex_VW6olMqleTpGW5_xILSuOW]=ex__0Gxic3Bpu_HjDevqjQi0l;--
ex_VEXzFHKjFN87iiOtLrddNz;}}}}}void ex_FtfBZE2kLGxyWamCvlRfeQ(real_T*x,real_T*
f,const size_t n){if(x[n-1]<x[0]){ex_kGRJvwU4WMthWL53sjRCpO(x,n,1,1,1,1,0,0,0)
;ex_kGRJvwU4WMthWL53sjRCpO(f,n,1,1,1,1,0,0,0);}}void ex_F4LajttG6uGtbXBJgUNQpW
(real_T*x1,real_T*x2,real_T*f,const size_t n1,const size_t n2){size_t
ex_kyZWlRgyPY_nhaYrzhlz4N=1;size_t ex_VSy0VE52bQSafuDoXEVasH=
ex_kyZWlRgyPY_nhaYrzhlz4N*n1;if(x1[n1-1]<x1[0]){ex_kGRJvwU4WMthWL53sjRCpO(x1,
n1,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n1,n2,1,1,
ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,0,0);}if(x2[n2-1]<x2[0]){
ex_kGRJvwU4WMthWL53sjRCpO(x2,n2,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n2,
n1,1,1,ex_VSy0VE52bQSafuDoXEVasH,ex_kyZWlRgyPY_nhaYrzhlz4N,0,0);}}void
ex_kIBgcKPC9nhchTKovcabSa(real_T*x1,real_T*x2,real_T*x3,real_T*f,const size_t
n1,const size_t n2,const size_t n3){size_t ex_kyZWlRgyPY_nhaYrzhlz4N=1;size_t
ex_VSy0VE52bQSafuDoXEVasH=ex_kyZWlRgyPY_nhaYrzhlz4N*n1;size_t
ex_keXUKEfwn7pKd9Pw_tgV73=ex_VSy0VE52bQSafuDoXEVasH*n2;if(x1[n1-1]<x1[0]){
ex_kGRJvwU4WMthWL53sjRCpO(x1,n1,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n1,
n2,n3,1,ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,
ex_keXUKEfwn7pKd9Pw_tgV73,0);}if(x2[n2-1]<x2[0]){ex_kGRJvwU4WMthWL53sjRCpO(x2,
n2,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n2,n3,n1,1,
ex_VSy0VE52bQSafuDoXEVasH,ex_keXUKEfwn7pKd9Pw_tgV73,ex_kyZWlRgyPY_nhaYrzhlz4N,
0);}if(x3[n3-1]<x3[0]){ex_kGRJvwU4WMthWL53sjRCpO(x3,n3,1,1,1,1,0,0,0);
ex_kGRJvwU4WMthWL53sjRCpO(f,n3,n1,n2,1,ex_keXUKEfwn7pKd9Pw_tgV73,
ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,0);}}void
ex_F_6wSEEsvm_1cTAuvwDt9B(real_T*x1,real_T*x2,real_T*x3,real_T*x4,real_T*f,
const size_t n1,const size_t n2,const size_t n3,const size_t n4){size_t
ex_kyZWlRgyPY_nhaYrzhlz4N=1;size_t ex_VSy0VE52bQSafuDoXEVasH=
ex_kyZWlRgyPY_nhaYrzhlz4N*n1;size_t ex_keXUKEfwn7pKd9Pw_tgV73=
ex_VSy0VE52bQSafuDoXEVasH*n2;size_t ex_FZiPJehSX8hycyX0BLEeoT=
ex_keXUKEfwn7pKd9Pw_tgV73*n3;if(x1[n1-1]<x1[0]){ex_kGRJvwU4WMthWL53sjRCpO(x1,
n1,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n1,n2,n3,n4,
ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,ex_keXUKEfwn7pKd9Pw_tgV73,
ex_FZiPJehSX8hycyX0BLEeoT);}if(x2[n2-1]<x2[0]){ex_kGRJvwU4WMthWL53sjRCpO(x2,n2
,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n2,n3,n4,n1,
ex_VSy0VE52bQSafuDoXEVasH,ex_keXUKEfwn7pKd9Pw_tgV73,ex_FZiPJehSX8hycyX0BLEeoT,
ex_kyZWlRgyPY_nhaYrzhlz4N);}if(x3[n3-1]<x3[0]){ex_kGRJvwU4WMthWL53sjRCpO(x3,n3
,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n3,n4,n1,n2,
ex_keXUKEfwn7pKd9Pw_tgV73,ex_FZiPJehSX8hycyX0BLEeoT,ex_kyZWlRgyPY_nhaYrzhlz4N,
ex_VSy0VE52bQSafuDoXEVasH);}if(x4[n4-1]<x4[0]){ex_kGRJvwU4WMthWL53sjRCpO(x4,n4
,1,1,1,1,0,0,0);ex_kGRJvwU4WMthWL53sjRCpO(f,n4,n1,n2,n3,
ex_FZiPJehSX8hycyX0BLEeoT,ex_kyZWlRgyPY_nhaYrzhlz4N,ex_VSy0VE52bQSafuDoXEVasH,
ex_keXUKEfwn7pKd9Pw_tgV73);}}
