#include "string.h"
#include "stddef.h"
void ex_kUMpUuPKaDtphe_ZEm_2A_(const double**ex_VToqGBrino_cYuTsjsb5G7,const
size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const
size_t ex_F_tm5fod4xxuguhS49BSQm,double*ex__g9rIuQqKUWtZastp1XFl9,size_t*
ex_ked9tdolvUCd_PP3XHAAJ5,double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t
ex__Qhq8A0DwpCxayd3Wx4meP,const size_t ex__o3nHuxrYcSAfPDlW4I06H,const double*
*ex_keuqc0JkC8SQZLp7wSGmG6,size_t**ex_Vic4f_t1_8lMdPxTHOuua8,double**
ex_kNB1fXR86Plkbu9Fg9Jx9N,double*ex__zQbdTEDftlFdLWYhMGZcH);void
ex_k7ypWjDWg_lUbHU7ul6PL1(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,double*ex_koSOkfGA3wCTgD7UMHzVC6,const
size_t ex__Qhq8A0DwpCxayd3Wx4meP,const size_t ex__o3nHuxrYcSAfPDlW4I06H,const
double*ex__DeeKqxVkgxqhHgsvRavsg,const size_t*ex_VZzCVEv_E686iTwj8YGVM7,double
*ex_F1rQUll_EnhbfeQZPiHn_s);double ex_Vwan_yZETEpgj9oiOzAX4n(const size_t
ex_k_6zaL2966Wtbi_ZH4jtru,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t
ex__yM_A_2BN54jcmwUSM5scj,const double*ex_FStFcQlyAJ_dVy4kGZXBPQ,const double*
H,const double*ex_F6RnVICINc49ciNf98e_Is,const size_t*
ex_V_UvGTfGl_SJaiQExjAoMx,double*ex_V_B9zWHH1lOKeDF123SdyB);size_t
ex_Vy7Ms6IbIBlXhqmj1nRra2(const size_t ex_FtLpaXfWjlhXVyJeyN2hSL,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t
*ex_FHcjR_usTa4LYqB68SWCBT,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t
ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP,const double*
*ex_keuqc0JkC8SQZLp7wSGmG6,size_t**ex_Vic4f_t1_8lMdPxTHOuua8,double**
ex_kNB1fXR86Plkbu9Fg9Jx9N,double*H,double*ex_F6RnVICINc49ciNf98e_Is);void
ex__r0oWBiQ7Fp4aXbH65BZ_t(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,const double ex__DeeKqxVkgxqhHgsvRavsg,const size_t b,double*H1,double*H2,
double*H3,double*H4);size_t ex_VF6BzpGacs_E_9CXFHed_I(const size_t*
ex_F2l4p_g4sn02huHNflQjMH,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B);void
ex_kw_oFrpzPH_7eyJRzldHYQ(size_t*ex_F2l4p_g4sn02huHNflQjMH,const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B);void ex_FdOINfzBl14LhHoPJjZvQg(const size_t*
ex_kxydxYiH7Klu_5VxWpaRqo,const size_t ex_F9XXYvbW1X_RXP6D2uUU48,size_t*
ex_FxajFA_1TahGZXVH9j9Gmx,size_t*ex_VP6UMDxcGrpRcThEcmqI0C,size_t*
ex_kaClFa7GFotAhac1oMBMZn);double ex_V7K1AhcbGYxBXLLX4NJH5f(const double a);
size_t ex_VP1AIhBqhr8UjPFzg_S70e(const double*x,const size_t n,const double
ex__DeeKqxVkgxqhHgsvRavsg);size_t ex__h_X9bmrQK0Rg9mXMtm6iz(const double*x,
const size_t ex_V5LBNJCbhICNbmMG_hLaZ6);size_t ex___xN3n8gXlhcdqFMCs70RT(const
double**ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const
size_t ex_F3nVSXkoDK8VeeL5OmY0_B);void ex_kUMpUuPKaDtphe_ZEm_2A_(const double*
*ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t ex_F_tm5fod4xxuguhS49BSQm,double*
ex__g9rIuQqKUWtZastp1XFl9,size_t*ex_ked9tdolvUCd_PP3XHAAJ5,double*
ex_koSOkfGA3wCTgD7UMHzVC6,const size_t ex__Qhq8A0DwpCxayd3Wx4meP,const size_t
ex__o3nHuxrYcSAfPDlW4I06H,const double**ex_keuqc0JkC8SQZLp7wSGmG6,size_t**
ex_Vic4f_t1_8lMdPxTHOuua8,double**ex_kNB1fXR86Plkbu9Fg9Jx9N,double*
ex__zQbdTEDftlFdLWYhMGZcH){size_t ex_V6njO70LRF8tVmzp79Qg_5,
ex__yM_A_2BN54jcmwUSM5scj,ex_FEa9HpQub3K9X1Fkj0Fvl_,ex_FTi_wPjU38_8buO6i19F75,
ex_FJlFrKJTlv_ThaUlVMpivJ,ex_Fg8ImRvvPYOt_D3xBhqiFM,ex_FtLpaXfWjlhXVyJeyN2hSL,
ex_k_6zaL2966Wtbi_ZH4jtru,ex__2Voi3rNiShKiDRgAw2aDa,ex__o6c_2DPlf_Ki1VA4nb9fX;
size_t*ex_FHcjR_usTa4LYqB68SWCBT;size_t*ex_kiu_0_oo5ZpJj1aotuN7lo;size_t*
ex_V_UvGTfGl_SJaiQExjAoMx;double*ex_V_B9zWHH1lOKeDF123SdyB;double*H;double*
ex_F6RnVICINc49ciNf98e_Is;ex_V6njO70LRF8tVmzp79Qg_5=((size_t)1)<<
ex_F3nVSXkoDK8VeeL5OmY0_B;ex__yM_A_2BN54jcmwUSM5scj=ex_VF6BzpGacs_E_9CXFHed_I(
ex__jP7F4Fk5ExlWmUH2CnO0p,ex_F3nVSXkoDK8VeeL5OmY0_B);ex_FHcjR_usTa4LYqB68SWCBT
=ex_ked9tdolvUCd_PP3XHAAJ5;memcpy(ex_FHcjR_usTa4LYqB68SWCBT,
ex__jP7F4Fk5ExlWmUH2CnO0p,ex_F3nVSXkoDK8VeeL5OmY0_B*sizeof(size_t));
ex_kw_oFrpzPH_7eyJRzldHYQ(ex_FHcjR_usTa4LYqB68SWCBT,ex_F3nVSXkoDK8VeeL5OmY0_B)
;ex_kiu_0_oo5ZpJj1aotuN7lo=ex_FHcjR_usTa4LYqB68SWCBT+ex_F3nVSXkoDK8VeeL5OmY0_B
;ex_kiu_0_oo5ZpJj1aotuN7lo[0]=0;ex_V_UvGTfGl_SJaiQExjAoMx=
ex_kiu_0_oo5ZpJj1aotuN7lo+ex_V6njO70LRF8tVmzp79Qg_5;memset(
ex_V_UvGTfGl_SJaiQExjAoMx,0,ex_F3nVSXkoDK8VeeL5OmY0_B*
ex_V6njO70LRF8tVmzp79Qg_5*sizeof(size_t));ex_V_B9zWHH1lOKeDF123SdyB=
ex__g9rIuQqKUWtZastp1XFl9;H=ex_V_B9zWHH1lOKeDF123SdyB+
ex_V6njO70LRF8tVmzp79Qg_5;ex_F6RnVICINc49ciNf98e_Is=H+2*
ex_F3nVSXkoDK8VeeL5OmY0_B;for(ex_FEa9HpQub3K9X1Fkj0Fvl_=0;
ex_FEa9HpQub3K9X1Fkj0Fvl_<ex_F3nVSXkoDK8VeeL5OmY0_B;++
ex_FEa9HpQub3K9X1Fkj0Fvl_){ex_FTi_wPjU38_8buO6i19F75=((size_t)1)<<
ex_FEa9HpQub3K9X1Fkj0Fvl_;for(ex_FJlFrKJTlv_ThaUlVMpivJ=
ex_FTi_wPjU38_8buO6i19F75;ex_FJlFrKJTlv_ThaUlVMpivJ<2*
ex_FTi_wPjU38_8buO6i19F75;++ex_FJlFrKJTlv_ThaUlVMpivJ){for(
ex_Fg8ImRvvPYOt_D3xBhqiFM=0;ex_Fg8ImRvvPYOt_D3xBhqiFM<
ex_F3nVSXkoDK8VeeL5OmY0_B;++ex_Fg8ImRvvPYOt_D3xBhqiFM){
ex_V_UvGTfGl_SJaiQExjAoMx[ex_FJlFrKJTlv_ThaUlVMpivJ*ex_F3nVSXkoDK8VeeL5OmY0_B+
ex_Fg8ImRvvPYOt_D3xBhqiFM]=(ex_Fg8ImRvvPYOt_D3xBhqiFM==
ex_FEa9HpQub3K9X1Fkj0Fvl_)?1:ex_V_UvGTfGl_SJaiQExjAoMx[(
ex_FJlFrKJTlv_ThaUlVMpivJ-ex_FTi_wPjU38_8buO6i19F75)*ex_F3nVSXkoDK8VeeL5OmY0_B
+ex_Fg8ImRvvPYOt_D3xBhqiFM];}}}for(ex_FtLpaXfWjlhXVyJeyN2hSL=0;
ex_FtLpaXfWjlhXVyJeyN2hSL<ex__o3nHuxrYcSAfPDlW4I06H;++
ex_FtLpaXfWjlhXVyJeyN2hSL){ex_k_6zaL2966Wtbi_ZH4jtru=ex_Vy7Ms6IbIBlXhqmj1nRra2
(ex_FtLpaXfWjlhXVyJeyN2hSL,ex_VToqGBrino_cYuTsjsb5G7,ex__jP7F4Fk5ExlWmUH2CnO0p
,ex_FHcjR_usTa4LYqB68SWCBT,ex_F3nVSXkoDK8VeeL5OmY0_B,ex_F_tm5fod4xxuguhS49BSQm
,ex__Qhq8A0DwpCxayd3Wx4meP,ex_keuqc0JkC8SQZLp7wSGmG6,ex_Vic4f_t1_8lMdPxTHOuua8
,ex_kNB1fXR86Plkbu9Fg9Jx9N,H,ex_F6RnVICINc49ciNf98e_Is);
ex__zQbdTEDftlFdLWYhMGZcH[ex_FtLpaXfWjlhXVyJeyN2hSL]=ex_Vwan_yZETEpgj9oiOzAX4n
(ex_k_6zaL2966Wtbi_ZH4jtru+ex_kiu_0_oo5ZpJj1aotuN7lo[0],
ex_F3nVSXkoDK8VeeL5OmY0_B,ex__yM_A_2BN54jcmwUSM5scj,ex_koSOkfGA3wCTgD7UMHzVC6,
H,ex_F6RnVICINc49ciNf98e_Is,ex_V_UvGTfGl_SJaiQExjAoMx,
ex_V_B9zWHH1lOKeDF123SdyB);for(ex_FEa9HpQub3K9X1Fkj0Fvl_=0;
ex_FEa9HpQub3K9X1Fkj0Fvl_<ex_F3nVSXkoDK8VeeL5OmY0_B;++
ex_FEa9HpQub3K9X1Fkj0Fvl_){ex__2Voi3rNiShKiDRgAw2aDa=ex_FHcjR_usTa4LYqB68SWCBT
[ex_FEa9HpQub3K9X1Fkj0Fvl_];ex_FTi_wPjU38_8buO6i19F75=((size_t)1)<<
ex_FEa9HpQub3K9X1Fkj0Fvl_;for(ex_FJlFrKJTlv_ThaUlVMpivJ=
ex_FTi_wPjU38_8buO6i19F75;ex_FJlFrKJTlv_ThaUlVMpivJ<2*
ex_FTi_wPjU38_8buO6i19F75;++ex_FJlFrKJTlv_ThaUlVMpivJ){
ex__o6c_2DPlf_Ki1VA4nb9fX=ex_kiu_0_oo5ZpJj1aotuN7lo[ex_FJlFrKJTlv_ThaUlVMpivJ-
ex_FTi_wPjU38_8buO6i19F75];ex_kiu_0_oo5ZpJj1aotuN7lo[ex_FJlFrKJTlv_ThaUlVMpivJ
]=ex__o6c_2DPlf_Ki1VA4nb9fX+ex__2Voi3rNiShKiDRgAw2aDa;
ex__zQbdTEDftlFdLWYhMGZcH[ex_FtLpaXfWjlhXVyJeyN2hSL]+=
ex_Vwan_yZETEpgj9oiOzAX4n(ex_k_6zaL2966Wtbi_ZH4jtru+ex_kiu_0_oo5ZpJj1aotuN7lo[
ex_FJlFrKJTlv_ThaUlVMpivJ],ex_F3nVSXkoDK8VeeL5OmY0_B,ex__yM_A_2BN54jcmwUSM5scj
,ex_koSOkfGA3wCTgD7UMHzVC6,H,ex_F6RnVICINc49ciNf98e_Is,
ex_V_UvGTfGl_SJaiQExjAoMx+ex_FJlFrKJTlv_ThaUlVMpivJ*ex_F3nVSXkoDK8VeeL5OmY0_B,
ex_V_B9zWHH1lOKeDF123SdyB);}}}}void ex_k7ypWjDWg_lUbHU7ul6PL1(const double*x,
const size_t ex_V5LBNJCbhICNbmMG_hLaZ6,const size_t ex_F_tm5fod4xxuguhS49BSQm,
double*ex_koSOkfGA3wCTgD7UMHzVC6,const size_t ex__Qhq8A0DwpCxayd3Wx4meP,const
size_t ex__o3nHuxrYcSAfPDlW4I06H,const double*ex__DeeKqxVkgxqhHgsvRavsg,const
size_t*ex_VZzCVEv_E686iTwj8YGVM7,double*ex_F1rQUll_EnhbfeQZPiHn_s){size_t
ex_FtLpaXfWjlhXVyJeyN2hSL,b;double H1,H2,H3,H4;for(ex_FtLpaXfWjlhXVyJeyN2hSL=0
;ex_FtLpaXfWjlhXVyJeyN2hSL<ex__o3nHuxrYcSAfPDlW4I06H;++
ex_FtLpaXfWjlhXVyJeyN2hSL){b=ex_VZzCVEv_E686iTwj8YGVM7?
ex_VZzCVEv_E686iTwj8YGVM7[ex_FtLpaXfWjlhXVyJeyN2hSL]:ex_VP1AIhBqhr8UjPFzg_S70e
(x,ex_V5LBNJCbhICNbmMG_hLaZ6,ex__DeeKqxVkgxqhHgsvRavsg[
ex_FtLpaXfWjlhXVyJeyN2hSL]);ex__r0oWBiQ7Fp4aXbH65BZ_t(x,
ex_V5LBNJCbhICNbmMG_hLaZ6,ex_F_tm5fod4xxuguhS49BSQm,ex__Qhq8A0DwpCxayd3Wx4meP,
ex__DeeKqxVkgxqhHgsvRavsg[ex_FtLpaXfWjlhXVyJeyN2hSL],b,&H1,&H2,&H3,&H4);
ex_F1rQUll_EnhbfeQZPiHn_s[ex_FtLpaXfWjlhXVyJeyN2hSL]=(
ex_koSOkfGA3wCTgD7UMHzVC6[b]*H1+ex_koSOkfGA3wCTgD7UMHzVC6[
ex_V5LBNJCbhICNbmMG_hLaZ6+b]*H2)+(ex_koSOkfGA3wCTgD7UMHzVC6[b+1]*H3+
ex_koSOkfGA3wCTgD7UMHzVC6[ex_V5LBNJCbhICNbmMG_hLaZ6+b+1]*H4);}}double
ex_Vwan_yZETEpgj9oiOzAX4n(const size_t ex_k_6zaL2966Wtbi_ZH4jtru,const size_t
ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t ex__yM_A_2BN54jcmwUSM5scj,const double*
ex_FStFcQlyAJ_dVy4kGZXBPQ,const double*H,const double*
ex_F6RnVICINc49ciNf98e_Is,const size_t*ex_V_UvGTfGl_SJaiQExjAoMx,double*
ex_V_B9zWHH1lOKeDF123SdyB){size_t ex_FEa9HpQub3K9X1Fkj0Fvl_,
ex_FJlFrKJTlv_ThaUlVMpivJ,ex_FTi_wPjU38_8buO6i19F75,ex__UG7Z_4bSspscamu_oWJqW;
ex_V_B9zWHH1lOKeDF123SdyB[0]=ex_FStFcQlyAJ_dVy4kGZXBPQ[
ex_k_6zaL2966Wtbi_ZH4jtru];for(ex_FEa9HpQub3K9X1Fkj0Fvl_=0;
ex_FEa9HpQub3K9X1Fkj0Fvl_<ex_F3nVSXkoDK8VeeL5OmY0_B;++
ex_FEa9HpQub3K9X1Fkj0Fvl_){ex_FTi_wPjU38_8buO6i19F75=((size_t)1)<<
ex_FEa9HpQub3K9X1Fkj0Fvl_;for(ex_FJlFrKJTlv_ThaUlVMpivJ=
ex_FTi_wPjU38_8buO6i19F75;ex_FJlFrKJTlv_ThaUlVMpivJ<2*
ex_FTi_wPjU38_8buO6i19F75;++ex_FJlFrKJTlv_ThaUlVMpivJ){
ex_V_B9zWHH1lOKeDF123SdyB[ex_FJlFrKJTlv_ThaUlVMpivJ]=ex_FStFcQlyAJ_dVy4kGZXBPQ
[ex_FJlFrKJTlv_ThaUlVMpivJ*ex__yM_A_2BN54jcmwUSM5scj+ex_k_6zaL2966Wtbi_ZH4jtru
];}}for(ex_FEa9HpQub3K9X1Fkj0Fvl_=ex_F3nVSXkoDK8VeeL5OmY0_B;
ex_FEa9HpQub3K9X1Fkj0Fvl_>0;--ex_FEa9HpQub3K9X1Fkj0Fvl_){
ex__UG7Z_4bSspscamu_oWJqW=2*(ex_F3nVSXkoDK8VeeL5OmY0_B-
ex_FEa9HpQub3K9X1Fkj0Fvl_)+ex_V_UvGTfGl_SJaiQExjAoMx[ex_F3nVSXkoDK8VeeL5OmY0_B
-ex_FEa9HpQub3K9X1Fkj0Fvl_];ex_FTi_wPjU38_8buO6i19F75=((size_t)1)<<(
ex_FEa9HpQub3K9X1Fkj0Fvl_-1);for(ex_FJlFrKJTlv_ThaUlVMpivJ=0;
ex_FJlFrKJTlv_ThaUlVMpivJ<ex_FTi_wPjU38_8buO6i19F75;++
ex_FJlFrKJTlv_ThaUlVMpivJ){ex_V_B9zWHH1lOKeDF123SdyB[ex_FJlFrKJTlv_ThaUlVMpivJ
]=ex_V_B9zWHH1lOKeDF123SdyB[2*ex_FJlFrKJTlv_ThaUlVMpivJ]*H[
ex__UG7Z_4bSspscamu_oWJqW]+ex_V_B9zWHH1lOKeDF123SdyB[2*
ex_FJlFrKJTlv_ThaUlVMpivJ+1]*ex_F6RnVICINc49ciNf98e_Is[
ex__UG7Z_4bSspscamu_oWJqW];}}return ex_V_B9zWHH1lOKeDF123SdyB[0];}size_t
ex_Vy7Ms6IbIBlXhqmj1nRra2(const size_t ex_FtLpaXfWjlhXVyJeyN2hSL,const double*
*ex_VToqGBrino_cYuTsjsb5G7,const size_t*ex__jP7F4Fk5ExlWmUH2CnO0p,const size_t
*ex_FHcjR_usTa4LYqB68SWCBT,const size_t ex_F3nVSXkoDK8VeeL5OmY0_B,const size_t
ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP,const double*
*ex_keuqc0JkC8SQZLp7wSGmG6,size_t**ex_Vic4f_t1_8lMdPxTHOuua8,double**
ex_kNB1fXR86Plkbu9Fg9Jx9N,double*H,double*ex_F6RnVICINc49ciNf98e_Is){size_t
ex_FJlFrKJTlv_ThaUlVMpivJ,b,ex_k_6zaL2966Wtbi_ZH4jtru,
ex_kZ7pFYL2NUCreebu_VwQXO,ex__Cd9Ggd936_Hg1SkLb3g6J;ex_k_6zaL2966Wtbi_ZH4jtru=
0;ex__Cd9Ggd936_Hg1SkLb3g6J=4*ex_FtLpaXfWjlhXVyJeyN2hSL;for(
ex_FJlFrKJTlv_ThaUlVMpivJ=0;ex_FJlFrKJTlv_ThaUlVMpivJ<
ex_F3nVSXkoDK8VeeL5OmY0_B;++ex_FJlFrKJTlv_ThaUlVMpivJ){b=
ex_Vic4f_t1_8lMdPxTHOuua8?ex_Vic4f_t1_8lMdPxTHOuua8[ex_FJlFrKJTlv_ThaUlVMpivJ]
[ex_FtLpaXfWjlhXVyJeyN2hSL]:ex_VP1AIhBqhr8UjPFzg_S70e(
ex_VToqGBrino_cYuTsjsb5G7[ex_FJlFrKJTlv_ThaUlVMpivJ],ex__jP7F4Fk5ExlWmUH2CnO0p
[ex_FJlFrKJTlv_ThaUlVMpivJ],ex_keuqc0JkC8SQZLp7wSGmG6[
ex_FJlFrKJTlv_ThaUlVMpivJ][ex_FtLpaXfWjlhXVyJeyN2hSL]);
ex_kZ7pFYL2NUCreebu_VwQXO=2*ex_FJlFrKJTlv_ThaUlVMpivJ;if(
ex_kNB1fXR86Plkbu9Fg9Jx9N!=0){H[ex_kZ7pFYL2NUCreebu_VwQXO]=
ex_kNB1fXR86Plkbu9Fg9Jx9N[ex_FJlFrKJTlv_ThaUlVMpivJ][ex__Cd9Ggd936_Hg1SkLb3g6J
];ex_F6RnVICINc49ciNf98e_Is[ex_kZ7pFYL2NUCreebu_VwQXO]=
ex_kNB1fXR86Plkbu9Fg9Jx9N[ex_FJlFrKJTlv_ThaUlVMpivJ][ex__Cd9Ggd936_Hg1SkLb3g6J
+1];H[ex_kZ7pFYL2NUCreebu_VwQXO+1]=ex_kNB1fXR86Plkbu9Fg9Jx9N[
ex_FJlFrKJTlv_ThaUlVMpivJ][ex__Cd9Ggd936_Hg1SkLb3g6J+2];
ex_F6RnVICINc49ciNf98e_Is[ex_kZ7pFYL2NUCreebu_VwQXO+1]=
ex_kNB1fXR86Plkbu9Fg9Jx9N[ex_FJlFrKJTlv_ThaUlVMpivJ][ex__Cd9Ggd936_Hg1SkLb3g6J
+3];}else{ex__r0oWBiQ7Fp4aXbH65BZ_t(ex_VToqGBrino_cYuTsjsb5G7[
ex_FJlFrKJTlv_ThaUlVMpivJ],ex__jP7F4Fk5ExlWmUH2CnO0p[ex_FJlFrKJTlv_ThaUlVMpivJ
],ex_F_tm5fod4xxuguhS49BSQm,ex__Qhq8A0DwpCxayd3Wx4meP,
ex_keuqc0JkC8SQZLp7wSGmG6[ex_FJlFrKJTlv_ThaUlVMpivJ][ex_FtLpaXfWjlhXVyJeyN2hSL
],b,H+ex_kZ7pFYL2NUCreebu_VwQXO,ex_F6RnVICINc49ciNf98e_Is+
ex_kZ7pFYL2NUCreebu_VwQXO,H+ex_kZ7pFYL2NUCreebu_VwQXO+1,
ex_F6RnVICINc49ciNf98e_Is+ex_kZ7pFYL2NUCreebu_VwQXO+1);}
ex_k_6zaL2966Wtbi_ZH4jtru+=b*ex_FHcjR_usTa4LYqB68SWCBT[
ex_FJlFrKJTlv_ThaUlVMpivJ];}return ex_k_6zaL2966Wtbi_ZH4jtru;}void
ex__r0oWBiQ7Fp4aXbH65BZ_t(const double*x,const size_t ex_V5LBNJCbhICNbmMG_hLaZ6
,const size_t ex_F_tm5fod4xxuguhS49BSQm,const size_t ex__Qhq8A0DwpCxayd3Wx4meP
,const double ex__DeeKqxVkgxqhHgsvRavsg,const size_t b,double*H1,double*H2,
double*H3,double*H4){double ex_V6t5zV_jpC0KdeBXmkcSMH,
ex_FQferGZUKft3_i5GvYy4Oy,ex_Fl7GdOQqGEWCcqQK5l5ja4,ex_F_G05VSDehtIi5erCMrhEO;
if(ex_V5LBNJCbhICNbmMG_hLaZ6<3&&ex_F_tm5fod4xxuguhS49BSQm!=1){
ex_V6t5zV_jpC0KdeBXmkcSMH=x[b+1]-x[b];ex_FQferGZUKft3_i5GvYy4Oy=(
ex__DeeKqxVkgxqhHgsvRavsg-x[b])/ex_V6t5zV_jpC0KdeBXmkcSMH;*H1=1-
ex_FQferGZUKft3_i5GvYy4Oy;*H2=0;*H3=ex_FQferGZUKft3_i5GvYy4Oy;*H4=0;}else{if(
ex_F_tm5fod4xxuguhS49BSQm>0&&ex__DeeKqxVkgxqhHgsvRavsg<x[0]){if(
ex__Qhq8A0DwpCxayd3Wx4meP){*H1=1;*H2=(ex__DeeKqxVkgxqhHgsvRavsg-x[0])*(
ex_F_tm5fod4xxuguhS49BSQm-1);*H3=0;*H4=0;}else{*H1=0;*H2=(double)(
ex_F_tm5fod4xxuguhS49BSQm-1);*H3=0;*H4=0;}}else if(ex_F_tm5fod4xxuguhS49BSQm>0
&&ex__DeeKqxVkgxqhHgsvRavsg>x[ex_V5LBNJCbhICNbmMG_hLaZ6-1]){if(
ex__Qhq8A0DwpCxayd3Wx4meP){*H1=0;*H2=0;*H3=1;*H4=(ex__DeeKqxVkgxqhHgsvRavsg-x[
ex_V5LBNJCbhICNbmMG_hLaZ6-1])*(ex_F_tm5fod4xxuguhS49BSQm-1);}else{*H1=0;*H2=0;
*H3=0;*H4=(double)(ex_F_tm5fod4xxuguhS49BSQm-1);}}else{
ex_V6t5zV_jpC0KdeBXmkcSMH=x[b+1]-x[b];ex_FQferGZUKft3_i5GvYy4Oy=(
ex__DeeKqxVkgxqhHgsvRavsg-x[b])/ex_V6t5zV_jpC0KdeBXmkcSMH;if(
ex__Qhq8A0DwpCxayd3Wx4meP){ex_Fl7GdOQqGEWCcqQK5l5ja4=ex_FQferGZUKft3_i5GvYy4Oy
*ex_FQferGZUKft3_i5GvYy4Oy;ex_F_G05VSDehtIi5erCMrhEO=ex_Fl7GdOQqGEWCcqQK5l5ja4
*ex_FQferGZUKft3_i5GvYy4Oy;*H3= -(2*ex_F_G05VSDehtIi5erCMrhEO-3*
ex_Fl7GdOQqGEWCcqQK5l5ja4);*H1= -H3[0]+1;*H2=(ex_F_G05VSDehtIi5erCMrhEO-2*
ex_Fl7GdOQqGEWCcqQK5l5ja4+ex_FQferGZUKft3_i5GvYy4Oy)*ex_V6t5zV_jpC0KdeBXmkcSMH
;*H4=(ex_F_G05VSDehtIi5erCMrhEO-ex_Fl7GdOQqGEWCcqQK5l5ja4)*
ex_V6t5zV_jpC0KdeBXmkcSMH;}else{ex_Fl7GdOQqGEWCcqQK5l5ja4=
ex_FQferGZUKft3_i5GvYy4Oy*ex_FQferGZUKft3_i5GvYy4Oy;ex_F_G05VSDehtIi5erCMrhEO=
6*(ex_Fl7GdOQqGEWCcqQK5l5ja4-ex_FQferGZUKft3_i5GvYy4Oy)/
ex_V6t5zV_jpC0KdeBXmkcSMH;*H1=ex_F_G05VSDehtIi5erCMrhEO;*H2=3*
ex_Fl7GdOQqGEWCcqQK5l5ja4-4*ex_FQferGZUKft3_i5GvYy4Oy+1;*H3= -
ex_F_G05VSDehtIi5erCMrhEO;*H4=3*ex_Fl7GdOQqGEWCcqQK5l5ja4-2*
ex_FQferGZUKft3_i5GvYy4Oy;}}}}
